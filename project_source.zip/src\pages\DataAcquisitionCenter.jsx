import { useState, useMemo, useRef } from 'react'
import {
  ShieldCheck,
  Cpu,
  Edit,
  History,
  Users,
  Search,
  Filter,
  RefreshCw,
  Plus,
  Upload,
  Download,
  X,
  ChevronDown,
  ChevronUp,
  FileText,
  AlertTriangle,
  FileUp,
  ExternalLink,
  Check,
  Trash2,
  HardHat,
  Award,
  Heart,
  TrendingUp,
  Building2,
  Briefcase,
  UserCheck,
  Maximize2,
  Minimize2,
  DownloadCloud,
  ChevronLeft,
  ChevronRight,
  Info,
  Sparkles,
  Zap,
  Activity,
  Layers,
  FileSpreadsheet
} from 'lucide-react'

// Initial Workers database for Real-name tab
const INITIAL_WORKERS = [
  { id: '1', name: '张建国', sex: '男', idCard: '3701021980******56', jobType: '钢筋工', team: '钢筋一班', enterprise: '中建一局集团有限公司', project: '北京CBD东区超高层项目', entryDate: '2026-01-10', exitDate: '-', status: '在场', evalStatus: '可评价', completeness: 94, updateTime: '2026-07-09 10:15:30', certificate: '建筑施工特种作业操作证(钢筋工)', safetyStatus: '已培训且合格' },
  { id: '2', name: '李强', sex: '男', idCard: '4201061988******90', jobType: '架子工', team: '架子二班', enterprise: '中建一局集团有限公司', project: '北京CBD东区超高层项目', entryDate: '2026-02-15', exitDate: '-', status: '在场', evalStatus: '可评价', completeness: 91, updateTime: '2026-07-09 09:30:12', certificate: '建筑施工特种作业操作证(高处架子工)', safetyStatus: '已培训且合格' },
  { id: '3', name: '王朝阳', sex: '男', idCard: '1301021992******67', jobType: '泥工', team: '泥工一班', enterprise: '中铁十一局集团有限公司', project: '北京轨道交通28号线项目', entryDate: '2026-03-01', exitDate: '-', status: '在场', evalStatus: '数据缺失', completeness: 78, updateTime: '2026-07-08 17:45:00', certificate: '普通工种上岗证', safetyStatus: '已培训且合格' },
  { id: '4', name: '赵铁柱', sex: '男', idCard: '2101031975******78', jobType: '电焊工', team: '机电安装队', enterprise: '上海建工集团股份有限公司', project: '城市绿心剧院机电安装项目', entryDate: '2026-01-05', exitDate: '2026-07-05', status: '已退场', evalStatus: '可评价', completeness: 85, updateTime: '2026-07-05 16:20:11', certificate: '熔化焊接与热切割作业证', safetyStatus: '已培训且合格' },
  { id: '5', name: '孙红梅', sex: '女', idCard: '5101051985******45', jobType: '信号工', team: '塔吊班组', enterprise: '中铁十一局集团有限公司', project: '北京轨道交通28号线项目', entryDate: '2026-04-10', exitDate: '-', status: '在场', evalStatus: '暂停评价', completeness: 88, updateTime: '2026-07-09 11:00:22', certificate: '起重信号司索工特种证', safetyStatus: '已培训且合格' }
];

const INITIAL_ATTENDANCE = [
  { name: '张建国', idCard: '3701021980******56', date: '2026-07-09', clockIn: '07:15:32', clockOut: '17:35:10', status: '正常', location: '1号大门闸机', deviceId: 'GATE-01' },
  { name: '李强', idCard: '4201061988******90', date: '2026-07-09', clockIn: '07:22:04', clockOut: '17:40:55', status: '正常', location: '2号大门闸机', deviceId: 'GATE-02' },
  { name: '王朝阳', idCard: '1301021992******67', date: '2026-07-09', clockIn: '07:45:12', clockOut: '--:--:--', status: '缺卡', location: '1号大门闸机', deviceId: 'GATE-01' }
];

const INITIAL_EMPLOYMENT = [
  { name: '张建国', idCard: '3701021980******56', project: '北京CBD东区超高层项目', enterprise: '中建一局集团有限公司', team: '钢筋一班', jobType: '钢筋工', entryDate: '2026-01-10', exitDate: '-' },
  { name: '李强', idCard: '4201061988******90', project: '北京CBD东区超高层项目', enterprise: '中建一局集团有限公司', team: '架子二班', jobType: '架子工', entryDate: '2026-02-15', exitDate: '-' }
];

// AI Pending verification records
const INITIAL_AI_TO_CONFIRM = [
  { id: 'c1', worker: '张建国', idCard: '3701021980******56', type: '体检记录', detail: '体检结论：合格；心电图无明显异常。北京市朝阳区第二医院，2026-07-08', conf: 99.4, time: '2026-07-09 11:20:15', associateStatus: '匹配成功', status: '待确认', fileId: 'f1', model: 'Gemini-2.0-Flash-OCR', cost: '0.4s' },
  { id: 'c2', worker: '王朝阳', idCard: '1301021992******67', type: '处罚记录', detail: '因进入起吊区未戴安全帽被项目部处以罚款200元。2026-07-05', conf: 95.8, time: '2026-07-05 09:12:44', associateStatus: '匹配成功', status: '待确认', fileId: 'f2', model: 'DeepSeek-VL-Coder', cost: '0.6s' }
];

// Initial Manual Ledgers
const INITIAL_MANUAL_DATA = {
  exam: [
    { id: 'e1', name: '张建国', idCard: '3701021980******56', project: '北京CBD东区超高层项目', date: '2026-07-08', institution: '朝阳区第二医院', result: '合格', recorder: '管理员', mode: '手工录入', attachment: '20260708_体检报告.pdf', remarks: '高空特种作业合格' },
    { id: 'e2', name: '李强', idCard: '4201061988******90', project: '北京CBD东区超高层项目', date: '2026-06-15', institution: '建工疗养院体检中心', result: '合格', recorder: '李工', mode: '导入同步', attachment: '20260615_体检单.pdf', remarks: '无高空禁忌' }
  ],
  rewards: [
    { id: 'r1', name: '李强', idCard: '4201061988******90', title: '季度百日安全无事故先进个人', level: '项目部级', money: '500', date: '2026-07-08', agency: '中建一局项目部', recorder: '系统自动', mode: 'AI识别', attachment: '安全证书.jpg', remarks: '履约优良' }
  ],
  punishments: [
    { id: 'p1', name: '王朝阳', idCard: '1301021992******67', reason: '未佩戴安全帽进入施工基坑', action: '通报批评并罚款', money: '200', date: '2026-07-05', recorder: '刘安检', mode: '手工录入', attachment: '罚金凭单.pdf', remarks: '红线违规扣减20分' }
  ],
  trainings: [
    { id: 't1', name: '张建国', idCard: '3701021980******56', course: '夏季防暑降温与高空坠落实操演练', hours: '4', result: '合格', date: '2026-07-02', instructor: '赵安全员', recorder: '管理员', mode: '手工录入', attachment: '签到表.pdf', remarks: '安全三级培训合格' }
  ],
  certs: [
    { id: 'cert1', name: '张建国', idCard: '3701021980******56', certName: '特种作业操作证(钢筋工)', level: '省级', date: '2025-10-12', agency: '山东省建设厅', recorder: '管理员', mode: '手工录入', attachment: '特种证件扫描.pdf', remarks: '已通过真伪校验' }
  ],
  honors: [
    { id: 'h1', name: '张建国', idCard: '3701021980******56', honorName: '首都杰出工匠劳动模范', level: '省级', date: '2026-05-01', agency: '北京市总工会', recorder: '管理员', mode: '手动录入', attachment: '工匠模范证书.jpg', remarks: '重磅省级表彰' }
  ]
};

// Initial History Records
const INITIAL_LOGS = [
  { id: 'l1', method: 'AI智能解析', type: '体检记录', target: '张建国', status: '成功', duration: '0.4s', recorder: '管理员', time: '2026-07-09 11:20:15', source: '附件扫描' },
  { id: 'l2', method: 'API自动同步', type: '考勤信息', target: '班组考勤汇总 (285人)', status: '成功', duration: '1.2s', recorder: '系统自动', time: '2026-07-09 10:00:00', source: '闸机接口' },
  { id: 'l3', method: '手工录入', type: '荣誉记录', target: '张建国', status: '成功', duration: '0.2s', recorder: '管理员', time: '2026-07-09 09:30:00', source: '平台端' },
  { id: 'l4', method: 'Excel批量导入', type: '体检记录', target: '李强 等12人', status: '成功', duration: '0.8s', recorder: '李工', time: '2026-07-08 15:40:00', source: '表格上传' }
];

export default function DataAcquisitionCenter({ triggerNotification }) {
  // Navigation & Sub-Tabs
  const [activeTab, setActiveTab] = useState('realname') // realname, ai, pending, manual, history
  const [realnameSubTab, setRealnameSubTab] = useState('personnel') // personnel, attendance, teams, enterprises, employment
  const [manualSubTab, setManualSubTab] = useState('exam') // exam, rewards, punishments, trainings, certs, honors

  // Search & Collapsible Filters
  const [searchKeyword, setSearchKeyword] = useState('')
  const [isAdvancedSearchOpen, setIsAdvancedSearchOpen] = useState(false)
  const [filterProject, setFilterProject] = useState('ALL')
  const [filterStatus, setFilterStatus] = useState('ALL')

  // Data States
  const [workers, setWorkers] = useState(INITIAL_WORKERS)
  const [aiToConfirm, setAiToConfirm] = useState(INITIAL_AI_TO_CONFIRM)
  const [manualData, setManualData] = useState(INITIAL_MANUAL_DATA)
  const [historyLogs, setHistoryLogs] = useState(INITIAL_LOGS)

  // Drawer states
  const [isWorkerDrawerOpen, setIsWorkerDrawerOpen] = useState(false)
  const [selectedWorker, setSelectedWorker] = useState(null)
  
  const [isAddManualDrawerOpen, setIsAddManualDrawerOpen] = useState(false)
  const [editingManualRecord, setEditingManualRecord] = useState(null)

  // AI Upload & Wizard States
  const [aiWizardStep, setAiWizardStep] = useState(1) // 1=Upload, 2=OCR, 3=Associate & Verify
  const [isOcrLoading, setIsOcrLoading] = useState(false)
  const [dragActive, setDragActive] = useState(false)
  const fileInputRef = useRef(null)

  // Zoom / PDF preview mock state
  const [pdfZoom, setPdfZoom] = useState(100)
  const [pdfPage, setPdfPage] = useState(1)

  // Temporary uploaded record state
  const [uploadedRecord, setUploadedRecord] = useState({
    fileName: '建筑工人体检报告_张建国.pdf',
    type: '体检记录',
    model: 'Gemini-2.0-Flash-OCR',
    cost: '0.45s',
    confidence: 99.2,
    data: {
      name: '张建国',
      idCard: '3701021980******56',
      date: '2026-07-09',
      project: '北京CBD东区超高层项目',
      institution: '北京市朝阳区第二医院',
      result: '合格(具备高空及电气特种作业资格)',
      remarks: '血压120/80，健康状况优良'
    },
    association: {
      name: '张建国',
      idCard: '3701021980******56',
      project: '北京CBD东区超高层项目',
      team: '钢筋一班',
      enterprise: '中建一局集团',
      matchRate: 100,
      status: '匹配成功'
    }
  })

  // Selected multi-check boxes
  const [selectedRowIds, setSelectedRowIds] = useState([])

  // Add/Edit Form State
  const [manualForm, setManualForm] = useState({
    name: '张建国',
    project: '北京CBD东区超高层项目',
    date: '2026-07-09',
    institution: '',
    result: '合格',
    remarks: '',
    title: '',
    level: '项目部级',
    money: '',
    reason: '',
    action: '',
    course: '',
    hours: '',
    instructor: '',
    certName: '',
    honorName: '',
    agency: ''
  })

  // Collapsed search filter logic
  const handleQuery = () => {
    triggerNotification('条件过滤检索中...', 'info')
  }

  const handleReset = () => {
    setSearchKeyword('')
    setFilterProject('ALL')
    setFilterStatus('ALL')
    triggerNotification('检索条件已重置。', 'info')
  }

  // Double Column verify save
  const handleConfirmOcrEntry = () => {
    const targetType = uploadedRecord.type
    const resolvedIdCard = uploadedRecord.data.idCard

    if (targetType === '体检记录') {
      const newRec = {
        id: `e_${Date.now()}`,
        name: uploadedRecord.data.name,
        idCard: resolvedIdCard,
        project: uploadedRecord.data.project,
        date: uploadedRecord.data.date,
        institution: uploadedRecord.data.institution,
        result: uploadedRecord.data.result,
        recorder: '管理员',
        mode: 'AI识别',
        attachment: uploadedRecord.fileName,
        remarks: uploadedRecord.data.remarks
      }
      setManualData(prev => ({ ...prev, exam: [newRec, ...prev.exam] }))
    } else if (targetType === '奖励记录') {
      const newRec = {
        id: `r_${Date.now()}`,
        name: uploadedRecord.data.name,
        idCard: resolvedIdCard,
        title: 'AI识别奖励',
        level: '项目部级',
        money: '200',
        date: uploadedRecord.data.date,
        agency: uploadedRecord.data.institution,
        recorder: '管理员',
        mode: 'AI识别',
        attachment: uploadedRecord.fileName,
        remarks: uploadedRecord.data.remarks
      }
      setManualData(prev => ({ ...prev, rewards: [newRec, ...prev.rewards] }))
    }

    // Append to logs
    const newLog = {
      id: `l_${Date.now()}`,
      method: 'AI智能解析',
      type: targetType,
      target: uploadedRecord.data.name,
      status: '成功',
      duration: uploadedRecord.cost,
      recorder: '管理员',
      time: new Date().toLocaleString(),
      source: '附件扫描'
    }
    setHistoryLogs(prev => [newLog, ...prev])

    triggerNotification(`AI 结构化记录已成功入库并同步！`, 'success')
    setAiWizardStep(1)
  }

  // Batch action handlers
  const handleBatchConfirm = () => {
    if (selectedRowIds.length === 0) {
      triggerNotification('请先勾选需要入库的AI待确认记录', 'warning')
      return
    }
    
    // Simulate batch confirm
    setAiToConfirm(prev => prev.filter(item => {
      const isChecked = selectedRowIds.includes(item.id)
      if (isChecked) {
        // Append to manual exam ledger
        const newRec = {
          id: `e_${Date.now()}_${Math.random()}`,
          name: item.worker,
          idCard: item.idCard,
          project: '北京CBD东区超高层项目',
          date: '2026-07-09',
          institution: '朝阳区第二医院',
          result: '合格',
          recorder: '管理员',
          mode: 'AI智能识别',
          attachment: 'AI_OCR_document.pdf',
          remarks: '批量确认识别结果'
        }
        setManualData(prev => ({ ...prev, exam: [newRec, ...prev.exam] }))
      }
      return !isChecked
    }))

    setSelectedRowIds([])
    triggerNotification('选中的 AI 提取数据已成功批量确认入库！', 'success')
  }

  const handleBatchReject = () => {
    if (selectedRowIds.length === 0) {
      triggerNotification('请先勾选需要驳回的记录', 'warning')
      return
    }
    if (confirm(`确认要批量驳回选中的 ${selectedRowIds.length} 项 AI 识别结果吗？`)) {
      setAiToConfirm(prev => prev.filter(item => !selectedRowIds.includes(item.id)))
      setSelectedRowIds([])
      triggerNotification('选中的识别记录已驳回。', 'warning')
    }
  }

  // Worker detail drawer suggestion generator
  const getWorkerSuggestions = (worker) => {
    if (worker.completeness >= 90) {
      return {
        missing: ['健康档案'],
        suggest: '该工人画像极其完整。仅需定期核验季度体检状态，持续跟踪每日出勤考勤打卡。'
      }
    } else if (worker.completeness >= 80) {
      return {
        missing: ['奖励记录', '体检报告'],
        suggest: '建议补充体检诊断佐证扫描件。如有班组红榜或季度安全奖，建议上传同步以提升履约权重分。'
      }
    } else {
      return {
        missing: ['体检合格报告', '职业病培训课时', '安全奖惩记录'],
        suggest: '画像数据完整度偏低！请尽快在“AI采集中心”上传入场体检扫描件，并录入其特种三级培训签到成绩。'
      }
    }
  }

  // Upload handlers
  const handleDrag = (e) => {
    e.preventDefault()
    e.stopPropagation()
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true)
    } else if (e.type === "dragleave") {
      setDragActive(false)
    }
  }

  const handleDrop = (e) => {
    e.preventDefault()
    e.stopPropagation()
    setDragActive(false)
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      startOcrSimulation(e.dataTransfer.files[0].name)
    }
  }

  const handleFileInput = (e) => {
    if (e.target.files && e.target.files[0]) {
      startOcrSimulation(e.target.files[0].name)
    }
  }

  const startOcrSimulation = (fileName) => {
    setIsOcrLoading(true)
    setAiWizardStep(2)
    triggerNotification('文档上传成功，AI 神经网络大模型解析提取中...', 'info')
    
    setTimeout(() => {
      setIsOcrLoading(false)
      setAiWizardStep(3)
      setUploadedRecord(prev => ({
        ...prev,
        fileName: fileName,
        type: fileName.includes('体检') ? '体检记录' : fileName.includes('奖') ? '奖励记录' : '培训记录',
        data: {
          ...prev.data,
          name: fileName.includes('李强') ? '李强' : '张建国',
          idCard: fileName.includes('李强') ? '4201061988******90' : '3701021980******56',
          result: fileName.includes('李强') ? '合格(无高处架子工禁忌)' : '合格(具备高空及电气特种作业资格)'
        },
        association: {
          ...prev.association,
          name: fileName.includes('李强') ? '李强' : '张建国',
          idCard: fileName.includes('李强') ? '4201061988******90' : '3701021980******56',
          team: fileName.includes('李强') ? '架子二班' : '钢筋一班'
        }
      }))
      triggerNotification('AI OCR 及结构化解析翻译完成！置信度 99.2%', 'success')
    }, 2000)
  }

  // Manual records Add/Save
  const openAddManualRecord = (record = null) => {
    if (record) {
      setEditingManualRecord(record)
      setManualForm({ ...record })
    } else {
      setEditingManualRecord(null)
      setManualForm({
        name: '张建国',
        project: '北京CBD东区超高层项目',
        date: '2026-07-09',
        institution: '北京市朝阳区第二医院',
        result: '合格',
        remarks: '',
        title: '月度安全标兵称号',
        level: '项目部级',
        money: '300',
        reason: '进入起吊红线未带防护帽',
        action: '警告教育并扣减劳务积分',
        course: '高空坠落逃生演练',
        hours: '4',
        instructor: '雷安全长',
        certName: '二级焊接工艺特种证',
        honorName: '北京市总工会工匠劳动模范',
        agency: '北京市建协'
      })
    }
    setIsAddManualDrawerOpen(true)
  }

  const handleSaveManualForm = (e) => {
    e.preventDefault()
    const workerObj = INITIAL_WORKERS.find(w => w.name === manualForm.name)
    const idCard = workerObj ? workerObj.idCard : '3701021980******56'

    if (editingManualRecord) {
      setManualData(prev => ({
        ...prev,
        [manualSubTab]: prev[manualSubTab].map(item => item.id === editingManualRecord.id ? { ...manualForm, id: item.id, idCard } : item)
      }))
      triggerNotification('台账数据更新成功。', 'success')
    } else {
      const newRec = {
        ...manualForm,
        id: `rec_${Date.now()}`,
        idCard,
        recorder: '管理员',
        mode: '手工录入',
        attachment: 'manual_attached_doc.pdf'
      }
      setManualData(prev => ({
        ...prev,
        [manualSubTab]: [newRec, ...prev[manualSubTab]]
      }))
      triggerNotification('新增台账记录成功！', 'success')
    }
    setIsAddManualDrawerOpen(false)
  }

  const handleDeleteManualRecord = (id) => {
    if (confirm('确认删除此条人工录入的数据记录？')) {
      setManualData(prev => ({
        ...prev,
        [manualSubTab]: prev[manualSubTab].filter(item => item.id !== id)
      }))
      triggerNotification('台账记录已删除。', 'warning')
    }
  }

  return (
    <div className="flex-grow flex flex-col gap-6">
      
      {/* 1. Header Title */}
      <div className="bg-white border border-border-gray rounded p-5 flex flex-col md:flex-row md:items-center justify-between gap-4 shrink-0 shadow-sm">
        <div>
          <h2 className="text-xl font-bold text-text-dark flex items-center gap-2">
            <Zap className="h-5.5 w-5.5 text-primary" />
            评价数据采集中心
            <span className="text-xs font-normal text-[#11356A] bg-[#11356A]/5 border border-[#11356A]/20 px-2 py-0.5 rounded">
              国企智慧工地标准 Demo
            </span>
          </h2>
          <p className="text-xs text-text-secondary mt-1.5">
            负责系统所需实名制接口、AI结构化识别、人工补登等所有前置指标台账的入库流转与校验核对。
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => triggerNotification('接口就绪：数据流连接正常', 'success')}
            className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 border border-slate-200 rounded font-bold text-xs text-text-dark flex items-center gap-1 cursor-pointer transition-all"
          >
            <RefreshCw className="h-3 w-3 animate-spin text-primary" />
            联调监控中
          </button>
        </div>
      </div>

      {/* 2. Top KPI Cards (5 Columns) */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-6 shrink-0">
        {[
          { title: '累计工人数', val: '1,265 人', change: '+12% 同比上月', time: '今日 12:00', icon: <Users className="h-5 w-5 text-primary" /> },
          { title: '今日同步数量', val: '45 条', change: '+32% 同比昨日', time: '10分钟前', icon: <UserCheck className="h-5 w-5 text-success-green" /> },
          { title: 'AI识别数量', val: '86 件', change: '+15.2% 本月环比', time: '今日 11:20', icon: <Cpu className="h-5 w-5 text-indigo-500" /> },
          { title: '待确认数量', val: `${aiToConfirm.length} 件`, change: '需尽快人工校对', time: '今日 14:00', icon: <AlertTriangle className="h-5 w-5 text-warning-orange" /> },
          { title: '数据完整率', val: '89.4%', change: '健康度: 优秀', time: '模型每小时轮询', icon: <Activity className="h-5 w-5 text-[#52C41A]" /> }
        ].map((kpi, idx) => (
          <div key={idx} className="bg-white border border-border-gray p-4 rounded-lg shadow-sm flex flex-col justify-between hover:shadow-md transition-all border-l-4 border-l-primary">
            <div className="flex items-start justify-between">
              <div className="text-[11px] text-text-secondary font-bold uppercase tracking-wider">{kpi.title}</div>
              <div className="bg-slate-50 p-1.5 rounded">{kpi.icon}</div>
            </div>
            <div className="mt-2.5">
              <div className="text-xl font-black text-text-dark font-mono leading-none">{kpi.val}</div>
              <div className="flex items-center justify-between text-[10px] text-text-secondary mt-2">
                <span className="font-semibold text-primary">{kpi.change}</span>
                <span>{kpi.time}</span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* 3. Primary Tabs Navigation */}
      <div className="bg-white border border-border-gray rounded shadow-sm flex flex-col min-h-[500px] flex-grow">
        
        {/* Navigation tabs */}
        <div className="flex border-b border-border-gray bg-slate-50 px-4 pt-3 shrink-0">
          {[
            { id: 'realname', label: '实名制数据 (同步)', icon: <ShieldCheck className="h-4 w-4" /> },
            { id: 'ai', label: 'AI智能解析 (OCR)', icon: <Cpu className="h-4 w-4" /> },
            { id: 'pending', label: '待确认数据', icon: <AlertTriangle className="h-4 w-4" />, count: aiToConfirm.length },
            { id: 'manual', label: '人工数据维护', icon: <Edit className="h-4 w-4" /> },
            { id: 'history', label: '采集记录历史', icon: <History className="h-4 w-4" /> }
          ].map(t => (
            <button
              key={t.id}
              onClick={() => setActiveTab(t.id)}
              className={`flex items-center gap-1.5 px-4.5 py-3 text-xs font-bold border-t-2 border-x transition-all duration-150 cursor-pointer ${
                activeTab === t.id
                  ? 'bg-white border-x-border-gray border-t-primary text-primary -mb-[1px] relative z-10 shadow-[0_-2px_10px_rgba(0,0,0,0.03)]'
                  : 'bg-transparent border-transparent text-text-secondary hover:text-primary hover:bg-slate-100'
              }`}
            >
              {t.icon}
              <span>{t.label}</span>
              {t.count !== undefined && t.count > 0 && (
                <span className="ml-1 bg-warning-orange text-white text-[9px] px-1.5 py-0.2 rounded-full leading-none font-bold">
                  {t.count}
                </span>
              )}
            </button>
          ))}
        </div>

        {/* Dynamic Panels */}
        <div className="p-6 flex-grow flex flex-col min-h-[380px]">
          
          {/* ==========================================
              TAB 1: 实名制数据台账 (Auto Sync)
              ========================================== */}
          {activeTab === 'realname' && (
            <div className="flex-grow flex flex-col gap-6">
              
              {/* Secondary sub-tabs */}
              <div className="flex bg-slate-100 p-1 rounded-lg border border-slate-200 self-start shrink-0">
                {[
                  { id: 'personnel', label: '人员信息' },
                  { id: 'attendance', label: '考勤信息' },
                  { id: 'employment', label: '用工信息' }
                ].map(sub => (
                  <button
                    key={sub.id}
                    onClick={() => setRealnameSubTab(sub.id)}
                    className={`px-3 py-1 text-[11px] font-bold rounded transition-all cursor-pointer ${
                      realnameSubTab === sub.id ? 'bg-[#11356A] text-white shadow-sm' : 'text-text-secondary hover:text-primary'
                    }`}
                  >
                    {sub.label}
                  </button>
                ))}
              </div>

              {/* Table search filter bar */}
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-50 p-4 border border-border-gray rounded shrink-0">
                <div className="flex items-center gap-4 flex-wrap">
                  <div className="relative">
                    <input
                      type="text"
                      value={searchKeyword}
                      onChange={(e) => setSearchKeyword(e.target.value)}
                      placeholder="姓名 / 班组 / 身份证..."
                      className="bg-white border border-slate-300 rounded px-2.5 pl-8 py-1 text-xs text-text-dark w-48"
                    />
                    <Search className="absolute left-2.5 top-2 h-3.5 w-3.5 text-slate-400" />
                  </div>

                  <button
                    onClick={() => setIsAdvancedSearchOpen(!isAdvancedSearchOpen)}
                    className="flex items-center gap-1 text-xs text-text-secondary font-bold hover:text-primary cursor-pointer"
                  >
                    <Filter className="h-3 w-3" />
                    <span>高级筛选</span>
                    {isAdvancedSearchOpen ? <ChevronUp className="h-3.5 w-3.5" /> : <ChevronDown className="h-3.5 w-3.5" />}
                  </button>
                </div>

                <div className="flex items-center gap-2">
                  <button onClick={handleQuery} className="px-3.5 py-1 bg-[#11356A] hover:bg-primary-hover text-white text-xs font-bold rounded shadow-sm cursor-pointer">查询</button>
                  <button onClick={handleReset} className="px-3.5 py-1 bg-white hover:bg-slate-50 text-text-dark border border-slate-300 text-xs font-bold rounded shadow-sm cursor-pointer">重置</button>
                </div>
              </div>

              {/* Advanced search collapsible panel */}
              {isAdvancedSearchOpen && (
                <div className="bg-slate-50 border border-slate-200 rounded p-4 grid grid-cols-2 md:grid-cols-4 gap-4 animate-slide-down shrink-0 text-xs">
                  <div>
                    <label className="block font-bold text-text-secondary mb-1">参建工程项目</label>
                    <select
                      value={filterProject}
                      onChange={(e) => setFilterProject(e.target.value)}
                      className="w-full bg-white border border-slate-300 rounded px-2 py-1"
                    >
                      <option value="ALL">全部项目</option>
                      <option value="CBD">北京CBD东区超高层项目</option>
                      <option value="28号线">北京轨道交通28号线项目</option>
                    </select>
                  </div>
                  <div>
                    <label className="block font-bold text-text-secondary mb-1">评价状态</label>
                    <select
                      value={filterStatus}
                      onChange={(e) => setFilterStatus(e.target.value)}
                      className="w-full bg-white border border-slate-300 rounded px-2 py-1"
                    >
                      <option value="ALL">全部状态</option>
                      <option value="可评价">可评价</option>
                      <option value="数据缺失">数据缺失</option>
                      <option value="暂停评价">暂停评价</option>
                    </select>
                  </div>
                </div>
              )}

              {/* Data Table */}
              <div className="flex-grow border border-border-gray rounded-lg overflow-x-auto">
                {realnameSubTab === 'personnel' && (
                  <table className="b-table text-xs">
                    <thead>
                      <tr>
                        <th>姓名</th>
                        <th>身份证号(脱敏)</th>
                        <th>工种</th>
                        <th>班组</th>
                        <th>所属企业</th>
                        <th>所属项目</th>
                        <th>进场打卡日期</th>
                        <th>在场状态</th>
                        <th>评价状态</th>
                        <th className="w-24">数据完整率</th>
                        <th>更新时间</th>
                        <th>来源</th>
                        <th className="text-right">操作</th>
                      </tr>
                    </thead>
                    <tbody>
                      {workers.map(w => (
                        <tr key={w.id} className="hover:bg-slate-50 transition-colors">
                          <td className="font-bold text-text-dark">
                            <div className="flex items-center gap-2">
                              <span className="h-6 w-6 rounded-full bg-slate-200 text-primary flex items-center justify-center font-black text-[10px]">
                                {w.name[0]}
                              </span>
                              {w.name}
                            </div>
                          </td>
                          <td className="font-mono">{w.idCard}</td>
                          <td>{w.jobType}</td>
                          <td>{w.team}</td>
                          <td className="max-w-[150px] truncate" title={w.enterprise}>{w.enterprise}</td>
                          <td className="max-w-[150px] truncate" title={w.project}>{w.project}</td>
                          <td className="font-mono">{w.entryDate}</td>
                          <td>
                            <span className={`inline-flex items-center gap-1 px-1.5 py-0.2 rounded text-[10px] font-bold ${
                              w.status === '在场' ? 'bg-emerald-50 text-success-green border border-emerald-200' : 'bg-slate-50 text-slate-400 border border-slate-200'
                            }`}>
                              {w.status}
                            </span>
                          </td>
                          <td>
                            <span className={`inline-flex items-center gap-1 px-1.5 py-0.2 rounded text-[10px] font-bold ${
                              w.evalStatus === '可评价' ? 'bg-emerald-50 text-success-green border border-emerald-200' :
                              w.evalStatus === '数据缺失' ? 'bg-orange-50 text-warning-orange border border-orange-200' : 'bg-red-50 text-[#F5222D] border border-red-100'
                            }`}>
                              {w.evalStatus}
                            </span>
                          </td>
                          <td>
                            <div className="flex items-center gap-1">
                              <div className="w-12 bg-slate-100 rounded-full h-1 border">
                                <div className="bg-[#11356A] h-1 rounded-full" style={{ width: `${w.completeness}%` }}></div>
                              </div>
                              <span className="font-mono text-[9px] font-bold">{w.completeness}%</span>
                            </div>
                          </td>
                          <td className="text-text-secondary font-mono">{w.updateTime.split(' ')[0]}</td>
                          <td>
                            <span className="bg-blue-50 text-[#11356A] border border-blue-100 px-1 py-0.2 rounded text-[9px] font-black">
                              实名制
                            </span>
                          </td>
                          <td className="text-right">
                            <button
                              onClick={() => {
                                setSelectedWorker(w)
                                setIsWorkerDrawerOpen(true)
                              }}
                              className="text-primary hover:text-primary-hover font-bold text-xs bg-primary/5 border border-primary/20 px-2 py-1 rounded cursor-pointer"
                            >
                              查看
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )}

                {realnameSubTab === 'attendance' && (
                  <table className="b-table text-xs">
                    <thead>
                      <tr>
                        <th>姓名</th>
                        <th>身份证号</th>
                        <th>考勤日期</th>
                        <th>签到时间</th>
                        <th>签退时间</th>
                        <th>位置</th>
                        <th>设备ID</th>
                        <th>考勤结论</th>
                      </tr>
                    </thead>
                    <tbody>
                      {INITIAL_ATTENDANCE.map((a, i) => (
                        <tr key={i}>
                          <td className="font-bold text-text-dark">{a.name}</td>
                          <td className="font-mono">{a.idCard}</td>
                          <td className="font-mono">{a.date}</td>
                          <td className="font-mono text-success-green font-bold">{a.clockIn}</td>
                          <td className="font-mono text-text-secondary">{a.clockOut}</td>
                          <td>{a.location}</td>
                          <td className="font-mono text-text-secondary">{a.deviceId}</td>
                          <td>
                            <span className="bg-emerald-50 text-success-green border border-emerald-200 px-1.5 py-0.5 rounded text-[10px] font-bold">
                              {a.status}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )}

                {realnameSubTab === 'employment' && (
                  <table className="b-table text-xs">
                    <thead>
                      <tr>
                        <th>姓名</th>
                        <th>身份证号</th>
                        <th>参建分包企业</th>
                        <th>班组</th>
                        <th>工种</th>
                        <th>当前进场项目</th>
                        <th>进场时间</th>
                      </tr>
                    </thead>
                    <tbody>
                      {INITIAL_EMPLOYMENT.map((e, i) => (
                        <tr key={i}>
                          <td className="font-bold text-text-dark">{e.name}</td>
                          <td className="font-mono">{e.idCard}</td>
                          <td>{e.enterprise}</td>
                          <td>{e.team}</td>
                          <td>{e.jobType}</td>
                          <td className="font-semibold text-text-dark">{e.project}</td>
                          <td className="font-mono text-text-secondary">{e.entryDate}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )}
              </div>

              {/* Table Pagination */}
              <div className="flex items-center justify-between text-xs text-text-secondary pt-2 shrink-0">
                <span>每页 10 条，当前显示第 1-5 条</span>
                <div className="flex items-center gap-1">
                  <button className="h-6 w-6 border rounded bg-white flex items-center justify-center cursor-pointer hover:bg-slate-50"><ChevronLeft className="h-3 w-3" /></button>
                  <button className="h-6 w-6 border rounded bg-[#11356A] text-white flex items-center justify-center font-bold">1</button>
                  <button className="h-6 w-6 border rounded bg-white flex items-center justify-center cursor-pointer hover:bg-slate-50"><ChevronRight className="h-3 w-3" /></button>
                </div>
              </div>

            </div>
          )}

          {/* ==========================================
              TAB 2: AI智能采集 (OCR wizard flow)
              ========================================== */}
          {activeTab === 'ai' && (
            <div className="flex-grow flex flex-col gap-6">
              
              {/* Wizard steps bar */}
              <div className="bg-slate-50 p-4 border border-border-gray rounded-lg flex justify-between items-center shrink-0">
                {[
                  { step: 1, label: '上传原始单证' },
                  { step: 2, label: 'AI智能OCR识别' },
                  { step: 3, label: '关联核算入库' }
                ].map(st => (
                  <div key={st.step} className="flex items-center gap-2">
                    <span className={`h-6 w-6 rounded-full flex items-center justify-center text-xs font-black shadow-sm ${
                      aiWizardStep === st.step ? 'bg-[#11356A] text-white animate-pulse' :
                      aiWizardStep > st.step ? 'bg-success-green text-white' : 'bg-slate-200 text-slate-500'
                    }`}>
                      {aiWizardStep > st.step ? <Check className="h-3.5 w-3.5" /> : st.step}
                    </span>
                    <span className={`text-xs font-bold ${aiWizardStep === st.step ? 'text-[#11356A]' : 'text-text-secondary'}`}>
                      {st.label}
                    </span>
                    {st.step < 3 && <div className="h-[1px] w-12 md:w-24 bg-slate-300"></div>}
                  </div>
                ))}
              </div>

              {/* Step 1: Upload Panel */}
              {aiWizardStep === 1 && (
                <div className="flex-grow flex flex-col items-center justify-center p-8 border-2 border-dashed border-slate-300 rounded-lg hover:border-primary transition-all min-h-[300px]"
                     onDragEnter={handleDrag}
                     onDragOver={handleDrag}
                     onDragLeave={handleDrag}
                     onDrop={handleDrop}
                     onClick={() => fileInputRef.current.click()}
                >
                  <input ref={fileInputRef} type="file" className="hidden" accept=".pdf,.png,.jpg,.jpeg,.doc,.docx" onChange={handleFileInput} />
                  <FileUp className="h-14 w-14 text-slate-400 mb-3 animate-bounce" />
                  <h4 className="text-sm font-bold text-text-dark">拖拽附件，或点击此处选择文件上传</h4>
                  <p className="text-[11px] text-text-secondary mt-1">支持体检报告、培训表彰、荣誉证书、Excel、ZIP等多格式，AI自动提取分类</p>
                </div>
              )}

              {/* Step 2: OCR Loading */}
              {aiWizardStep === 2 && isOcrLoading && (
                <div className="flex-grow flex flex-col items-center justify-center p-8 min-h-[300px]">
                  <RefreshCw className="h-10 w-10 text-primary animate-spin mb-4" />
                  <h4 className="text-sm font-bold text-text-dark">AI 智能大模型读取附件、翻译理解结构化字段中...</h4>
                  <p className="text-xs text-text-secondary mt-1">正通过 {uploadedRecord.model} 进行光学识别及合规置信度打分</p>
                </div>
              )}

              {/* Step 3: Split-Screen OCR check */}
              {aiWizardStep === 3 && (
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 flex-grow">
                  
                  {/* Left Column: Attachment PDF/Image preview */}
                  <div className="lg:col-span-5 bg-slate-100 border border-slate-200 rounded-lg p-4 flex flex-col justify-between max-h-[500px]">
                    <div className="flex items-center justify-between border-b pb-2 mb-3">
                      <span className="text-xs font-bold text-text-dark flex items-center gap-1.5">
                        <FileText className="h-4 w-4 text-primary" />
                        {uploadedRecord.fileName}
                      </span>
                      <div className="flex items-center gap-1">
                        <button onClick={() => setPdfZoom(z => Math.max(50, z - 25))} className="p-1 border rounded bg-white hover:bg-slate-50 cursor-pointer text-xs font-bold">-</button>
                        <span className="text-[10px] font-mono font-bold px-1.5">{pdfZoom}%</span>
                        <button onClick={() => setPdfZoom(z => Math.min(200, z + 25))} className="p-1 border rounded bg-white hover:bg-slate-50 cursor-pointer text-xs font-bold">+</button>
                      </div>
                    </div>

                    {/* PDF Mock Visual Canvas */}
                    <div className="flex-1 bg-white border rounded shadow-inner p-4 relative overflow-auto flex items-center justify-center">
                      <div className="border border-slate-300 p-6 shadow-sm text-[10px] text-left text-slate-400 space-y-4 max-w-sm w-full" style={{ transform: `scale(${pdfZoom / 100})` }}>
                        <div className="text-center font-bold text-sm text-text-dark border-b pb-2 uppercase tracking-wide">
                          北京市职业健康监护报告单
                        </div>
                        <div className="grid grid-cols-2 gap-2 border-b pb-2">
                          <div className="border border-red-400 p-0.5 relative">
                            姓名：张建国
                            <span className="absolute -top-3.5 left-0 text-[8px] bg-red-400 text-white px-1 py-0.1 font-bold rounded">AI: 99%</span>
                          </div>
                          <div>科室：高处作业体检科</div>
                          <div className="border border-red-400 p-0.5 relative">
                            日期：2026-07-09
                            <span className="absolute -top-3.5 left-0 text-[8px] bg-red-400 text-white px-1 py-0.1 font-bold rounded">AI: 97%</span>
                          </div>
                          <div>机构：朝阳区第二医院</div>
                        </div>
                        <div className="space-y-1">
                          <div className="font-bold text-[10px] text-text-dark">临床诊断意见：</div>
                          <div className="text-[10px] text-emerald-600 font-bold bg-emerald-50 p-1 border border-emerald-100 rounded">
                            未见禁忌症。心率72次/分，胸透合格。准予参建高空建筑特种施工作业。
                          </div>
                        </div>
                        <div className="text-right pt-6">核定章：朝阳区第二医院体检中心</div>
                      </div>
                    </div>

                    <div className="flex items-center justify-between text-xs pt-3 border-t">
                      <span>页码：{pdfPage} / 1</span>
                      <button className="text-primary hover:underline flex items-center gap-0.5">
                        <DownloadCloud className="h-3.5 w-3.5" />
                        下载原始文件
                      </button>
                    </div>
                  </div>

                  {/* Right Column: AI Fields form & Match */}
                  <div className="lg:col-span-7 bg-white border border-border-gray rounded-lg p-5 flex flex-col gap-5 shadow-sm max-h-[500px] overflow-y-auto">
                    
                    {/* Header metrics */}
                    <div className="bg-indigo-50 border border-indigo-100 p-3 rounded-lg flex items-center justify-between text-xs shrink-0">
                      <div className="flex items-center gap-1.5 text-[#11356A] font-bold">
                        <Sparkles className="h-4 w-4 text-indigo-500 animate-pulse" />
                        <span>文档类别：{uploadedRecord.type} (AI自动识别)</span>
                      </div>
                      <div className="flex items-center gap-3">
                        <span className="text-[10px] font-bold text-text-secondary">耗时: {uploadedRecord.cost}</span>
                        <span className="text-success-green font-black">置信度: {uploadedRecord.confidence}%</span>
                      </div>
                    </div>

                    {/* AI auto association */}
                    <div className="bg-slate-50 p-4 border border-slate-200 rounded-lg space-y-2 text-xs">
                      <div className="font-bold text-text-dark flex items-center gap-1">
                        <UserCheck className="h-4 w-4 text-success-green" />
                        <span>AI 实名制匹配结论：{uploadedRecord.association.status} ({uploadedRecord.association.matchRate}% 匹配度)</span>
                      </div>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-[11px] text-text-secondary mt-1 pt-1.5 border-t border-dashed border-slate-200">
                        <div>匹配姓名：<span className="text-text-dark font-bold">{uploadedRecord.association.name}</span></div>
                        <div>所属班组：<span className="text-text-dark font-bold">{uploadedRecord.association.team}</span></div>
                        <div>所属项目：<span className="text-text-dark font-bold">{uploadedRecord.association.project}</span></div>
                      </div>
                    </div>

                    {/* Structural Fields Edit Form */}
                    <form className="space-y-4 text-xs" onSubmit={(e) => e.preventDefault()}>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="block font-bold text-text-secondary mb-1">姓名 (AI提取)</label>
                          <input
                            type="text"
                            value={uploadedRecord.data.name}
                            onChange={(e) => setUploadedRecord({
                              ...uploadedRecord,
                              data: { ...uploadedRecord.data, name: e.target.value }
                            })}
                            className="w-full bg-white border border-slate-300 rounded px-2.5 py-1.5 text-xs text-text-dark"
                          />
                        </div>
                        <div>
                          <label className="block font-bold text-text-secondary mb-1">身份证 (AI提取)</label>
                          <input
                            type="text"
                            value={uploadedRecord.data.idCard}
                            onChange={(e) => setUploadedRecord({
                              ...uploadedRecord,
                              data: { ...uploadedRecord.data, idCard: e.target.value }
                            })}
                            className="w-full bg-white border border-slate-300 rounded px-2.5 py-1.5 text-xs text-text-dark font-mono"
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="block font-bold text-text-secondary mb-1">诊断评估日期</label>
                          <input
                            type="date"
                            value={uploadedRecord.data.date}
                            onChange={(e) => setUploadedRecord({
                              ...uploadedRecord,
                              data: { ...uploadedRecord.data, date: e.target.value }
                            })}
                            className="w-full bg-white border border-slate-300 rounded px-2.5 py-1.5 text-xs text-text-dark"
                          />
                        </div>
                        <div>
                          <label className="block font-bold text-text-secondary mb-1">判定诊断结论</label>
                          <input
                            type="text"
                            value={uploadedRecord.data.result}
                            onChange={(e) => setUploadedRecord({
                              ...uploadedRecord,
                              data: { ...uploadedRecord.data, result: e.target.value }
                            })}
                            className="w-full bg-white border border-slate-300 rounded px-2.5 py-1.5 text-xs text-text-dark"
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="block font-bold text-text-secondary mb-1">评估公信主体</label>
                          <input
                            type="text"
                            value={uploadedRecord.data.institution}
                            onChange={(e) => setUploadedRecord({
                              ...uploadedRecord,
                              data: { ...uploadedRecord.data, institution: e.target.value }
                            })}
                            className="w-full bg-white border border-slate-300 rounded px-2.5 py-1.5 text-xs text-text-dark"
                          />
                        </div>
                        <div>
                          <label className="block font-bold text-text-secondary mb-1">归属项目</label>
                          <input
                            type="text"
                            disabled
                            value={uploadedRecord.data.project}
                            className="w-full bg-slate-50 border border-slate-200 rounded px-2.5 py-1.5 text-xs text-text-secondary"
                          />
                        </div>
                      </div>

                      <div className="flex justify-end gap-2 border-t pt-4">
                        <button
                          type="button"
                          onClick={() => {
                            setAiWizardStep(1)
                            triggerNotification('已取消并清除缓存。', 'warning')
                          }}
                          className="px-4 py-1.5 bg-white border border-slate-300 text-text-dark font-bold rounded shadow-sm cursor-pointer"
                        >
                          取消重置
                        </button>
                        <button
                          type="button"
                          onClick={handleConfirmOcrEntry}
                          className="px-5 py-1.5 bg-[#52C41A] hover:bg-emerald-600 text-white font-bold rounded shadow-sm cursor-pointer flex items-center gap-1"
                        >
                          <Check className="h-4 w-4" />
                          确认入库
                        </button>
                      </div>
                    </form>
                  </div>

                </div>
              )}

            </div>
          )}

          {/* ==========================================
              TAB 3: 待确认数据 (AI pending table)
              ========================================== */}
          {activeTab === 'pending' && (
            <div className="flex-grow flex flex-col gap-6">
              
              {/* Batch action operations bar */}
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-50 p-4 border border-border-gray rounded shrink-0">
                <div className="text-xs text-text-secondary">
                  已勾选 <span className="font-bold text-primary">{selectedRowIds.length}</span> 项待人工确认的 AI 采集单证记录。
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={handleBatchConfirm}
                    disabled={selectedRowIds.length === 0}
                    className={`px-3 py-1.5 text-xs font-bold rounded shadow-sm transition-colors flex items-center gap-1 ${
                      selectedRowIds.length === 0
                        ? 'bg-slate-200 text-slate-400 border border-slate-300 cursor-not-allowed'
                        : 'bg-primary hover:bg-[#1b3d6f] text-white cursor-pointer'
                    }`}
                  >
                    <Check className="h-3.5 w-3.5" />
                    批量审核入库
                  </button>
                  <button
                    onClick={handleBatchReject}
                    disabled={selectedRowIds.length === 0}
                    className={`px-3 py-1.5 text-xs font-bold rounded shadow-sm transition-colors flex items-center gap-1 ${
                      selectedRowIds.length === 0
                        ? 'bg-slate-200 text-slate-400 border border-slate-300 cursor-not-allowed'
                        : 'bg-white hover:bg-slate-100 text-danger-red border border-red-200 cursor-pointer'
                    }`}
                  >
                    <Trash2 className="h-3.5 w-3.5 text-danger-red" />
                    批量驳回
                  </button>
                </div>
              </div>

              {/* Table list */}
              <div className="flex-grow border border-border-gray rounded-lg overflow-x-auto">
                <table className="b-table text-xs">
                  <thead>
                    <tr>
                      <th className="w-10">
                        <input
                          type="checkbox"
                          checked={selectedRowIds.length === aiToConfirm.length && aiToConfirm.length > 0}
                          onChange={(e) => {
                            if (e.target.checked) {
                              setSelectedRowIds(aiToConfirm.map(i => i.id))
                            } else {
                              setSelectedRowIds([])
                            }
                          }}
                          className="h-3.5 w-3.5"
                        />
                      </th>
                      <th>关联工人</th>
                      <th>身份证号</th>
                      <th>识别类型</th>
                      <th>识别明细摘要</th>
                      <th>AI 可信度</th>
                      <th>匹配关联状态</th>
                      <th>提交时间</th>
                      <th>当前审核状态</th>
                      <th className="text-right">操作</th>
                    </tr>
                  </thead>
                  <tbody>
                    {aiToConfirm.map(item => (
                      <tr key={item.id} className="hover:bg-slate-50 transition-colors">
                        <td>
                          <input
                            type="checkbox"
                            checked={selectedRowIds.includes(item.id)}
                            onChange={(e) => {
                              if (e.target.checked) {
                                setSelectedRowIds(prev => [...prev, item.id])
                              } else {
                                setSelectedRowIds(prev => prev.filter(id => id !== item.id))
                              }
                            }}
                            className="h-3.5 w-3.5"
                          />
                        </td>
                        <td className="font-bold text-text-dark">{item.worker}</td>
                        <td className="font-mono text-text-secondary">{item.idCard}</td>
                        <td>{item.type}</td>
                        <td className="max-w-[200px] truncate text-text-secondary" title={item.detail}>{item.detail}</td>
                        <td>
                          <span className={`font-mono font-bold text-xs ${item.conf >= 98 ? 'text-success-green' : 'text-warning-orange'}`}>
                            {item.conf}%
                          </span>
                        </td>
                        <td>
                          <span className="bg-emerald-50 text-success-green border border-emerald-200 px-1.5 py-0.2 rounded text-[10px] font-bold">
                            {item.associateStatus}
                          </span>
                        </td>
                        <td className="text-text-secondary font-mono">{item.time}</td>
                        <td>
                          <span className="bg-amber-50 text-warning-orange border border-amber-200 px-1.5 py-0.2 rounded text-[10px] font-bold animate-pulse">
                            {item.status}
                          </span>
                        </td>
                        <td className="text-right">
                          <button
                            onClick={() => {
                              setUploadedRecord({
                                fileName: item.fileId === 'f1' ? '20260709_体检报告_张建国.pdf' : '20260705_违规处罚通报_王朝阳.png',
                                type: item.type,
                                model: item.model,
                                cost: item.cost,
                                confidence: item.conf,
                                data: {
                                  name: item.worker,
                                  idCard: item.idCard,
                                  date: item.time.split(' ')[0],
                                  project: '北京CBD东区超高层项目',
                                  institution: item.fileId === 'f1' ? '北京市朝阳区第二医院' : '项目安全监察部',
                                  result: item.detail,
                                  remarks: '等待人工核对'
                                },
                                association: {
                                  name: item.worker,
                                  idCard: item.idCard,
                                  project: '北京CBD东区超高层项目',
                                  team: item.fileId === 'f1' ? '钢筋一班' : '泥工一班',
                                  matchRate: 100,
                                  status: '匹配成功'
                                }
                              })
                              setAiWizardStep(3)
                              setActiveTab('ai')
                            }}
                            className="text-primary hover:text-primary-hover font-bold text-xs bg-primary/5 border border-primary/20 px-2 py-1 rounded cursor-pointer"
                          >
                            校对确认
                          </button>
                        </td>
                      </tr>
                    ))}
                    {aiToConfirm.length === 0 && (
                      <tr>
                        <td colSpan="10" className="text-center py-8 text-text-secondary font-medium">
                          没有待确认识别的 AI 提取记录。
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>

            </div>
          )}

          {/* ==========================================
              TAB 4: 人工数据维护台账
              ========================================== */}
          {activeTab === 'manual' && (
            <div className="flex-grow flex flex-col gap-6">
              
              {/* Secondary Sub tabs selector */}
              <div className="flex bg-slate-100 p-1 rounded-lg border border-slate-200 self-start shrink-0">
                {[
                  { id: 'exam', label: '🩺 体检记录' },
                  { id: 'rewards', label: '🏆 奖励记录' },
                  { id: 'punishments', label: '⚠️ 处罚记录' },
                  { id: 'trainings', label: '📚 培训记录' },
                  { id: 'certs', label: '📜 技能证书' },
                  { id: 'honors', label: '🏅 荣誉记录' }
                ].map(sub => (
                  <button
                    key={sub.id}
                    onClick={() => setManualSubTab(sub.id)}
                    className={`px-3 py-1 text-[11px] font-bold rounded transition-all cursor-pointer ${
                      manualSubTab === sub.id ? 'bg-[#11356A] text-white shadow-sm' : 'text-text-secondary hover:text-primary'
                    }`}
                  >
                    {sub.label}
                  </button>
                ))}
              </div>

              {/* Toolbar Actions */}
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-50 p-4 border border-border-gray rounded shrink-0">
                <div className="text-xs font-bold text-text-dark flex items-center gap-1.5">
                  <Activity className="h-4 w-4 text-primary" />
                  <span>当前台账共 {manualData[manualSubTab].length} 条记录</span>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => openAddManualRecord()}
                    className="px-3.5 py-1.5 bg-[#52C41A] hover:bg-emerald-600 text-white rounded font-bold text-xs shadow-sm cursor-pointer flex items-center gap-1"
                  >
                    <Plus className="h-3.5 w-3.5" />
                    新增记录
                  </button>
                  <button
                    onClick={() => triggerNotification('Excel 模板导出准备中...', 'info')}
                    className="px-3 py-1.5 bg-white border border-slate-300 text-text-dark rounded font-bold text-xs shadow-sm cursor-pointer flex items-center gap-1 hover:bg-slate-50"
                  >
                    <Download className="h-3.5 w-3.5" />
                    导出数据
                  </button>
                </div>
              </div>

              {/* Data Table */}
              <div className="flex-grow border border-border-gray rounded-lg overflow-x-auto">
                <table className="b-table text-xs">
                  <thead>
                    <tr>
                      <th>姓名</th>
                      <th>身份证号</th>
                      
                      {manualSubTab === 'exam' && (
                        <>
                          <th>体检筛查项目</th>
                          <th>体检时间</th>
                          <th>体检机构</th>
                          <th>诊断结论</th>
                        </>
                      )}

                      {manualSubTab === 'rewards' && (
                        <>
                          <th>奖励证书名称</th>
                          <th>荣誉级别</th>
                          <th>现金奖励(元)</th>
                          <th>获奖时间</th>
                          <th>授予机构</th>
                        </>
                      )}

                      {manualSubTab === 'punishments' && (
                        <>
                          <th>安全违章行为</th>
                          <th>惩戒措施</th>
                          <th>罚款金额(元)</th>
                          <th>处罚日期</th>
                          <th>督查记录人</th>
                        </>
                      )}

                      {manualSubTab === 'trainings' && (
                        <>
                          <th>安全培训课程</th>
                          <th>课时 (h)</th>
                          <th>考核结论</th>
                          <th>培训日期</th>
                          <th>授课讲师</th>
                        </>
                      )}

                      {manualSubTab === 'certs' && (
                        <>
                          <th>技能证书名称</th>
                          <th>发证级别</th>
                          <th>发证日期</th>
                          <th>发证机关</th>
                        </>
                      )}

                      {manualSubTab === 'honors' && (
                        <>
                          <th>荣誉称号名称</th>
                          <th>荣誉级别</th>
                          <th>授予日期</th>
                          <th>颁发机关</th>
                        </>
                      )}

                      <th>录入人</th>
                      <th>录入方式</th>
                      <th>更新时间</th>
                      <th className="text-right font-bold">操作</th>
                    </tr>
                  </thead>
                  <tbody>
                    {manualData[manualSubTab].map(item => (
                      <tr key={item.id} className="hover:bg-slate-50 transition-colors">
                        <td className="font-bold text-text-dark">{item.name}</td>
                        <td className="font-mono text-text-secondary">{item.idCard}</td>

                        {manualSubTab === 'exam' && (
                          <>
                            <td>{item.project}</td>
                            <td className="font-mono">{item.date}</td>
                            <td>{item.institution}</td>
                            <td>
                              <span className="bg-emerald-50 text-success-green border border-emerald-200 px-1.5 py-0.2 rounded font-bold">
                                {item.result}
                              </span>
                            </td>
                          </>
                        )}

                        {manualSubTab === 'rewards' && (
                          <>
                            <td className="font-semibold text-emerald-800">{item.title}</td>
                            <td>{item.level}</td>
                            <td className="font-mono font-bold text-success-green">+{item.money}</td>
                            <td className="font-mono">{item.date}</td>
                            <td>{item.agency}</td>
                          </>
                        )}

                        {manualSubTab === 'punishments' && (
                          <>
                            <td className="font-semibold text-red-700">{item.reason}</td>
                            <td>{item.action}</td>
                            <td className="font-mono font-bold text-danger-red">-{item.money}</td>
                            <td className="font-mono">{item.date}</td>
                            <td>{item.recorder}</td>
                          </>
                        )}

                        {manualSubTab === 'trainings' && (
                          <>
                            <td>{item.course}</td>
                            <td className="font-mono font-bold text-[#11356A]">{item.hours}h</td>
                            <td>
                              <span className="bg-emerald-50 text-success-green border border-emerald-200 px-1.5 py-0.2 rounded font-bold">
                                {item.result}
                              </span>
                            </td>
                            <td className="font-mono">{item.date}</td>
                            <td>{item.instructor}</td>
                          </>
                        )}

                        {manualSubTab === 'certs' && (
                          <>
                            <td className="font-semibold text-indigo-800">{item.certName}</td>
                            <td>{item.level}</td>
                            <td className="font-mono">{item.date}</td>
                            <td>{item.agency}</td>
                          </>
                        )}

                        {manualSubTab === 'honors' && (
                          <>
                            <td className="font-black text-amber-800">{item.honorName}</td>
                            <td>{item.level}</td>
                            <td className="font-mono">{item.date}</td>
                            <td>{item.agency}</td>
                          </>
                        )}

                        <td>{item.recorder || '管理员'}</td>
                        <td>
                          <span className={`px-1.5 py-0.2 rounded text-[10px] font-bold ${
                            item.mode === 'AI识别' ? 'bg-indigo-50 text-indigo-600 border border-indigo-200' : 'bg-slate-50 text-slate-500 border border-slate-200'
                          }`}>
                            {item.mode || '手工录入'}
                          </span>
                        </td>
                        <td className="font-mono text-text-secondary">{item.date}</td>
                        <td className="text-right">
                          <div className="flex items-center justify-end gap-1.5">
                            <button
                              onClick={() => openAddManualRecord(item)}
                              className="text-primary hover:text-primary-hover font-bold text-[11px] border border-slate-200 bg-white hover:bg-slate-50 px-2 py-0.5 rounded cursor-pointer"
                            >
                              编辑
                            </button>
                            <button
                              onClick={() => handleDeleteManualRecord(item.id)}
                              className="text-danger-red hover:text-red-700 font-bold text-[11px] border border-slate-200 bg-white hover:bg-slate-50 px-2 py-0.5 rounded cursor-pointer"
                            >
                              删除
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

            </div>
          )}

          {/* ==========================================
              TAB 5: 采集历史记录
              ========================================== */}
          {activeTab === 'history' && (
            <div className="flex-grow flex flex-col gap-6">
              
              <div className="flex-grow border border-border-gray rounded-lg overflow-x-auto">
                <table className="b-table text-xs">
                  <thead>
                    <tr>
                      <th>采集接口/方法</th>
                      <th>采集数据类型</th>
                      <th>解析评价对象</th>
                      <th>时延耗时</th>
                      <th>采集更新时间</th>
                      <th>审计记录员</th>
                      <th>原始物料来源</th>
                      <th>同步审计状态</th>
                    </tr>
                  </thead>
                  <tbody>
                    {historyLogs.map(log => (
                      <tr key={log.id} className="hover:bg-slate-50 transition-colors">
                        <td className="font-bold text-text-dark">{log.method}</td>
                        <td>
                          <span className="bg-slate-100 border border-slate-200 px-2 py-0.5 rounded text-[11px] font-semibold text-text-dark">
                            {log.type}
                          </span>
                        </td>
                        <td className="font-semibold text-text-dark">{log.target}</td>
                        <td className="font-mono text-text-secondary">{log.duration}</td>
                        <td className="font-mono text-text-secondary">{log.time}</td>
                        <td>{log.recorder}</td>
                        <td className="text-xs text-text-secondary">{log.source}</td>
                        <td>
                          <span className="bg-emerald-50 text-success-green border border-emerald-200 px-2 py-0.5 rounded font-black">
                            {log.status}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

            </div>
          )}

        </div>
      </div>

      {/* ======================================================================
          DRAWER 1: WORKER PROFILE DETAILS (查看工人详情右侧抽屉)
          ====================================================================== */}
      {isWorkerDrawerOpen && selectedWorker && (
        <div className="fixed inset-0 z-50 flex justify-end">
          {/* Overlay */}
          <div className="absolute inset-0 bg-black/50 transition-opacity" onClick={() => setIsWorkerDrawerOpen(false)}></div>
          
          {/* Content Pane */}
          <div className="relative w-full max-w-xl bg-white h-full shadow-2xl flex flex-col z-10 animate-slide-in">
            {/* Header */}
            <div className="p-5 border-b bg-slate-50 border-slate-200 flex items-center justify-between shrink-0">
              <div>
                <h3 className="text-sm font-black text-text-dark flex items-center gap-2">
                  <span>实名制工人评价档案详情</span>
                  <span className="text-[10px] bg-blue-50 text-primary border border-blue-200 px-2 py-0.5 rounded">
                    实名制同步
                  </span>
                </h3>
                <p className="text-[10px] text-text-secondary mt-1">最后同步时间：{selectedWorker.updateTime}</p>
              </div>
              <button onClick={() => setIsWorkerDrawerOpen(false)} className="text-slate-400 hover:text-slate-600 p-1">
                <X className="h-5 w-5" />
              </button>
            </div>

            {/* Scroll Body */}
            <div className="flex-1 p-6 overflow-y-auto space-y-6">
              
              {/* Profile Card & Circular completeness progress */}
              <div className="bg-slate-50 border border-slate-200 rounded-lg p-5 flex items-center justify-between gap-6">
                <div className="flex items-center gap-4">
                  <div className="h-14 w-14 rounded-full bg-[#11356A] text-white flex items-center justify-center font-black text-lg shadow-inner">
                    {selectedWorker.name[0]}
                  </div>
                  <div>
                    <h4 className="font-bold text-text-dark text-sm flex items-center gap-1.5">
                      {selectedWorker.name}
                      <span className="h-2 w-2 rounded-full bg-success-green"></span>
                    </h4>
                    <span className="text-xs text-text-secondary">{selectedWorker.jobType} | {selectedWorker.team}</span>
                  </div>
                </div>

                {/* Circular completeness indicator */}
                <div className="flex flex-col items-center gap-1 bg-white p-3 border rounded shadow-sm relative">
                  <svg className="w-14 h-14 transform -rotate-90">
                    <circle cx="28" cy="28" r="22" stroke="#E2E8F0" strokeWidth="3" fill="transparent" />
                    <circle cx="28" cy="28" r="22" stroke="#11356A" strokeWidth="3" fill="transparent"
                            strokeDasharray={2 * Math.PI * 22}
                            strokeDashoffset={2 * Math.PI * 22 * (1 - selectedWorker.completeness / 100)} />
                  </svg>
                  <span className="absolute top-[21px] text-[10px] font-black font-mono text-[#11356A]">
                    {selectedWorker.completeness}%
                  </span>
                  <span className="text-[9px] text-text-secondary font-bold">数据完整率</span>
                </div>
              </div>

              {/* Basic Fields */}
              <div className="space-y-3">
                <div className="text-xs font-bold text-text-dark border-l-4 border-primary pl-2 mb-2">基本身份信息</div>
                <div className="grid grid-cols-2 gap-4 text-xs">
                  <div>
                    <span className="text-text-secondary">身份证号：</span>
                    <span className="font-mono text-text-dark font-bold">{selectedWorker.idCard}</span>
                  </div>
                  <div>
                    <span className="text-text-secondary">劳动力所属企业：</span>
                    <span className="text-text-dark font-semibold">{selectedWorker.enterprise}</span>
                  </div>
                  <div>
                    <span className="text-text-secondary">当前在建项目：</span>
                    <span className="text-text-dark font-semibold">{selectedWorker.project}</span>
                  </div>
                  <div>
                    <span className="text-text-secondary">进场签到日期：</span>
                    <span className="text-text-dark font-semibold font-mono">{selectedWorker.entryDate}</span>
                  </div>
                </div>
              </div>

              {/* Data Checklist Cover */}
              <div className="space-y-3 pt-3 border-t">
                <div className="text-xs font-bold text-text-dark border-l-4 border-primary pl-2 mb-2">评价数据覆盖维度核验</div>
                <div className="grid grid-cols-2 gap-3">
                  {[
                    { key: '基本实名信息', done: true },
                    { key: '月度打卡考勤', done: true },
                    { key: '安全三级培训', done: selectedWorker.completeness >= 80 },
                    { key: '季度职业体检', done: selectedWorker.completeness >= 90 },
                    { key: '现场奖励表彰', done: selectedWorker.completeness >= 94 },
                    { key: '违章记分处罚', done: true },
                    { key: '技术等级证书', done: true },
                    { key: '心理健康测评', done: selectedWorker.completeness >= 94 }
                  ].map((chk, idx) => (
                    <div key={idx} className="flex items-center justify-between bg-slate-50 p-2.5 rounded border border-slate-200 text-xs">
                      <span className="text-text-secondary">{chk.key}</span>
                      <span className={`px-2 py-0.5 rounded text-[10px] font-black ${
                        chk.done ? 'bg-emerald-50 text-success-green border border-emerald-100' : 'bg-red-50 text-red-500 border border-red-100'
                      }`}>
                        {chk.done ? '已覆盖' : '待补充'}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* AI Auto Suggestion Card */}
              <div className="bg-indigo-50/50 border border-dashed border-indigo-200 rounded-lg p-4 space-y-2 text-xs">
                <div className="flex items-center gap-1 text-[#11356A] font-bold">
                  <Sparkles className="h-4.5 w-4.5 text-indigo-500 animate-pulse" />
                  <span>AI 智能治理优化建议</span>
                </div>
                <p className="text-[11px] text-text-secondary leading-relaxed">
                  {getWorkerSuggestions(selectedWorker).suggest}
                </p>
                <div className="flex flex-wrap gap-1.5 pt-1.5">
                  {getWorkerSuggestions(selectedWorker).missing.map((mis, i) => (
                    <span key={i} className="bg-indigo-100 text-[#11356A] text-[9.5px] px-2 py-0.5 rounded font-black shadow-sm">
                      ⚠️ 缺: {mis}
                    </span>
                  ))}
                </div>
              </div>

            </div>

            {/* Footer */}
            <div className="p-4 border-t bg-slate-50 border-slate-200 flex items-center justify-end shrink-0">
              <button
                onClick={() => setIsWorkerDrawerOpen(false)}
                className="px-4 py-2 bg-primary hover:bg-[#1b3d6f] text-white text-xs font-bold rounded shadow-sm cursor-pointer transition-colors"
              >
                关闭面板
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ======================================================================
          DRAWER 2: MANUAL DATA ADD/EDIT (人工数据新增/编辑右侧抽屉)
          ====================================================================== */}
      {isAddManualDrawerOpen && (
        <div className="fixed inset-0 z-50 flex justify-end">
          {/* Overlay */}
          <div className="absolute inset-0 bg-black/50 transition-opacity" onClick={() => setIsAddManualDrawerOpen(false)}></div>

          {/* Form container */}
          <form
            onSubmit={handleSaveManualForm}
            className="relative w-full max-w-xl bg-white h-full shadow-2xl flex flex-col z-10 animate-slide-in"
          >
            {/* Header */}
            <div className="p-5 border-b bg-slate-50 border-slate-200 flex items-center justify-between shrink-0">
              <h3 className="text-sm font-black text-text-dark flex items-center gap-1.5">
                <Edit className="h-4.5 w-4.5 text-primary" />
                <span>
                  {editingManualRecord ? '修改人工评价数据' : '补登人工维护数据'} - {
                    manualSubTab === 'exam' ? '体检记录' :
                    manualSubTab === 'rewards' ? '奖励记录' :
                    manualSubTab === 'punishments' ? '处罚记录' :
                    manualSubTab === 'trainings' ? '培训记录' :
                    manualSubTab === 'certs' ? '特种证书' : '荣誉称号'
                  }
                </span>
              </h3>
              <button type="button" onClick={() => setIsAddManualDrawerOpen(false)} className="text-slate-400 hover:text-slate-600 p-1">
                <X className="h-5 w-5" />
              </button>
            </div>

            {/* Form Fields Scroll */}
            <div className="flex-grow p-6 overflow-y-auto space-y-4 text-xs">
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block font-bold text-text-secondary mb-1">选择目标工人</label>
                  <select
                    value={manualForm.name}
                    onChange={(e) => setManualForm({ ...manualForm, name: e.target.value })}
                    className="w-full bg-white border border-slate-300 rounded px-2.5 py-1.5 text-text-dark"
                  >
                    {workers.map(w => (
                      <option key={w.id} value={w.name}>{w.name} ({w.jobType})</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block font-bold text-text-secondary mb-1">所属参建项目</label>
                  <select
                    value={manualForm.project}
                    onChange={(e) => setManualForm({ ...manualForm, project: e.target.value })}
                    className="w-full bg-white border border-slate-300 rounded px-2.5 py-1.5 text-text-dark"
                  >
                    <option value="北京CBD东区超高层项目">北京CBD东区超高层项目</option>
                    <option value="北京轨道交通28号线项目">北京轨道交通28号线项目</option>
                    <option value="城市绿心剧院机电安装项目">城市绿心剧院机电安装项目</option>
                  </select>
                </div>
              </div>

              {/* Tab specific dynamic sub-forms */}
              {manualSubTab === 'exam' && (
                <div className="space-y-4 border-t pt-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block font-bold text-text-secondary mb-1">体检筛查时间</label>
                      <input
                        type="date"
                        required
                        value={manualForm.date}
                        onChange={(e) => setManualForm({ ...manualForm, date: e.target.value })}
                        className="w-full bg-white border border-slate-300 rounded px-2.5 py-1.5 text-text-dark"
                      />
                    </div>
                    <div>
                      <label className="block font-bold text-text-secondary mb-1">健康结论结论</label>
                      <select
                        value={manualForm.result}
                        onChange={(e) => setManualForm({ ...manualForm, result: e.target.value })}
                        className="w-full bg-white border border-slate-300 rounded px-2.5 py-1.5 text-text-dark"
                      >
                        <option value="合格">合格</option>
                        <option value="不合格">不合格 (高处禁忌)</option>
                      </select>
                    </div>
                  </div>
                  <div>
                    <label className="block font-bold text-text-secondary mb-1">筛查医疗机构</label>
                    <input
                      type="text"
                      required
                      value={manualForm.institution}
                      onChange={(e) => setManualForm({ ...manualForm, institution: e.target.value })}
                      placeholder="如：北京市朝阳区第二医院"
                      className="w-full bg-white border border-slate-300 rounded px-2.5 py-1.5 text-text-dark"
                    />
                  </div>
                </div>
              )}

              {manualSubTab === 'rewards' && (
                <div className="space-y-4 border-t pt-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block font-bold text-text-secondary mb-1">奖励现金金额 (元)</label>
                      <input
                        type="number"
                        required
                        value={manualForm.money}
                        onChange={(e) => setManualForm({ ...manualForm, money: e.target.value })}
                        placeholder="如：500"
                        className="w-full bg-white border border-slate-300 rounded px-2.5 py-1.5 text-text-dark"
                      />
                    </div>
                    <div>
                      <label className="block font-bold text-text-secondary mb-1">表彰获奖日期</label>
                      <input
                        type="date"
                        required
                        value={manualForm.date}
                        onChange={(e) => setManualForm({ ...manualForm, date: e.target.value })}
                        className="w-full bg-white border border-slate-300 rounded px-2.5 py-1.5 text-text-dark"
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block font-bold text-text-secondary mb-1">奖励荣誉级别</label>
                      <select
                        value={manualForm.level}
                        onChange={(e) => setManualForm({ ...manualForm, level: e.target.value })}
                        className="w-full bg-white border border-slate-300 rounded px-2.5 py-1.5 text-text-dark"
                      >
                        <option value="项目部级">项目部级</option>
                        <option value="企业级">企业级</option>
                        <option value="省级">省级</option>
                      </select>
                    </div>
                    <div>
                      <label className="block font-bold text-text-secondary mb-1">颁发授予机关</label>
                      <input
                        type="text"
                        required
                        value={manualForm.agency}
                        onChange={(e) => setManualForm({ ...manualForm, agency: e.target.value })}
                        placeholder="颁授机关单位"
                        className="w-full bg-white border border-slate-300 rounded px-2.5 py-1.5 text-text-dark"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block font-bold text-text-secondary mb-1">奖励证书/奖项全称</label>
                    <input
                      type="text"
                      required
                      value={manualForm.title}
                      onChange={(e) => setManualForm({ ...manualForm, title: e.target.value })}
                      placeholder="如：百日安全优秀标兵表彰"
                      className="w-full bg-white border border-slate-300 rounded px-2.5 py-1.5 text-text-dark"
                    />
                  </div>
                </div>
              )}

              {manualSubTab === 'punishments' && (
                <div className="space-y-4 border-t pt-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block font-bold text-text-secondary mb-1">处罚扣款金额 (元)</label>
                      <input
                        type="number"
                        required
                        value={manualForm.money}
                        onChange={(e) => setManualForm({ ...manualForm, money: e.target.value })}
                        className="w-full bg-white border border-slate-300 rounded px-2.5 py-1.5 text-text-dark"
                      />
                    </div>
                    <div>
                      <label className="block font-bold text-text-secondary mb-1">违章通报日期</label>
                      <input
                        type="date"
                        required
                        value={manualForm.date}
                        onChange={(e) => setManualForm({ ...manualForm, date: e.target.value })}
                        className="w-full bg-white border border-slate-300 rounded px-2.5 py-1.5 text-text-dark"
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block font-bold text-text-secondary mb-1">惩戒处置手段</label>
                      <input
                        type="text"
                        required
                        value={manualForm.action}
                        onChange={(e) => setManualForm({ ...manualForm, action: e.target.value })}
                        placeholder="如：通报警告并罚款"
                        className="w-full bg-white border border-slate-300 rounded px-2.5 py-1.5 text-text-dark"
                      />
                    </div>
                    <div>
                      <label className="block font-bold text-text-secondary mb-1">定案安全督察人</label>
                      <input
                        type="text"
                        required
                        value={manualForm.recorder}
                        onChange={(e) => setManualForm({ ...manualForm, recorder: e.target.value })}
                        className="w-full bg-white border border-slate-300 rounded px-2.5 py-1.5 text-text-dark"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block font-bold text-text-secondary mb-1">具体违章行为行为</label>
                    <textarea
                      required
                      rows="2"
                      value={manualForm.reason}
                      onChange={(e) => setManualForm({ ...manualForm, reason: e.target.value })}
                      placeholder="描述违章事实..."
                      className="w-full bg-white border border-slate-300 rounded px-2.5 py-1.5 text-text-dark"
                    ></textarea>
                  </div>
                </div>
              )}

              {manualSubTab === 'trainings' && (
                <div className="space-y-4 border-t pt-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block font-bold text-text-secondary mb-1">培训总学时 (h)</label>
                      <input
                        type="number"
                        required
                        value={manualForm.hours}
                        onChange={(e) => setManualForm({ ...manualForm, hours: e.target.value })}
                        className="w-full bg-white border border-slate-300 rounded px-2.5 py-1.5 text-text-dark"
                      />
                    </div>
                    <div>
                      <label className="block font-bold text-text-secondary mb-1">考核考评日期</label>
                      <input
                        type="date"
                        required
                        value={manualForm.date}
                        onChange={(e) => setManualForm({ ...manualForm, date: e.target.value })}
                        className="w-full bg-white border border-slate-300 rounded px-2.5 py-1.5 text-text-dark"
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block font-bold text-text-secondary mb-1">考评培训结论</label>
                      <select
                        value={manualForm.result}
                        onChange={(e) => setManualForm({ ...manualForm, result: e.target.value })}
                        className="w-full bg-white border border-slate-300 rounded px-2.5 py-1.5 text-text-dark"
                      >
                        <option value="合格">合格</option>
                        <option value="优秀">优秀</option>
                        <option value="不合格">不合格</option>
                      </select>
                    </div>
                    <div>
                      <label className="block font-bold text-text-secondary mb-1">主要讲课讲师</label>
                      <input
                        type="text"
                        required
                        value={manualForm.instructor}
                        onChange={(e) => setManualForm({ ...manualForm, instructor: e.target.value })}
                        className="w-full bg-white border border-slate-300 rounded px-2.5 py-1.5 text-text-dark"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block font-bold text-text-secondary mb-1">培训课程全称</label>
                    <input
                      type="text"
                      required
                      value={manualForm.course}
                      onChange={(e) => setManualForm({ ...manualForm, course: e.target.value })}
                      placeholder="培训主题名称"
                      className="w-full bg-white border border-slate-300 rounded px-2.5 py-1.5 text-text-dark"
                    />
                  </div>
                </div>
              )}

              {manualSubTab === 'certs' && (
                <div className="space-y-4 border-t pt-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block font-bold text-text-secondary mb-1">发证评定级别</label>
                      <select
                        value={manualForm.level}
                        onChange={(e) => setManualForm({ ...manualForm, level: e.target.value })}
                        className="w-full bg-white border border-slate-300 rounded px-2.5 py-1.5 text-text-dark"
                      >
                        <option value="省级">省级/厅局级</option>
                        <option value="市级">市级/地级市</option>
                        <option value="企业级">企业级证书</option>
                      </select>
                    </div>
                    <div>
                      <label className="block font-bold text-text-secondary mb-1">证书发证日期</label>
                      <input
                        type="date"
                        required
                        value={manualForm.date}
                        onChange={(e) => setManualForm({ ...manualForm, date: e.target.value })}
                        className="w-full bg-white border border-slate-300 rounded px-2.5 py-1.5 text-text-dark"
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block font-bold text-text-secondary mb-1">评定发证机关</label>
                      <input
                        type="text"
                        required
                        value={manualForm.agency}
                        onChange={(e) => setManualForm({ ...manualForm, agency: e.target.value })}
                        placeholder="发证单位名称"
                        className="w-full bg-white border border-slate-300 rounded px-2.5 py-1.5 text-text-dark"
                      />
                    </div>
                    <div>
                      <label className="block font-bold text-text-secondary mb-1">技能证书名称</label>
                      <input
                        type="text"
                        required
                        value={manualForm.certName}
                        onChange={(e) => setManualForm({ ...manualForm, certName: e.target.value })}
                        placeholder="如：二级特种焊接资质"
                        className="w-full bg-white border border-slate-300 rounded px-2.5 py-1.5 text-text-dark"
                      />
                    </div>
                  </div>
                </div>
              )}

              {manualSubTab === 'honors' && (
                <div className="space-y-4 border-t pt-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block font-bold text-text-secondary mb-1">荣誉授予级别</label>
                      <select
                        value={manualForm.level}
                        onChange={(e) => setManualForm({ ...manualForm, level: e.target.value })}
                        className="w-full bg-white border border-slate-300 rounded px-2.5 py-1.5 text-text-dark"
                      >
                        <option value="省级">省级劳动模范</option>
                        <option value="市级">市级杰出称号</option>
                        <option value="企业级">企业级荣誉</option>
                      </select>
                    </div>
                    <div>
                      <label className="block font-bold text-text-secondary mb-1">荣誉授予日期</label>
                      <input
                        type="date"
                        required
                        value={manualForm.date}
                        onChange={(e) => setManualForm({ ...manualForm, date: e.target.value })}
                        className="w-full bg-white border border-slate-300 rounded px-2.5 py-1.5 text-text-dark"
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block font-bold text-text-secondary mb-1">授予颁发机关</label>
                      <input
                        type="text"
                        required
                        value={manualForm.agency}
                        onChange={(e) => setManualForm({ ...manualForm, agency: e.target.value })}
                        placeholder="颁发单位名称"
                        className="w-full bg-white border border-slate-300 rounded px-2.5 py-1.5 text-text-dark"
                      />
                    </div>
                    <div>
                      <label className="block font-bold text-text-secondary mb-1">荣誉称号全称</label>
                      <input
                        type="text"
                        required
                        value={manualForm.honorName}
                        onChange={(e) => setManualForm({ ...manualForm, honorName: e.target.value })}
                        placeholder="如：杰出青工先锋"
                        className="w-full bg-white border border-slate-300 rounded px-2.5 py-1.5 text-text-dark"
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* Shared Upload file zone */}
              <div className="border-t pt-4 space-y-4">
                <div>
                  <label className="block font-bold text-text-secondary mb-1">审计证明扫描件 (PDF / JPG)</label>
                  <div className="border border-dashed border-slate-300 rounded p-4 text-center cursor-pointer hover:bg-slate-50 bg-slate-50 flex items-center justify-center gap-1.5 text-text-secondary">
                    <Upload className="h-4.5 w-4.5" />
                    <span>上传佐证资料扫描件 (限制 20MB)</span>
                  </div>
                </div>
                <div>
                  <label className="block font-bold text-text-secondary mb-1">备注说明</label>
                  <textarea
                    rows="2"
                    value={manualForm.remarks}
                    onChange={(e) => setManualForm({ ...manualForm, remarks: e.target.value })}
                    placeholder="输入其他需要补充说明的审计信息..."
                    className="w-full bg-white border border-slate-300 rounded px-2.5 py-1.5 text-text-dark"
                  ></textarea>
                </div>
              </div>

            </div>

            {/* Footer */}
            <div className="p-4 border-t bg-slate-50 border-slate-200 flex items-center justify-end gap-2 shrink-0">
              <button
                type="button"
                onClick={() => setIsAddManualDrawerOpen(false)}
                className="px-4 py-2 bg-white border border-slate-300 text-text-dark font-bold rounded shadow-sm cursor-pointer"
              >
                取消
              </button>
              <button
                type="submit"
                className="px-5 py-2 bg-[#11356A] hover:bg-primary-hover text-white font-bold rounded shadow cursor-pointer transition-colors"
              >
                保存并入库
              </button>
            </div>
          </form>
        </div>
      )}

    </div>
  )
}
