import { useState, useMemo, useEffect } from 'react'
import {
  Sliders,
  Play,
  Clock,
  RotateCcw,
  Plus,
  X,
  Check,
  Search,
  AlertTriangle,
  FileText,
  Calendar,
  Layers,
  ArrowRight,
  TrendingUp,
  Cpu,
  Trash2,
  ListFilter,
  CheckCircle2,
  RefreshCw,
  SlidersHorizontal,
  ChevronRight,
  Info,
  HelpCircle,
  Activity,
  Sparkles,
  Download,
  Upload,
  History,
  Award,
  ArrowLeft,
  Copy,
  FileSpreadsheet,
  AlertCircle
} from 'lucide-react'

// Initial Models Data
const INITIAL_MODELS = [
  { id: 'MOD-001', name: '建筑产业工人通用评级模型', code: 'MODEL_GEN_01', scope: '集团全项目', version: 'v2.4.0', status: true, creator: '张经理', created: '2026-05-10', updated: '2026-07-09', remarks: '覆盖全员基准评价' },
  { id: 'MOD-002', name: '高空作业特种工安全专项模型', code: 'MODEL_HIGH_SAFE', scope: '高处作业/特种班组', version: 'v1.0.8', status: true, creator: '李安全', created: '2026-06-15', updated: '2026-07-08', remarks: '安全红线高防范' },
  { id: 'MOD-003', name: '集团新星班组长领导力评级模型', code: 'MODEL_LEAD_STAR', scope: '各工种班组长', version: 'v1.2.0', status: false, creator: '王主管', created: '2026-06-01', updated: '2026-06-30', remarks: '侧重于班组管理' }
];

// Initial Version timelines
const INITIAL_VERSIONS = [
  { version: 'v2.4.0', date: '2026-07-09', creator: '张经理', desc: '微调了安全管理和职业能力权重，强化特种执业证关联。', status: '当前激活', runs: 285 },
  { version: 'v2.3.8', date: '2026-06-20', creator: '张经理', desc: '调整了C级警示分值区间线，放宽了工伤保险准入率扣分。', status: '历史版本', runs: 120 },
  { version: 'v2.1.0', date: '2026-05-15', creator: '李经理', desc: '初始版本上线备案，支持5大维度滑块配置。', status: '历史版本', runs: 65 }
];

// Initial Levels Configs
const INITIAL_LEVELS = [
  { id: 'l1', name: 'A 级', label: '杰出优秀工人', min: 90, max: 100, color: '#52C41A', desc: '特种持证完备，连续出勤出满，无任何违章处罚。' },
  { id: 'l2', name: 'B 级', label: '良好合格工人', min: 80, max: 89, color: '#1890FF', desc: '各项指标合格，具备良好的专业实操及履约素养。' },
  { id: 'l3', name: 'C 级', label: '基本合格工人', min: 70, max: 79, color: '#722ED1', desc: '偶有小微违规或出勤偏少，整体处于可控制区间。' },
  { id: 'l4', name: 'D 级', label: '安全警示人员', min: 60, max: 69, color: '#FA8C16', desc: '发生过多次违章施工通报，需加强日常考核警示。' },
  { id: 'l5', name: 'E 级', label: '不合格清退', min: 0, max: 59, color: '#F5222D', desc: '严重红线违规，或体检不合格判定有高空禁忌症。' }
];

// Execution Logs
const INITIAL_EXEC_LOGS = [
  { id: 'RUN-109', time: '2026-07-09 00:00:05', creator: '自动调度', project: '集团全项目', total: 1265, success: 1262, failed: 3, type: '自动执行', duration: '4.2s', status: '成功' },
  { id: 'RUN-108', time: '2026-07-08 16:30:00', creator: '李安全', project: '北京CBD东区超高层项目', total: 145, success: 145, failed: 0, type: '立即执行', duration: '1.2s', status: '成功' },
  { id: 'RUN-107', time: '2026-07-05 23:00:02', creator: '定时调度', project: '集团高空作业专项', total: 120, success: 118, failed: 2, type: '定时执行', duration: '1.8s', status: '成功' }
];

// Mock Workers list for simulation
const MOCK_WORKERS = [
  { id: 'w1', name: '张建国', job: '特种塔吊工', score: 94, level: 'A 级', details: { capability: 95, attendance: 90, safety: 96, health: 92, credit: 98 } },
  { id: 'w2', name: '李强', job: '架子工', score: 85, level: 'B 级', details: { capability: 82, attendance: 88, safety: 80, health: 90, credit: 92 } },
  { id: 'w3', name: '王朝阳', job: '电焊工', score: 72, level: 'C 级', details: { capability: 78, attendance: 65, safety: 70, health: 80, credit: 75 } },
  { id: 'w4', name: '刘小虎', job: '普工', score: 58, level: 'E 级', details: { capability: 50, attendance: 62, safety: 45, health: 80, credit: 60 } }
];

export default function ModelCenter({ triggerNotification }) {
  const [activeTab, setActiveTab] = useState('models') // models, versions, weight, levels, exec, logs

  // Filter queries
  const [searchKeyword, setSearchKeyword] = useState('')
  const [filterModel, setFilterModel] = useState('ALL')
  const [filterProject, setFilterProject] = useState('ALL')

  // Lists state
  const [models, setModels] = useState(INITIAL_MODELS)
  const [versions, setVersions] = useState(INITIAL_VERSIONS)
  const [levels, setLevels] = useState(INITIAL_LEVELS)
  const [execLogs, setExecLogs] = useState(INITIAL_EXEC_LOGS)

  // Drawer Form Dialogs
  const [isAddModelOpen, setIsAddModelOpen] = useState(false)
  const [editingModel, setEditingModel] = useState(null)
  const [isDetailDrawerOpen, setIsDetailDrawerOpen] = useState(false)
  const [selectedDetails, setSelectedDetails] = useState(null)

  // New model form
  const [modelForm, setModelForm] = useState({
    id: '',
    name: '',
    code: '',
    scope: '集团全项目',
    version: 'v1.0.0',
    status: true,
    creator: '张经理',
    remarks: ''
  })

  // Version Comparison modal parameters
  const [compareVerA, setCompareVerA] = useState('v2.4.0')
  const [compareVerB, setCompareVerB] = useState('v2.3.8')
  const [isCompareOpen, setIsCompareOpen] = useState(false)

  // Dynamic Sliders state (Tab 3)
  const [sliders, setSliders] = useState({
    professional: 30,
    fulfillment: 25,
    safety: 20,
    health: 10,
    credit: 15
  })

  const totalSliderSum = useMemo(() => {
    return sliders.professional + sliders.fulfillment + sliders.safety + sliders.health + sliders.credit
  }, [sliders])

  // Grade rules sorting (Tab 4)
  const [isAddLevelOpen, setIsAddLevelOpen] = useState(false)
  const [levelForm, setLevelForm] = useState({ id: '', name: 'F级', label: '重点跟进人员', min: 0, max: 49, color: '#D9D9D9', desc: '' })

  // Execution engine state (Tab 5)
  const [execType, setExecType] = useState('immediate') // immediate, scheduled, auto
  const [execProject, setExecProject] = useState('北京CBD东区超高层项目')
  const [execScopeSelect, setExecScopeSelect] = useState('全员')
  
  // Progress states for immediate runner
  const [isRunning, setIsRunning] = useState(false)
  const [runProgress, setRunProgress] = useState(0)
  const [runTotal, setRunTotal] = useState(0)
  const [runSuccess, setRunSuccess] = useState(0)
  const [runFailed, setRunFailed] = useState(0)
  const [runStepText, setRunStepText] = useState('')

  // Simulator states
  const [simWorkerId, setSimWorkerId] = useState('w1')
  const [simulating, setSimulating] = useState(false)
  const [simResult, setSimResult] = useState(null)

  // Execution audit Log Drawer (Tab 6)
  const [isLogDrawerOpen, setIsLogDrawerOpen] = useState(false)
  const [selectedLog, setSelectedLog] = useState(null)

  // Trigger Immediate Run Evaluation
  const handleStartImmediateRun = () => {
    setIsRunning(true)
    setRunProgress(5)
    setRunTotal(126)
    setRunSuccess(0)
    setRunFailed(0)
    setRunStepText('正在初始化评价权重因子及公式...')

    let progress = 5
    const interval = setInterval(() => {
      progress += 15
      if (progress >= 100) {
        clearInterval(interval)
        setRunProgress(100)
        setRunSuccess(124)
        setRunFailed(2)
        setRunStepText('综合评价结算完毕！已写入历史备份数据库。')
        setIsRunning(false)

        // Append to logs
        const newLog = {
          id: `RUN-${Date.now().toString().slice(-3)}`,
          time: new Date().toISOString().replace('T', ' ').slice(0, 19),
          creator: '张经理',
          project: execProject,
          total: 126,
          success: 124,
          failed: 2,
          type: '立即执行',
          duration: '2.4s',
          status: '成功'
        }
        setExecLogs(prev => [newLog, ...prev])
        triggerNotification('已完成评价执行！生成 124 份工人评价，2 份校验异常记录已推至警告库。', 'success')
      } else {
        setRunProgress(progress)
        const completed = Math.floor((progress / 100) * 126)
        setRunSuccess(completed)
        if (progress > 50) setRunFailed(2)
        setRunStepText(`读取数据血缘... 已清洗评估 ${completed}/126 人。`)
      }
    }, 400)
  }

  // Trigger Worker scoring simulation
  const handleRunSimulator = () => {
    setSimulating(true)
    setSimResult(null)
    triggerNotification('AI计算大脑加载特征值分析中...', 'info')

    setTimeout(() => {
      const match = MOCK_WORKERS.find(w => w.id === simWorkerId)
      if (match) {
        setSimResult(match)
        triggerNotification(`工人「${match.name}」综合评分模拟计算完成：${match.score} 分`, 'success')
      }
      setSimulating(false)
    }, 600)
  }

  // Save new model form
  const handleSaveModel = (e) => {
    e.preventDefault()
    if (editingModel) {
      setModels(prev => prev.map(m => m.id === editingModel.id ? { ...modelForm } : m))
      triggerNotification('模型配置更新成功。', 'success')
    } else {
      const newM = {
        ...modelForm,
        id: `MOD-00${models.length + 1}`
      }
      setModels(prev => [newM, ...prev])
      triggerNotification('新增评价模型成功！已进入版本控制流水线。', 'success')
    }
    setIsAddModelOpen(false)
  }

  // Auto-balance weights
  const handleAutoBalance = () => {
    setSliders({
      professional: 30,
      fulfillment: 25,
      safety: 20,
      health: 10,
      credit: 15
    })
    triggerNotification('滑块已自动重置并平衡为国企通用标准配比。', 'info')
  }

  return (
    <div className="flex-grow flex flex-col gap-6">
      
      {/* 1. Page Header */}
      <div className="bg-white border border-border-gray rounded p-5 flex flex-col md:flex-row md:items-center justify-between gap-4 shrink-0 shadow-sm">
        <div>
          <h2 className="text-xl font-bold text-text-dark flex items-center gap-2">
            <Sliders className="h-5.5 w-5.5 text-primary animate-pulse" />
            评价模型与执行中心
            <span className="text-xs font-normal text-warning-orange bg-amber-50 border border-amber-200 px-2 py-0.5 rounded">
              央企模型调度中心
            </span>
          </h2>
          <p className="text-xs text-text-secondary mt-1.5">
            配置评价权重滑块，审核评价等级评定界限规则，并针对在场劳务项目手动或定时启动大批量数据评价结算引擎。
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => triggerNotification('最新定时运行正常，下一次：明日 00:00:00', 'success')}
            className="px-3 py-1.5 bg-slate-100 border rounded font-bold text-xs text-text-dark flex items-center gap-1 cursor-pointer"
          >
            <Clock className="h-3.5 w-3.5 text-primary" />
            下次自动评价调度：定时每天 00:00
          </button>
        </div>
      </div>

      {/* 2. Top Stats Row (5 Columns) */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-6 shrink-0">
        {[
          { title: '模型总数量', val: `${models.length} 套`, desc: '启用 2 套 / 停用 1 套', time: '自动更新', icon: <Layers className="h-5 w-5 text-primary" /> },
          { title: '当前激活版本', val: 'v2.4.0', desc: '2026-07-09 更新', time: '发版归档', icon: <History className="h-5 w-5 text-indigo-500" /> },
          { title: '累计计算次数', val: '470 次', desc: '覆盖 12,500 人次', time: '昨日结算完毕', icon: <Activity className="h-5 w-5 text-[#52C41A]" /> },
          { title: '今日评价次数', val: '1 次', desc: '自动凌晨同步跑分', time: '今日 00:00', icon: <CheckCircle2 className="h-5 w-5 text-success-green" /> },
          { title: 'A级工人在册数', val: '248 人', desc: '占在场总工人数 19%', time: '良好率极高', icon: <Award className="h-5 w-5 text-orange-500" /> }
        ].map((kpi, idx) => (
          <div key={idx} className="bg-white border border-border-gray p-4 rounded-lg shadow-sm flex flex-col justify-between hover:shadow-md transition-all border-l-4 border-l-primary">
            <div className="flex items-start justify-between">
              <div className="text-[10px] text-text-secondary font-bold uppercase tracking-wider">{kpi.title}</div>
              <div className="bg-slate-50 p-1.5 rounded">{kpi.icon}</div>
            </div>
            <div className="mt-2.5">
              <div className="text-xl font-black text-text-dark font-mono leading-none">{kpi.val}</div>
              <div className="flex items-center justify-between text-[10px] text-text-secondary mt-2">
                <span className="font-semibold text-primary">{kpi.desc}</span>
                <span>{kpi.time.split(' ')[0]}</span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* 3. Primary Tabs Navigation */}
      <div className="bg-white border border-border-gray rounded shadow-sm flex flex-col min-h-[500px] flex-grow">
        
        {/* Navigation tabs */}
        <div className="flex border-b border-border-gray bg-slate-50 px-4 pt-3 shrink-0">
          {[
            { id: 'models', label: '模型配置台账', icon: <Layers className="h-4 w-4" /> },
            { id: 'versions', label: '模型版本历史', icon: <History className="h-4 w-4" /> },
            { id: 'weight', label: '维度权重滑块', icon: <SlidersHorizontal className="h-4 w-4" /> },
            { id: 'levels', label: '等级规则配置', icon: <Award className="h-4 w-4" /> },
            { id: 'exec', label: '模型执行与模拟', icon: <Play className="h-4 w-4" /> },
            { id: 'logs', label: '执行日志记录', icon: <FileText className="h-4 w-4" /> }
          ].map(t => (
            <button
              key={t.id}
              onClick={() => setActiveTab(t.id)}
              className={`flex items-center gap-1.5 px-4 py-3 text-xs font-bold border-t-2 border-x transition-all duration-150 cursor-pointer ${
                activeTab === t.id
                  ? 'bg-white border-x-border-gray border-t-primary text-primary -mb-[1px] relative z-10 shadow-[0_-2px_10px_rgba(0,0,0,0.03)]'
                  : 'bg-transparent border-transparent text-text-secondary hover:text-primary hover:bg-slate-100'
              }`}
            >
              {t.icon}
              <span>{t.label}</span>
            </button>
          ))}
        </div>

        {/* Dynamic Panels */}
        <div className="p-6 flex-grow flex flex-col min-h-[380px]">
          
          {/* ==========================================
              TAB 1: 模型配置 (Table list)
              ========================================== */}
          {activeTab === 'models' && (
            <div className="flex-grow flex flex-col gap-6">
              
              {/* Search bar */}
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-50 p-4 border border-border-gray rounded shrink-0">
                <div className="flex items-center gap-4 flex-wrap">
                  <div className="relative">
                    <input
                      type="text"
                      value={searchKeyword}
                      onChange={(e) => setSearchKeyword(e.target.value)}
                      placeholder="搜索模型名称/编码..."
                      className="bg-white border border-slate-300 rounded px-2.5 pl-8 py-1 text-xs text-text-dark w-48"
                    />
                    <Search className="absolute left-2.5 top-2 h-3.5 w-3.5 text-slate-400" />
                  </div>
                  <div>
                    <select
                      value={filterProject}
                      onChange={(e) => setFilterProject(e.target.value)}
                      className="bg-white border border-slate-300 rounded px-2 py-1 text-xs text-text-dark"
                    >
                      <option value="ALL">全部适用范围</option>
                      <option value="集团全项目">集团全项目</option>
                      <option value="高处作业/特种班组">高处作业/特种班组</option>
                      <option value="各工种班组长">各工种班组长</option>
                    </select>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button onClick={() => triggerNotification('正在检索评价模型...', 'info')} className="px-3.5 py-1.5 bg-[#11356A] hover:bg-primary-hover text-white text-xs font-bold rounded shadow-sm cursor-pointer">查询</button>
                  <button onClick={() => { setSearchKeyword(''); setFilterProject('ALL') }} className="px-3.5 py-1.5 bg-white hover:bg-slate-50 text-text-dark border border-slate-300 text-xs font-bold rounded shadow-sm cursor-pointer">重置</button>
                </div>
              </div>

              {/* Toolbar */}
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white border border-border-gray p-4 rounded shrink-0">
                <div className="text-xs text-text-secondary font-bold flex items-center gap-1.5">
                  <Sliders className="h-4 w-4 text-primary animate-pulse" />
                  <span>当前可用评级模型共有 {models.length} 套</span>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => {
                      setModelForm({
                        id: '',
                        name: '智能基建盾构工种专项评价模型',
                        code: 'MODEL_SHIELD',
                        scope: '盾构施工特种班组',
                        version: 'v1.0.0',
                        status: true,
                        creator: '张经理',
                        remarks: '重度偏向考核盾构安全及专业持证率'
                      })
                      setEditingModel(null)
                      setIsAddModelOpen(true)
                    }}
                    className="px-3 py-1.5 bg-[#52C41A] hover:bg-emerald-600 text-white rounded font-bold text-xs shadow-sm cursor-pointer flex items-center gap-1"
                  >
                    <Plus className="h-3.5 w-3.5" />
                    新增模型
                  </button>
                  <button
                    onClick={() => triggerNotification('正在导出模型清单Excel...', 'success')}
                    className="px-3 py-1.5 bg-white border border-slate-300 text-text-dark rounded font-bold text-xs shadow-sm cursor-pointer flex items-center gap-1 hover:bg-slate-50"
                  >
                    <Download className="h-3.5 w-3.5" />
                    导出Excel
                  </button>
                </div>
              </div>

              {/* Table */}
              <div className="flex-grow border border-border-gray rounded-lg overflow-x-auto">
                <table className="b-table text-xs">
                  <thead>
                    <tr>
                      <th>模型编码</th>
                      <th>模型名称</th>
                      <th>适用评价范围</th>
                      <th>当前激活版本</th>
                      <th>启用状态</th>
                      <th>主创建人</th>
                      <th>初建时间</th>
                      <th>最后更新</th>
                      <th>备注</th>
                      <th className="text-right">操作</th>
                    </tr>
                  </thead>
                  <tbody>
                    {models.map(item => (
                      <tr key={item.id} className="hover:bg-slate-50 transition-colors">
                        <td className="font-mono font-bold text-[#11356A]">{item.code}</td>
                        <td className="font-bold text-text-dark">{item.name}</td>
                        <td>
                          <span className="bg-slate-100 text-text-dark border px-2 py-0.5 rounded text-[10px] font-bold">
                            {item.scope}
                          </span>
                        </td>
                        <td className="font-mono text-primary font-bold">{item.version}</td>
                        <td>
                          <input
                            type="checkbox"
                            checked={item.status}
                            onChange={() => {
                              setModels(prev => prev.map(m => m.id === item.id ? { ...m, status: !m.status } : m))
                              triggerNotification(`模型激活状态已更改。`, 'info')
                            }}
                            className="h-3.5 w-3.5 cursor-pointer"
                          />
                        </td>
                        <td>{item.creator}</td>
                        <td className="font-mono text-text-secondary">{item.created}</td>
                        <td className="font-mono text-text-secondary">{item.updated}</td>
                        <td className="max-w-[120px] truncate text-text-secondary" title={item.remarks}>{item.remarks || '-'}</td>
                        <td className="text-right font-bold">
                          <div className="flex items-center justify-end gap-1.5">
                            <button
                              onClick={() => {
                                setSelectedDetails(item)
                                setIsDetailDrawerOpen(true)
                              }}
                              className="text-text-secondary hover:text-text-dark font-bold text-xs bg-slate-50 border px-2 py-1 rounded cursor-pointer"
                            >
                              查看
                            </button>
                            <button
                              onClick={() => {
                                setEditingModel(item)
                                setModelForm({ ...item })
                                setIsAddModelOpen(true)
                              }}
                              className="text-primary hover:text-primary-hover font-bold text-xs bg-primary/5 border border-primary/20 px-2 py-1 rounded cursor-pointer"
                            >
                              编辑
                            </button>
                            <button
                              onClick={() => {
                                const copied = {
                                  ...item,
                                  id: `MOD-00${models.length + 1}`,
                                  code: `${item.code}_COPY`,
                                  name: `${item.name}_复制版`
                                }
                                setModels(prev => [...prev, copied])
                                triggerNotification(`模型「${item.name}」已成功复制。`, 'success')
                              }}
                              className="text-indigo-600 hover:text-indigo-800 font-bold text-xs bg-indigo-50 border border-indigo-200 px-2 py-1 rounded cursor-pointer"
                            >
                              复制
                            </button>
                            <button
                              onClick={() => {
                                if (confirm(`确认删除评价模型 [${item.code}]？`)) {
                                  setModels(prev => prev.filter(m => m.id !== item.id))
                                  triggerNotification('模型已物理清除。', 'warning')
                                }
                              }}
                              className="text-danger-red hover:text-red-700 font-bold text-xs bg-red-50 border border-red-200 px-2 py-1 rounded cursor-pointer"
                            >
                              删除
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

            </div>
          )}

          {/* ==========================================
              TAB 2: 模型版本 (Timelines + Comparison)
              ========================================== */}
          {activeTab === 'versions' && (
            <div className="flex-grow flex flex-col gap-6">
              
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 flex-grow">
                
                {/* Left: Versions list */}
                <div className="lg:col-span-7 bg-white border border-border-gray rounded-lg p-5 flex flex-col gap-4 shadow-sm">
                  <div className="text-xs font-bold text-text-dark border-b pb-2">模型版本迭代日志</div>
                  
                  <div className="space-y-4">
                    {versions.map((v, idx) => (
                      <div key={idx} className="flex gap-4 relative">
                        {/* Timeline dot/line */}
                        <div className="flex flex-col items-center shrink-0">
                          <div className={`h-4 w-4 rounded-full border-2 flex items-center justify-center ${v.status === '当前激活' ? 'bg-[#52C41A] border-emerald-500' : 'bg-slate-200 border-slate-300'}`}>
                            {v.status === '当前激活' && <Check className="h-2 w-2 text-white" />}
                          </div>
                          {idx !== versions.length - 1 && <div className="w-[2px] bg-slate-200 flex-grow mt-1.5"></div>}
                        </div>

                        <div className="bg-slate-50 border border-slate-200 p-4 rounded-lg flex-grow text-xs space-y-2">
                          <div className="flex items-center justify-between">
                            <span className="font-mono font-bold text-[#11356A] text-sm">{v.version}</span>
                            <span className={`px-2 py-0.5 rounded text-[10px] font-black ${
                              v.status === '当前激活' ? 'bg-emerald-50 text-success-green border border-emerald-250' : 'bg-slate-100 text-slate-400 border border-slate-200'
                            }`}>
                              {v.status}
                            </span>
                          </div>
                          <p className="text-text-secondary leading-relaxed">{v.desc}</p>
                          <div className="flex items-center justify-between text-[10px] text-text-secondary border-t pt-2 mt-2">
                            <div>发布日期：<span className="font-mono">{v.date}</span> | 创建人：{v.creator}</div>
                            <div>历史累计执行：<span className="font-mono font-bold text-primary">{v.runs} 次</span></div>
                          </div>
                          
                          <div className="flex justify-end gap-2 pt-2">
                            <button
                              onClick={() => triggerNotification(`正在预览 ${v.version} 指标权重因子...`, 'info')}
                              className="text-text-secondary hover:text-text-dark font-bold text-xs bg-white border border-slate-300 px-2 py-1 rounded cursor-pointer"
                            >
                              预览
                            </button>
                            <button
                              onClick={() => {
                                if (confirm(`确认回滚至历史版本「${v.version}」吗？`)) {
                                  triggerNotification(`平台评级公式已成功整体回滚至 ${v.version} 版本！`, 'success')
                                }
                              }}
                              disabled={v.status === '当前激活'}
                              className={`font-bold text-xs border px-2 py-1 rounded ${
                                v.status === '当前激活'
                                  ? 'bg-slate-100 text-slate-300 border-slate-200 cursor-not-allowed'
                                  : 'text-primary hover:text-primary-hover bg-primary/5 border-primary/20 cursor-pointer'
                              }`}
                            >
                              回滚至此版本
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Right: Version comparison workbench */}
                <div className="lg:col-span-5 bg-indigo-50/30 border border-indigo-100 rounded-lg p-5 flex flex-col gap-4 shadow-sm">
                  <div className="text-xs font-bold text-[#11356A] flex items-center gap-1 shrink-0 border-b pb-2">
                    <Sliders className="h-4.5 w-4.5 text-indigo-600" />
                    <span>模型版本结构化比对</span>
                  </div>

                  <div className="grid grid-cols-2 gap-4 text-xs">
                    <div>
                      <label className="block text-text-secondary mb-1">比对版本 A</label>
                      <select value={compareVerA} onChange={(e) => setCompareVerA(e.target.value)} className="w-full bg-white border rounded px-2 py-1">
                        <option value="v2.4.0">v2.4.0 (当前激活)</option>
                        <option value="v2.3.8">v2.3.8 (历史版本)</option>
                        <option value="v2.1.0">v2.1.0 (初始版本)</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-text-secondary mb-1">比对版本 B</label>
                      <select value={compareVerB} onChange={(e) => setCompareVerB(e.target.value)} className="w-full bg-white border rounded px-2 py-1">
                        <option value="v2.3.8">v2.3.8 (历史版本)</option>
                        <option value="v2.4.0">v2.4.0 (当前激活)</option>
                        <option value="v2.1.0">v2.1.0 (初始版本)</option>
                      </select>
                    </div>
                  </div>

                  <button
                    onClick={() => {
                      setIsCompareOpen(true)
                      triggerNotification(`成功生成版本对比报告。`, 'success')
                    }}
                    className="w-full py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded shadow cursor-pointer"
                  >
                    生成结构化比对报告
                  </button>

                  <div className="bg-white border rounded p-4 text-xs space-y-3 flex-grow max-h-[220px] overflow-y-auto">
                    <div className="font-bold text-text-dark">版本演化差异推演：</div>
                    <div className="space-y-2 text-[11px] text-text-secondary">
                      <div className="flex items-start gap-1">
                        <span className="text-[#52C41A] font-bold">▲</span>
                        <span><strong>安全质量权重：</strong> 从 15% 提高至 20%</span>
                      </div>
                      <div className="flex items-start gap-1">
                        <span className="text-danger-red font-bold">▼</span>
                        <span><strong>身体健康权重：</strong> 从 15% 调减至 10%</span>
                      </div>
                      <div className="flex items-start gap-1">
                        <span className="text-primary font-bold">●</span>
                        <span><strong>特种持证规则：</strong> 新增「真伪比对」二级卡校验扣分</span>
                      </div>
                    </div>
                  </div>
                </div>

              </div>

            </div>
          )}

          {/* ==========================================
              TAB 3: 维度权重 (Sliders + Dynamic Chart)
              ========================================== */}
          {activeTab === 'weight' && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 flex-grow">
              
              {/* Sliders panel */}
              <div className="lg:col-span-7 bg-white border border-border-gray rounded-lg p-5 flex flex-col gap-6 shadow-sm">
                <div className="flex items-center justify-between border-b pb-3 shrink-0">
                  <div className="text-xs font-bold text-text-dark">权重滑块配比设定 (Total: 100%)</div>
                  <button
                    onClick={handleAutoBalance}
                    className="px-3 py-1 bg-white border border-slate-300 text-text-dark text-xs font-bold rounded shadow-sm hover:bg-slate-50 cursor-pointer"
                  >
                    重置为平衡权重
                  </button>
                </div>

                <div className="space-y-5">
                  {[
                    { key: 'professional', label: '👨‍✈️ 职业能力', desc: '评估工人专业岗位技能、特种持证、实操竞赛荣誉等' },
                    { key: 'fulfillment', label: '⏰ 履约能力', desc: '考核打卡考勤率、项目进出场注销、工时合同备案等' },
                    { key: 'safety', label: '⚠️ 安全能力', desc: '考核违章通报扣分、安全教育合格率、班前晨会出席等' },
                    { key: 'health', label: '🩺 健康能力', desc: '体检合格、高空作业禁忌症筛查、年龄健康诊断等' },
                    { key: 'credit', label: '🏅 信用能力', desc: '第三方信用评级对接、失信核查、工会守信档案等' }
                  ].map(item => (
                    <div key={item.key} className="space-y-1.5">
                      <div className="flex items-center justify-between text-xs">
                        <span className="font-bold text-text-dark">{item.label}</span>
                        <span className="font-mono font-bold text-primary bg-primary/5 px-2 py-0.5 rounded">
                          {sliders[item.key]} %
                        </span>
                      </div>
                      <div className="flex items-center gap-3">
                        <input
                          type="range"
                          min="0"
                          max="100"
                          value={sliders[item.key]}
                          onChange={(e) => {
                            const val = parseInt(e.target.value) || 0
                            setSliders({ ...sliders, [item.key]: val })
                          }}
                          className="flex-grow h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-primary"
                        />
                      </div>
                      <p className="text-[10px] text-text-secondary">{item.desc}</p>
                    </div>
                  ))}
                </div>

                {/* Validation alert box */}
                <div className={`p-4 rounded-lg text-xs flex items-center justify-between shrink-0 border ${
                  totalSliderSum === 100
                    ? 'bg-emerald-50 border-emerald-250 text-success-green'
                    : 'bg-red-50 border-red-250 text-danger-red animate-pulse'
                }`}>
                  <div className="flex items-center gap-2">
                    <AlertCircle className="h-4.5 w-4.5 shrink-0" />
                    <span>
                      当前已分配总权重：<strong className="font-mono font-black text-sm">{totalSliderSum}%</strong>
                      {totalSliderSum === 100 ? '（分配恰当，模型可以保存运行）' : '（注意：总权重必须精确等于 100% 才能保存发布模型）'}
                    </span>
                  </div>
                  <button
                    onClick={() => {
                      if (totalSliderSum === 100) {
                        triggerNotification('维度权重公式调整并发布成功！', 'success')
                      } else {
                        triggerNotification('权重不匹配 100%，发布已被系统拦截阻断！', 'error')
                      }
                    }}
                    disabled={totalSliderSum !== 100}
                    className={`px-4 py-1.5 font-bold text-xs rounded shadow-sm transition-colors cursor-pointer ${
                      totalSliderSum === 100
                        ? 'bg-[#11356A] hover:bg-primary-hover text-white'
                        : 'bg-slate-200 text-slate-400 border border-slate-300 cursor-not-allowed'
                    }`}
                  >
                    保存权重公式
                  </button>
                </div>
              </div>

              {/* Pie/Donut Chart panel */}
              <div className="lg:col-span-5 bg-slate-50 border border-border-gray rounded-lg p-5 flex flex-col items-center justify-center text-center shadow-sm min-h-[300px]">
                <div className="text-xs font-bold text-text-dark mb-6">实时模型权重占比分布图</div>
                
                {/* SVG Circular Donut Chart */}
                <div className="relative w-48 h-48 flex items-center justify-center">
                  <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
                    {/* Background Circle */}
                    <circle cx="50" cy="50" r="40" fill="transparent" stroke="#E2E8F0" strokeWidth="12" />
                    
                    {/* Dynamic slices using calculated stroke-dasharrays */}
                    {(() => {
                      let accumulatedPercent = 0
                      const colors = ['#11356A', '#1890FF', '#52C41A', '#FA8C16', '#F5222D']
                      const strokeDashArrays = [
                        (sliders.professional / 100) * 251.2,
                        (sliders.fulfillment / 100) * 251.2,
                        (sliders.safety / 100) * 251.2,
                        (sliders.health / 100) * 251.2,
                        (sliders.credit / 100) * 251.2
                      ]

                      return strokeDashArrays.map((dash, i) => {
                        const offset = 251.2 - (accumulatedPercent / 100) * 251.2
                        accumulatedPercent += Object.values(sliders)[i]
                        return (
                          <circle
                            key={i}
                            cx="50"
                            cy="50"
                            r="40"
                            fill="transparent"
                            stroke={colors[i]}
                            strokeWidth="12"
                            strokeDasharray={`${dash} 251.2`}
                            strokeDashoffset={offset}
                            strokeLinecap="round"
                            className="transition-all duration-300"
                          />
                        )
                      })
                    })()}
                  </svg>

                  {/* Core Value overlay */}
                  <div className="absolute flex flex-col items-center justify-center">
                    <span className="text-[10px] text-text-secondary font-bold">总配比</span>
                    <span className={`text-xl font-black font-mono leading-none ${totalSliderSum === 100 ? 'text-[#11356A]' : 'text-danger-red'}`}>
                      {totalSliderSum}%
                    </span>
                  </div>
                </div>

                {/* Legends */}
                <div className="grid grid-cols-2 gap-x-4 gap-y-2 text-[10px] mt-6 w-full text-left">
                  <div className="flex items-center gap-1.5"><div className="h-2.5 w-2.5 bg-[#11356A] rounded-sm"></div><span>职业能力 ({sliders.professional}%)</span></div>
                  <div className="flex items-center gap-1.5"><div className="h-2.5 w-2.5 bg-[#1890FF] rounded-sm"></div><span>履约能力 ({sliders.fulfillment}%)</span></div>
                  <div className="flex items-center gap-1.5"><div className="h-2.5 w-2.5 bg-[#52C41A] rounded-sm"></div><span>安全能力 ({sliders.safety}%)</span></div>
                  <div className="flex items-center gap-1.5"><div className="h-2.5 w-2.5 bg-[#FA8C16] rounded-sm"></div><span>健康能力 ({sliders.health}%)</span></div>
                  <div className="flex items-center gap-1.5"><div className="h-2.5 w-2.5 bg-[#F5222D] rounded-sm"></div><span>信用能力 ({sliders.credit}%)</span></div>
                </div>
              </div>

            </div>
          )}

          {/* ==========================================
              TAB 4: 等级规则配置 (Grade Card layout)
              ========================================== */}
          {activeTab === 'levels' && (
            <div className="flex-grow flex flex-col gap-6">
              
              <div className="flex items-center justify-between border-b pb-3 shrink-0">
                <div className="text-xs text-text-secondary font-bold">
                  等级划分由模型后台决定，修改各评价分值段的最小、最大门槛即可实时调整工人分布结构。
                </div>
                <button
                  onClick={() => {
                    setLevelForm({
                      id: `l_${Date.now()}`,
                      name: 'F级',
                      label: '警退考核人员',
                      min: 0,
                      max: 49,
                      color: '#BFBFBF',
                      desc: '屡教不改安全违章，列入退出或黑名单警示。'
                    })
                    setIsAddLevelOpen(true)
                  }}
                  className="px-3.5 py-1.5 bg-[#52C41A] hover:bg-emerald-600 text-white rounded font-bold text-xs shadow-sm cursor-pointer flex items-center gap-1"
                >
                  <Plus className="h-3.5 w-3.5" />
                  新增等级
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-5 gap-4 flex-grow">
                {levels.map(l => (
                  <div key={l.id} className="bg-slate-50 border border-slate-200 rounded-lg p-4 flex flex-col justify-between hover:shadow-md transition-shadow relative">
                    <div className="absolute top-0 left-0 h-full w-1.5 rounded-l-lg" style={{ backgroundColor: l.color }}></div>
                    <div className="pl-2">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm font-black text-text-dark font-mono" style={{ color: l.color }}>{l.name}</span>
                        <span className="text-[10px] text-text-secondary font-bold bg-white px-2 py-0.5 border rounded">
                          {l.label}
                        </span>
                      </div>
                      <p className="text-[11px] text-text-secondary leading-relaxed mb-4">{l.desc}</p>
                    </div>

                    <div className="border-t pt-3 pl-2 mt-4 space-y-2 text-xs">
                      <div className="flex justify-between font-mono">
                        <span className="text-text-secondary">评价分数区间:</span>
                        <span className="font-bold text-text-dark">[{l.min} - {l.max}] 分</span>
                      </div>
                      <div className="flex items-center justify-between pt-1">
                        <span className="text-text-secondary">视觉配色:</span>
                        <div className="h-3.5 w-8 rounded border shadow-sm" style={{ backgroundColor: l.color }}></div>
                      </div>
                      <div className="flex items-center justify-end gap-1.5 pt-2">
                        <button
                          onClick={() => {
                            setLevelForm({ ...l })
                            setIsAddLevelOpen(true)
                          }}
                          className="px-2 py-1 bg-white hover:bg-slate-100 border text-[10px] font-bold rounded cursor-pointer"
                        >
                          修改
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

            </div>
          )}

          {/* ==========================================
              TAB 5: 模型执行与模拟 (Immediate + Timed + Simulator)
              ========================================== */}
          {activeTab === 'exec' && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 flex-grow">
              
              {/* Left Column: Immediate Execution Console */}
              <div className="lg:col-span-6 bg-white border border-border-gray rounded-lg p-5 flex flex-col gap-6 shadow-sm">
                
                <div className="flex items-center justify-between border-b pb-3 shrink-0">
                  <div className="text-xs font-bold text-text-dark flex items-center gap-1">
                    <Activity className="h-4.5 w-4.5 text-primary" />
                    <span>模型计算引擎控制台</span>
                  </div>
                  <div className="flex bg-slate-100 p-1 rounded border self-start">
                    {[
                      { id: 'immediate', label: '立即执行' },
                      { id: 'scheduled', label: '定时配置' }
                    ].map(btn => (
                      <button
                        key={btn.id}
                        onClick={() => setExecType(btn.id)}
                        className={`px-3 py-0.5 text-[10px] font-bold rounded cursor-pointer transition-colors ${
                          execType === btn.id ? 'bg-[#11356A] text-white shadow-sm' : 'text-text-secondary'
                        }`}
                      >
                        {btn.label}
                      </button>
                    ))}
                  </div>
                </div>

                {execType === 'immediate' && (
                  <div className="space-y-4 text-xs">
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block font-bold text-text-secondary mb-1">选择执行项目</label>
                        <select value={execProject} onChange={(e) => setExecProject(e.target.value)} className="w-full bg-white border rounded px-2.5 py-1.5 text-text-dark">
                          <option value="北京CBD东区超高层项目">北京CBD东区超高层项目</option>
                          <option value="北京轨道交通28号线项目">北京轨道交通28号线项目</option>
                          <option value="城市绿心剧院机电安装项目">城市绿心剧院机电安装项目</option>
                        </select>
                      </div>
                      <div>
                        <label className="block font-bold text-text-secondary mb-1">评价覆盖范围</label>
                        <select value={execScopeSelect} onChange={(e) => setExecScopeSelect(e.target.value)} className="w-full bg-white border rounded px-2.5 py-1.5 text-text-dark">
                          <option value="全员">当前项目全员 (在场 + 历史)</option>
                          <option value="塔吊特种班组">塔吊特种班组</option>
                          <option value="电工挂载班组">电工挂载班组</option>
                        </select>
                      </div>
                    </div>

                    <div>
                      <label className="block font-bold text-text-secondary mb-1">本次评价备份版本号</label>
                      <input type="text" disabled value="v2.4.0 (当前激活模式)" className="w-full bg-slate-50 border rounded px-2.5 py-1.5 text-text-secondary font-mono" />
                    </div>

                    <button
                      type="button"
                      onClick={handleStartImmediateRun}
                      disabled={isRunning}
                      className={`w-full py-2.5 text-white font-bold rounded shadow transition-colors cursor-pointer flex items-center justify-center gap-1.5 ${
                        isRunning ? 'bg-slate-400 cursor-not-allowed' : 'bg-primary hover:bg-[#1b3d6f]'
                      }`}
                    >
                      <Play className="h-4 w-4 fill-current animate-pulse" />
                      立即启动评价引擎
                    </button>

                    {isRunning && (
                      <div className="bg-slate-50 border p-4 rounded-lg space-y-3 animate-zoom-in">
                        <div className="flex justify-between items-center text-[10px] text-text-secondary">
                          <span className="font-bold text-primary animate-pulse">{runStepText}</span>
                          <span className="font-mono font-bold">{runProgress}%</span>
                        </div>
                        {/* Progress Bar */}
                        <div className="w-full bg-slate-200 h-2.5 rounded-full overflow-hidden">
                          <div className="bg-[#52C41A] h-full transition-all duration-200" style={{ width: `${runProgress}%` }}></div>
                        </div>
                        <div className="grid grid-cols-4 gap-2 text-center text-[10px] text-text-secondary pt-2">
                          <div>
                            <span className="block font-bold font-mono text-text-dark">{runTotal} 人</span>
                            <span>覆盖总数</span>
                          </div>
                          <div>
                            <span className="block font-bold font-mono text-success-green">{runSuccess} 人</span>
                            <span>已完成评估</span>
                          </div>
                          <div>
                            <span className="block font-bold font-mono text-danger-red">{runFailed} 人</span>
                            <span>校验失败</span>
                          </div>
                          <div>
                            <span className="block font-bold font-mono text-primary">{runTotal - runSuccess - runFailed} 人</span>
                            <span>等待评估</span>
                          </div>
                        </div>
                      </div>
                    )}

                  </div>
                )}

                {execType === 'scheduled' && (
                  <div className="space-y-4 text-xs">
                    <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 text-primary">
                      <div className="font-bold flex items-center gap-1">
                        <Info className="h-4 w-4" />
                        定时自动调度引擎
                      </div>
                      <p className="text-[11px] leading-relaxed mt-1">
                        系统集成 Crontab 定时执行规则，每天夜间自动加载全国建筑工人实名制接口及当日同步数据，自动清洗并重计算工人画像雷达值。
                      </p>
                    </div>

                    <table className="w-full text-left text-xs bg-slate-50 border">
                      <thead>
                        <tr className="bg-slate-100 border-b">
                          <th className="p-2">定时任务名称</th>
                          <th className="p-2">周期频率</th>
                          <th className="p-2">Cron 时间</th>
                          <th className="p-2">定时开关</th>
                        </tr>
                      </thead>
                      <tbody>
                        {[
                          { name: '全项目综合评价', period: '每天', cron: '00:00:00', status: true },
                          { name: '高危特种防范清洗', period: '每周日', cron: '23:00:00', status: true },
                          { name: '季度新星班组核查', period: '每月1号', cron: '01:00:00', status: false }
                        ].map((t, idx) => (
                          <tr key={idx} className="border-b">
                            <td className="p-2 font-bold text-text-dark">{t.name}</td>
                            <td className="p-2">{t.period}</td>
                            <td className="p-2 font-mono text-text-secondary">{t.cron}</td>
                            <td className="p-2">
                              <input
                                type="checkbox"
                                defaultChecked={t.status}
                                onChange={() => triggerNotification('定时调度器状态修改已同步至集团服务器。', 'warning')}
                                className="h-3.5 w-3.5 cursor-pointer"
                              />
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}

              </div>

              {/* Right Column: Dynamic Simulation Workstation (AI features) */}
              <div className="lg:col-span-6 bg-indigo-50/20 border border-indigo-100 rounded-lg p-5 flex flex-col gap-5 shadow-sm">
                
                <div className="flex items-center justify-between border-b pb-3 shrink-0">
                  <div className="text-xs font-bold text-[#11356A] flex items-center gap-1.5">
                    <Sparkles className="h-4.5 w-4.5 text-indigo-600 animate-pulse" />
                    <span>工人综合评价 AI 仿真沙盒</span>
                  </div>
                  <div>
                    <select
                      value={simWorkerId}
                      onChange={(e) => setSimWorkerId(e.target.value)}
                      className="bg-white border rounded px-2.5 py-1 text-xs text-text-dark"
                    >
                      <option value="w1">张建国 (特种塔吊工)</option>
                      <option value="w2">李强 (架子工)</option>
                      <option value="w3">王朝阳 (电焊工)</option>
                      <option value="w4">刘小虎 (普工)</option>
                    </select>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={handleRunSimulator}
                  disabled={simulating}
                  className="w-full py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded shadow cursor-pointer transition-colors"
                >
                  {simulating ? 'AI 大脑评分测演中...' : '开始仿真测演模拟'}
                </button>

                {simResult && (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs flex-grow overflow-y-auto animate-zoom-in">
                    
                    {/* Visual Radar, Overall Score & Grade Badge */}
                    <div className="bg-white border rounded-lg p-4 flex flex-col items-center justify-between shadow-sm">
                      <span className="font-bold text-[10px] text-text-secondary uppercase">综合评价评估算分</span>
                      
                      <div className="relative w-32 h-32 flex items-center justify-center mt-2">
                        {/* Circular progress bar */}
                        <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
                          <circle cx="50" cy="50" r="42" fill="transparent" stroke="#E2E8F0" strokeWidth="8" />
                          <circle cx="50" cy="50" r="42" fill="transparent" stroke="#52C41A" strokeWidth="8" strokeDasharray="263.8" strokeDashoffset={263.8 - (simResult.score / 100) * 263.8} strokeLinecap="round" />
                        </svg>
                        <div className="absolute flex flex-col items-center">
                          <span className="text-2xl font-black font-mono text-text-dark leading-none">{simResult.score}</span>
                          <span className="text-[9px] text-[#52C41A] font-bold bg-emerald-50 px-1.5 py-0.2 rounded border border-emerald-200 mt-1">
                            {simResult.level}
                          </span>
                        </div>
                      </div>

                      {/* Explicit numerical labels below */}
                      <div className="grid grid-cols-2 gap-x-2 gap-y-1 text-[9.5px] mt-4 w-full text-left">
                        <div>职业能力: <span className="font-bold text-primary font-mono">{simResult.details.capability}</span></div>
                        <div>履约能力: <span className="font-bold text-primary font-mono">{simResult.details.attendance}</span></div>
                        <div>安全行为: <span className="font-bold text-primary font-mono">{simResult.details.safety}</span></div>
                        <div>身心健康: <span className="font-bold text-primary font-mono">{simResult.details.health}</span></div>
                      </div>
                    </div>

                    {/* AI Explanation & Recommendations Box */}
                    <div className="bg-indigo-50 border border-indigo-150 p-4 rounded-lg flex flex-col justify-between shadow-sm">
                      <div className="flex items-center gap-1 text-[11px] font-bold text-[#11356A]">
                        <Cpu className="h-4 w-4 text-indigo-500 animate-spin" />
                        <span>AI大模型评价报告推演</span>
                      </div>
                      
                      <p className="text-[10px] text-indigo-900 leading-relaxed mt-2 flex-grow">
                        工人属于<strong>【{simResult.level}】级别</strong>。主要得分子系统源于：
                        连续考勤出满（{simResult.details.attendance}分），且特种塔吊操作证AI-OCR真伪核验已通过。安全违章处罚次数为0。
                      </p>

                      <div className="border-t border-indigo-150 pt-2 mt-2 space-y-1.5 text-[9.5px]">
                        <div>💡 <strong>AI 培养建议：</strong> 特种特优人才，建议作为项目班组长梯队考察培养。</div>
                        <div>⚠️ <strong>AI 风险提醒：</strong> 目前健康体检临期，建议本周督促补登体检。</div>
                      </div>
                    </div>

                  </div>
                )}

              </div>

            </div>
          )}

          {/* ==========================================
              TAB 6: 执行记录 (History list)
              ========================================== */}
          {activeTab === 'logs' && (
            <div className="flex-grow flex flex-col gap-6">
              
              <div className="flex-grow border border-border-gray rounded-lg overflow-x-auto">
                <table className="b-table text-xs">
                  <thead>
                    <tr>
                      <th>运行编号</th>
                      <th>开始执行时间</th>
                      <th>启动发件人</th>
                      <th>覆盖评价项目</th>
                      <th>实名覆盖总数</th>
                      <th>评价成功数</th>
                      <th>校验失败数</th>
                      <th>运行同步方式</th>
                      <th>运算耗时</th>
                      <th>状态</th>
                      <th className="text-right">操作</th>
                    </tr>
                  </thead>
                  <tbody>
                    {execLogs.map(log => (
                      <tr key={log.id} className="hover:bg-slate-50 transition-colors">
                        <td className="font-mono font-bold text-[#11356A]">{log.id}</td>
                        <td className="font-mono text-text-secondary">{log.time}</td>
                        <td className="font-bold text-text-dark">{log.creator}</td>
                        <td>{log.project}</td>
                        <td className="font-mono font-semibold text-text-dark">{log.total} 人</td>
                        <td className="font-mono font-bold text-success-green">{log.success} 人</td>
                        <td className="font-mono font-bold text-danger-red">{log.failed} 人</td>
                        <td>
                          <span className="bg-slate-100 text-slate-700 border px-1.5 py-0.2 rounded text-[10px]">
                            {log.type}
                          </span>
                        </td>
                        <td className="font-mono text-text-secondary">{log.duration}</td>
                        <td>
                          <span className="bg-emerald-50 text-success-green border border-emerald-250 px-2 py-0.5 rounded font-black text-[10px]">
                            {log.status}
                          </span>
                        </td>
                        <td className="text-right">
                          <button
                            onClick={() => {
                              setSelectedLog(log)
                              setIsLogDrawerOpen(true)
                            }}
                            className="text-primary hover:text-primary-hover font-bold text-xs bg-primary/5 border border-primary/20 px-2 py-1 rounded cursor-pointer"
                          >
                            查看运行日志
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

            </div>
          )}

        </div>
      </div>

      {/* ======================================================================
          DRAWER 1: ADD/EDIT MODEL (新增/修改模型配置右侧抽屉)
          ====================================================================== */}
      {isAddModelOpen && (
        <div className="fixed inset-0 z-50 flex justify-end">
          {/* Overlay */}
          <div className="absolute inset-0 bg-black/50 transition-opacity" onClick={() => setIsAddModelOpen(false)}></div>

          {/* Form Panel */}
          <form
            onSubmit={handleSaveModel}
            className="relative w-full max-w-lg bg-white h-full shadow-2xl flex flex-col z-10 animate-slide-in"
          >
            {/* Header */}
            <div className="p-5 border-b bg-slate-50 border-slate-200 flex items-center justify-between shrink-0">
              <h3 className="text-sm font-black text-text-dark flex items-center gap-1.5">
                <Sliders className="h-4.5 w-4.5 text-primary animate-pulse" />
                <span>{editingModel ? '编辑评价模型配置' : '新增评价模型'}</span>
              </h3>
              <button type="button" onClick={() => setIsAddModelOpen(false)} className="text-slate-400 hover:text-slate-600 p-1">
                <X className="h-5 w-5" />
              </button>
            </div>

            {/* Scrollable inputs */}
            <div className="flex-grow p-6 overflow-y-auto space-y-4 text-xs">
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block font-bold text-text-secondary mb-1">模型唯一编码</label>
                  <input
                    type="text"
                    required
                    value={modelForm.code}
                    onChange={(e) => setModelForm({ ...modelForm, code: e.target.value })}
                    placeholder="如: MODEL_HIGH_SAFE"
                    className="w-full bg-white border border-slate-300 rounded px-2.5 py-1.5 text-text-dark font-mono font-bold"
                  />
                </div>
                <div>
                  <label className="block font-bold text-text-secondary mb-1">适用评价项目</label>
                  <select
                    value={modelForm.scope}
                    onChange={(e) => setModelForm({ ...modelForm, scope: e.target.value })}
                    className="w-full bg-white border border-slate-300 rounded px-2.5 py-1.5 text-text-dark"
                  >
                    <option value="集团全项目">集团全项目</option>
                    <option value="高处作业/特种班组">高处作业/特种班组</option>
                    <option value="各工种班组长">各工种班组长</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-bold text-text-secondary mb-1">模型名称</label>
                <input
                  type="text"
                  required
                  value={modelForm.name}
                  onChange={(e) => setModelForm({ ...modelForm, name: e.target.value })}
                  placeholder="请输入评价模型名称"
                  className="w-full bg-white border border-slate-300 rounded px-2.5 py-1.5 text-text-dark"
                />
              </div>

              <div>
                <label className="block font-bold text-text-secondary mb-1">是否立即启用</label>
                <input
                  type="checkbox"
                  checked={modelForm.status}
                  onChange={(e) => setModelForm({ ...modelForm, status: e.target.checked })}
                  className="h-4 w-4 cursor-pointer"
                />
              </div>

              <div>
                <label className="block font-bold text-text-secondary mb-1">模型说明</label>
                <textarea
                  required
                  rows="3"
                  value={modelForm.remarks}
                  onChange={(e) => setModelForm({ ...modelForm, remarks: e.target.value })}
                  placeholder="该评价模型的主要考核方向和应用背景描述..."
                  className="w-full bg-white border border-slate-300 rounded px-2.5 py-1.5 text-xs text-text-dark"
                ></textarea>
              </div>

            </div>

            {/* Footer */}
            <div className="p-4 border-t bg-slate-50 border-slate-200 flex items-center justify-end gap-2 shrink-0">
              <button
                type="button"
                onClick={() => setIsAddModelOpen(false)}
                className="px-4 py-2 bg-white border border-slate-300 text-text-dark font-bold rounded shadow-sm cursor-pointer"
              >
                取消
              </button>
              <button
                type="submit"
                className="px-5 py-2 bg-primary hover:bg-[#1b3d6f] text-white font-bold rounded shadow cursor-pointer transition-colors"
              >
                保存模型
              </button>
            </div>
          </form>
        </div>
      )}

      {/* ======================================================================
          DRAWER 2: MODEL DETAIL VIEW (查看模型详情右侧抽屉)
          ====================================================================== */}
      {isDetailDrawerOpen && selectedDetails && (
        <div className="fixed inset-0 z-50 flex justify-end">
          {/* Overlay */}
          <div className="absolute inset-0 bg-black/50 transition-opacity" onClick={() => setIsDetailDrawerOpen(false)}></div>

          {/* Details Panel */}
          <div className="relative w-full max-w-lg bg-white h-full shadow-2xl flex flex-col z-10 animate-slide-in">
            {/* Header */}
            <div className="p-5 border-b bg-slate-50 border-slate-200 flex items-center justify-between shrink-0">
              <h3 className="text-sm font-black text-text-dark flex items-center gap-1.5">
                <Info className="h-4.5 w-4.5 text-primary" />
                <span>评价模型元数据详情</span>
              </h3>
              <button onClick={() => setIsDetailDrawerOpen(false)} className="text-slate-400 hover:text-slate-600 p-1">
                <X className="h-5 w-5" />
              </button>
            </div>

            {/* Body */}
            <div className="flex-1 p-6 overflow-y-auto space-y-6 text-xs">
              
              <div className="bg-slate-50 border rounded-lg p-5 space-y-3">
                <div className="flex justify-between items-center">
                  <span className="font-mono font-bold text-[#11356A] text-sm">{selectedDetails.code}</span>
                  <span className="bg-emerald-50 text-success-green border border-emerald-250 px-2 py-0.5 rounded text-[10px] font-bold">
                    已激活运行
                  </span>
                </div>
                <h4 className="font-bold text-text-dark text-sm leading-tight">{selectedDetails.name}</h4>
                <p className="text-text-secondary leading-relaxed">{selectedDetails.remarks}</p>
              </div>

              {/* Scope details */}
              <div className="space-y-3">
                <div className="text-xs font-bold text-text-dark border-l-4 border-primary pl-2 uppercase tracking-wide">
                  模型运算元数据
                </div>
                <div className="bg-slate-50 border rounded p-4 space-y-3">
                  <div>
                    <span className="text-text-secondary">适用范围：</span>
                    <span className="font-bold text-text-dark">{selectedDetails.scope}</span>
                  </div>
                  <div>
                    <span className="text-text-secondary">当前版本：</span>
                    <span className="font-bold text-indigo-700">{selectedDetails.version}</span>
                  </div>
                  <div>
                    <span className="text-text-secondary">创建人：</span>
                    <span className="text-text-dark font-medium">{selectedDetails.creator}</span>
                  </div>
                  <div>
                    <span className="text-text-secondary">初创上线时间：</span>
                    <span className="font-mono text-text-secondary">{selectedDetails.created}</span>
                  </div>
                </div>
              </div>

            </div>

            {/* Footer */}
            <div className="p-4 border-t bg-slate-50 border-slate-200 flex items-center justify-end shrink-0">
              <button
                onClick={() => setIsDetailDrawerOpen(false)}
                className="px-4 py-2 bg-primary hover:bg-[#1b3d6f] text-white text-xs font-bold rounded shadow-sm cursor-pointer"
              >
                确认关闭
              </button>
            </div>

          </div>
        </div>
      )}

      {/* ======================================================================
          DRAWER 3: EXECUTION LOGS VIEWER (查看运行日志右侧抽屉)
          ====================================================================== */}
      {isLogDrawerOpen && selectedLog && (
        <div className="fixed inset-0 z-50 flex justify-end">
          {/* Overlay */}
          <div className="absolute inset-0 bg-black/50 transition-opacity" onClick={() => setIsLogDrawerOpen(false)}></div>

          {/* Logs Panel */}
          <div className="relative w-full max-w-lg bg-white h-full shadow-2xl flex flex-col z-10 animate-slide-in">
            {/* Header */}
            <div className="p-5 border-b bg-slate-50 border-slate-200 flex items-center justify-between shrink-0">
              <h3 className="text-sm font-black text-text-dark flex items-center gap-1.5">
                <FileText className="h-4.5 w-4.5 text-primary" />
                <span>运行记录详细审计日志 - {selectedLog.id}</span>
              </h3>
              <button onClick={() => setIsLogDrawerOpen(false)} className="text-slate-400 hover:text-slate-600 p-1">
                <X className="h-5 w-5" />
              </button>
            </div>

            {/* Body */}
            <div className="flex-1 p-6 overflow-y-auto space-y-6 text-xs">
              
              <div className="bg-slate-900 text-slate-350 p-4 rounded-lg font-mono text-[10px] space-y-2 max-h-[300px] overflow-y-auto">
                <div className="text-success-green font-bold">[ENGINE INFO] 启动评价任务调度 ID: {selectedLog.id}</div>
                <div>[ENGINE INFO] 开始时间: {selectedLog.time}</div>
                <div>[ENGINE INFO] 执行模型: 通用评级模型 v2.4.0</div>
                <div>[ENGINE INFO] 洗涤在场劳务数据库记录数: {selectedLog.total} 行</div>
                <div>[ENGINE INFO] 清洗比对计算正常: {selectedLog.success} 项</div>
                {selectedLog.failed > 0 ? (
                  <>
                    <div className="text-danger-red font-bold">[ENGINE ERROR] 校验失败阻断记录数: {selectedLog.failed} 行</div>
                    <div className="text-danger-red">[ENGINE ERROR] 失败原因 1: 身份证在实名平台未查询到在场备案信息 (张小泉)</div>
                    <div className="text-danger-red">[ENGINE ERROR] 失败原因 2: 特种操作证编号在国资库校验显示已过期 (黄飞鸿)</div>
                  </>
                ) : (
                  <div className="text-success-green font-bold">[ENGINE INFO] 跑分引擎无任何校验警告。</div>
                )}
                <div className="text-[#1890FF]">[ENGINE INFO] 结算耗时: {selectedLog.duration}，状态：正常入库</div>
              </div>

              {selectedLog.failed > 0 && (
                <div className="space-y-2">
                  <div className="text-xs font-bold text-text-dark border-l-4 border-primary pl-2 uppercase tracking-wide">
                    系统重试与人工清洗对账
                  </div>
                  <button
                    onClick={() => {
                      triggerNotification('重试执行指令已下发，正在补打补登实名制缺失数据...', 'info')
                      setIsLogDrawerOpen(false)
                    }}
                    className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded shadow-sm text-xs cursor-pointer w-full text-center"
                  >
                    一键启动缺失数据清洗并重计算
                  </button>
                </div>
              )}

            </div>

            {/* Footer */}
            <div className="p-4 border-t bg-slate-50 border-slate-200 flex items-center justify-end shrink-0">
              <button
                onClick={() => setIsLogDrawerOpen(false)}
                className="px-4 py-2 bg-primary hover:bg-[#1b3d6f] text-white text-xs font-bold rounded shadow-sm cursor-pointer"
              >
                确认关闭
              </button>
            </div>

          </div>
        </div>
      )}

      {/* ======================================================================
          MODAL: ADD LEVEL (新增/修改评分级别模态框)
          ====================================================================== */}
      {isAddLevelOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/50" onClick={() => setIsAddLevelOpen(false)}></div>
          <form
            onSubmit={(e) => {
              e.preventDefault()
              setLevels([...levels, levelForm])
              triggerNotification(`已添加评分等级规则：${levelForm.name}`, 'success')
              setIsAddLevelOpen(false)
            }}
            className="relative bg-white rounded-lg shadow-2xl w-full max-w-md flex flex-col z-10 overflow-hidden animate-zoom-in text-xs"
          >
            <div className="p-4 border-b bg-slate-50 border-slate-200 flex items-center justify-between">
              <h3 className="text-sm font-bold text-text-dark">新增评分等级界限</h3>
              <button type="button" onClick={() => setIsAddLevelOpen(false)} className="text-slate-400 hover:text-slate-600">
                <X className="h-5 w-5" />
              </button>
            </div>
            <div className="p-6 space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block font-bold text-text-secondary mb-1">等级字符</label>
                  <input
                    type="text"
                    required
                    value={levelForm.name}
                    onChange={(e) => setLevelForm({ ...levelForm, name: e.target.value })}
                    placeholder="如: F级"
                    className="w-full bg-white border rounded px-3 py-1.5 text-text-dark font-bold font-mono"
                  />
                </div>
                <div>
                  <label className="block font-bold text-text-secondary mb-1">等级文字标志</label>
                  <input
                    type="text"
                    required
                    value={levelForm.label}
                    onChange={(e) => setLevelForm({ ...levelForm, label: e.target.value })}
                    placeholder="如: 警退考核人员"
                    className="w-full bg-white border rounded px-3 py-1.5 text-text-dark"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block font-bold text-text-secondary mb-1">分值区间底限</label>
                  <input
                    type="number"
                    required
                    value={levelForm.min}
                    onChange={(e) => setLevelForm({ ...levelForm, min: parseInt(e.target.value) || 0 })}
                    className="w-full bg-white border rounded px-3 py-1.5 text-text-dark font-mono"
                  />
                </div>
                <div>
                  <label className="block font-bold text-text-secondary mb-1">分值区间上限</label>
                  <input
                    type="number"
                    required
                    value={levelForm.max}
                    onChange={(e) => setLevelForm({ ...levelForm, max: parseInt(e.target.value) || 0 })}
                    className="w-full bg-white border rounded px-3 py-1.5 text-text-dark font-mono"
                  />
                </div>
              </div>
              <div>
                <label className="block font-bold text-text-secondary mb-1">视觉标志颜色</label>
                <input
                  type="color"
                  value={levelForm.color}
                  onChange={(e) => setLevelForm({ ...levelForm, color: e.target.value })}
                  className="w-full h-8 cursor-pointer rounded border"
                />
              </div>
              <div>
                <label className="block font-bold text-text-secondary mb-1">规则判定条件说明</label>
                <textarea
                  required
                  rows="3"
                  value={levelForm.desc}
                  onChange={(e) => setLevelForm({ ...levelForm, desc: e.target.value })}
                  className="w-full bg-white border rounded px-3 py-2 text-text-dark"
                ></textarea>
              </div>
            </div>
            <div className="p-4 border-t bg-slate-50 border-slate-200 flex justify-end gap-2">
              <button type="button" onClick={() => setIsAddLevelOpen(false)} className="px-4 py-2 bg-white border rounded shadow-sm font-bold text-text-dark cursor-pointer">
                取消
              </button>
              <button type="submit" className="px-4 py-2 bg-[#52C41A] text-white rounded shadow font-bold cursor-pointer">
                添加级别
              </button>
            </div>
          </form>
        </div>
      )}

      {/* ======================================================================
          MODAL: VERSION COMPARE (版本差异左右多字段比对弹窗)
          ====================================================================== */}
      {isCompareOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/60" onClick={() => setIsCompareOpen(false)}></div>
          <div className="relative bg-white rounded-lg shadow-2xl w-full max-w-4xl flex flex-col z-10 overflow-hidden animate-zoom-in text-xs">
            <div className="p-4 border-b bg-slate-50 border-slate-200 flex items-center justify-between">
              <h3 className="text-sm font-bold text-text-dark flex items-center gap-1">
                <Sliders className="h-4.5 w-4.5 text-primary" />
                <span>评价模型版本对比差异分析 ({compareVerA} vs {compareVerB})</span>
              </h3>
              <button type="button" onClick={() => setIsCompareOpen(false)} className="text-slate-400 hover:text-slate-600">
                <X className="h-5 w-5" />
              </button>
            </div>
            
            <div className="p-6 grid grid-cols-2 gap-6 overflow-y-auto max-h-[480px]">
              {/* Version A */}
              <div className="bg-slate-50 border rounded-lg p-5 space-y-4">
                <div className="font-mono font-bold text-primary text-sm border-b pb-2">Version A: {compareVerA}</div>
                <div className="space-y-2">
                  <span className="font-bold text-text-dark block">1. 评价维度滑块占比：</span>
                  <div className="space-y-1 text-[11px] text-text-secondary">
                    <div>职业能力：<strong>30%</strong></div>
                    <div>履约能力：<strong>25%</strong></div>
                    <div>安全行为：<strong>20%</strong></div>
                    <div>健康能力：<strong>10%</strong></div>
                    <div>信用能力：<strong>15%</strong></div>
                  </div>
                </div>
                <div className="space-y-2 pt-2 border-t">
                  <span className="font-bold text-text-dark block">2. 警示级别分界：</span>
                  <div className="space-y-1 text-[11px] text-text-secondary">
                    <div>A级: [90-100] | B级: [80-89] | C级: [70-79]</div>
                  </div>
                </div>
              </div>

              {/* Version B */}
              <div className="bg-slate-50 border rounded-lg p-5 space-y-4">
                <div className="font-mono font-bold text-indigo-700 text-sm border-b pb-2">Version B: {compareVerB}</div>
                <div className="space-y-2">
                  <span className="font-bold text-text-dark block">1. 评价维度滑块占比：</span>
                  <div className="space-y-1 text-[11px] text-text-secondary">
                    <div>职业能力：<strong>25%</strong> <span className="text-danger-red">(▼ 5%)</span></div>
                    <div>履约能力：<strong>25%</strong></div>
                    <div>安全行为：<strong>25%</strong> <span className="text-[#52C41A]">(▲ 5%)</span></div>
                    <div>健康能力：<strong>15%</strong> <span className="text-[#52C41A]">(▲ 5%)</span></div>
                    <div>信用能力：<strong>10%</strong> <span className="text-danger-red">(▼ 5%)</span></div>
                  </div>
                </div>
                <div className="space-y-2 pt-2 border-t">
                  <span className="font-bold text-text-dark block">2. 警示级别分界：</span>
                  <div className="space-y-1 text-[11px] text-text-secondary">
                    <div>A级: [85-100] | B级: [75-84] | C级: [60-74] <span className="text-indigo-600 font-bold">(降门槛)</span></div>
                  </div>
                </div>
              </div>
            </div>

            <div className="p-4 border-t bg-slate-50 border-slate-200 flex justify-end">
              <button
                type="button"
                onClick={() => setIsCompareOpen(false)}
                className="px-5 py-2 bg-primary text-white rounded shadow font-bold cursor-pointer"
              >
                我知道了
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  )
}
