import { useState, useRef } from 'react'
import {
  Users,
  Building2,
  Briefcase,
  UserCheck,
  HardHat,
  FileText,
  Cpu,
  Edit,
  Plus,
  Upload,
  Download,
  Check,
  AlertTriangle,
  Search,
  FileUp,
  X,
  Filter,
  Trash2,
  Calendar,
  ClipboardList,
  Award,
  Heart,
  HelpCircle,
  RefreshCw,
  Clock,
  ExternalLink,
  ShieldCheck,
  Activity,
  FileSpreadsheet,
  AlertCircle,
  Database,
  Sliders,
  Layers
} from 'lucide-react'
import DataCenter from './pages/DataCenter'
import IndexCenter from './pages/IndexCenter'
import ModelCenter from './pages/ModelCenter'
import TagCenter from './pages/TagCenter'
import PortraitCenter from './pages/PortraitCenter'
import DataAcquisitionCenter from './pages/DataAcquisitionCenter'

// Initial Mock Data
const INITIAL_WORKERS = [
  { id: '1', name: '张建国', idCard: '370102198010123456', jobType: '钢筋工', team: '钢筋一班', enterprise: '中建一局集团', status: '在场', updateTime: '2026-07-09 10:15:30', entryDate: '2026-01-10', exitDate: '-', sex: '男', age: 46, certificate: '特种作业操作证(钢筋工)', safetyStatus: '已培训且合格' },
  { id: '2', name: '李强', idCard: '420106198805247890', jobType: '架子工', team: '架子二班', enterprise: '中建一局集团', status: '在场', updateTime: '2026-07-09 09:30:12', entryDate: '2026-02-15', exitDate: '-', sex: '男', age: 38, certificate: '特种作业操作证(高处作业)', safetyStatus: '已培训且合格' },
  { id: '3', name: '王朝阳', idCard: '130102199203154567', jobType: '泥工', team: '泥工一班', enterprise: '中铁十一局', status: '在场', updateTime: '2026-07-08 17:45:00', entryDate: '2026-03-01', exitDate: '-', sex: '男', age: 34, certificate: '普通工种上岗证', safetyStatus: '已培训且合格' },
  { id: '4', name: '赵铁柱', idCard: '210103197508215678', jobType: '电焊工', team: '机电安装队', enterprise: '上海建工集团', status: '已退场', updateTime: '2026-07-05 16:20:11', entryDate: '2026-01-05', exitDate: '2026-07-05', sex: '男', age: 51, certificate: '焊接与热切割特种作业证', safetyStatus: '已培训且合格' },
  { id: '5', name: '孙红梅', idCard: '510105198511082345', jobType: '信号工', team: '塔吊班组', enterprise: '中铁十一局', status: '在场', updateTime: '2026-07-09 11:00:22', entryDate: '2026-04-10', exitDate: '-', sex: '女', age: 41, certificate: '建筑起重信号司索工证', safetyStatus: '已培训且合格' }
];

const INITIAL_ATTENDANCE = [
  { name: '张建国', date: '2026-07-09', clockIn: '07:15:32', clockOut: '17:35:10', status: '正常', location: '1号大门闸机', deviceId: 'ZJ-GATE-01' },
  { name: '李强', date: '2026-07-09', clockIn: '07:22:04', clockOut: '17:40:55', status: '正常', location: '2号大门闸机', deviceId: 'ZJ-GATE-02' },
  { name: '王朝阳', date: '2026-07-09', clockIn: '07:45:12', clockOut: '--:--:--', status: '缺卡', location: '1号大门闸机', deviceId: 'ZJ-GATE-01' },
  { name: '赵铁柱', date: '2026-07-09', clockIn: '--:--:--', clockOut: '--:--:--', status: '请假', location: '未打卡', deviceId: '无' },
  { name: '孙红梅', date: '2026-07-09', clockIn: '08:02:15', clockOut: '17:05:44', status: '迟到', location: '1号大门闸机', deviceId: 'ZJ-GATE-01' }
];

const INITIAL_EMPLOYMENT = [
  { name: '张建国', project: '北京CBD东区超高层项目', enterprise: '中建一局集团', team: '钢筋一班', jobType: '钢筋工', entryDate: '2026-01-10', exitDate: '2027-12-31' },
  { name: '李强', project: '北京CBD东区超高层项目', enterprise: '中建一局集团', team: '架子二班', jobType: '架子工', entryDate: '2026-02-15', exitDate: '2027-10-30' },
  { name: '王朝阳', project: '北京轨道交通28号线项目', enterprise: '中铁十一局', team: '泥工一班', jobType: '泥工', entryDate: '2026-03-01', exitDate: '2026-12-31' },
  { name: '赵铁柱', project: '城市绿心剧院机电安装项目', enterprise: '上海建工集团', team: '机电安装队', jobType: '电焊工', entryDate: '2026-01-05', exitDate: '2026-07-05' },
  { name: '孙红梅', project: '北京轨道交通28号线项目', enterprise: '中铁十一局', team: '塔吊班组', jobType: '信号工', entryDate: '2026-04-10', exitDate: '2027-06-30' }
];

const INITIAL_TEAMS = [
  { teamName: '钢筋一班', count: 42, leader: '雷建军', enterprise: '中建一局集团' },
  { teamName: '架子二班', count: 28, leader: '李大山', enterprise: '中建一局集团' },
  { teamName: '泥工一班', count: 35, leader: '王顺德', enterprise: '中铁十一局' },
  { teamName: '机电安装队', count: 50, leader: '钱有才', enterprise: '上海建工集团' },
  { teamName: '塔吊班组', count: 12, leader: '周小松', enterprise: '中铁十一局' }
];

const INITIAL_ENTERPRISES = [
  { enterpriseName: '中建一局集团有限公司', leader: '陈国强', workerCount: 450 },
  { enterpriseName: '中铁十一局集团有限公司', leader: '刘志军', workerCount: 380 },
  { enterpriseName: '上海建工集团股份有限公司', leader: '张海波', workerCount: 290 },
  { enterpriseName: '北京建工集团有限责任公司', leader: '赵鹏飞', workerCount: 145 }
];

// AI Sub-module Mock Data
const INITIAL_AI_HISTORY = [
  { id: '1', fileName: '20260709_体检报告_张建国.pdf', uploadTime: '2026-07-09 11:20:15', status: '待确认', type: '体检记录', size: '1.2 MB', data: { name: '张建国', idCard: '370102198010123456', date: '2026-07-08', result: '合格(符合高空作业条件)', agency: '北京市朝阳区第二医院职业健康体检中心', reward: '-', punishment: '-', confidence: 99.4 } },
  { id: '2', fileName: '20260708_百日安全个人表彰_李强.jpg', uploadTime: '2026-07-08 15:44:32', status: '已确认', type: '奖励记录', size: '3.4 MB', data: { name: '李强', idCard: '420106198805247890', date: '2026-07-08', result: '突出表现奖励', agency: '中建一局集团项目部', reward: '安全百日优秀工人表彰', punishment: '-', confidence: 97.2 } },
  { id: '3', fileName: '20260705_违规处罚通报_王朝阳.png', uploadTime: '2026-07-05 09:12:44', status: '待确认', type: '处罚记录', size: '2.1 MB', data: { name: '王朝阳', idCard: '130102199203154567', date: '2026-07-05', result: '违规进入吊装警戒区', agency: '项目安全监察部', reward: '-', punishment: '通报批评并罚款200元', confidence: 95.8 } },
  { id: '4', fileName: '20260703_三级安全教育培训_赵铁柱.docx', uploadTime: '2026-07-03 14:22:00', status: '已确认', type: '培训记录', size: '4.8 MB', data: { name: '赵铁柱', idCard: '210103197508215678', date: '2026-07-03', result: '考试分数：92分(合格)', agency: '项目部安全教育部', reward: '-', punishment: '-', confidence: 98.9 } }
];

const INITIAL_AI_TO_CONFIRM = [
  { id: 'c1', worker: '张建国', idCard: '370102198010123456', type: '体检记录', detail: '体检结果：合格；体检机构：北京市朝阳区第二医院', time: '2026-07-09 11:20:15', status: '待确认', conf: '99.4%', fileId: '1' },
  { id: 'c2', worker: '王朝阳', idCard: '130102199203154567', type: '处罚记录', detail: '违规进入吊装警戒区，罚款200元', time: '2026-07-05 09:12:44', status: '待确认', conf: '95.8%', fileId: '3' }
];

const INITIAL_AI_TEMPLATES = [
  { id: 't1', name: '标准入场体检表', format: 'PDF/图片', fields: ['姓名', '身份证号', '体检时间', '结论'], status: '启用中', updated: '2026-05-12' },
  { id: 't2', name: '违规处罚通知单', format: 'PDF/Word', fields: ['姓名', '身份证号', '违规事实', '处罚金额', '处罚时间'], status: '启用中', updated: '2026-06-01' },
  { id: 't3', name: '安全培训考评表', format: 'Excel/图片', fields: ['姓名', '工种', '培训课程', '考试成绩', '结论'], status: '启用中', updated: '2026-06-18' },
  { id: 't4', name: '技能竞赛获奖公示', format: 'Word', fields: ['姓名', '竞赛名称', '获得名次', '发证机关', '时间'], status: '待配置', updated: '2026-07-02' }
];

// Manual Sub-module Mock Data
const INITIAL_MANUAL_DATA = {
  exam: [
    { id: 'e1', name: '张建国', idCard: '370102198010123456', project: '北京CBD东区超高层项目', date: '2026-07-08', institution: '朝阳区第二医院', result: '合格', attachment: '20260708_体检报告.pdf', remarks: '复检合格' },
    { id: 'e2', name: '李强', idCard: '420106198805247890', project: '北京CBD东区超高层项目', date: '2026-06-15', institution: '建工疗养院体检中心', result: '合格', attachment: '20260615_体检表.pdf', remarks: '血压偏高，建议复查' },
    { id: 'e3', name: '王朝阳', idCard: '130102199203154567', project: '北京轨道交通28号线项目', date: '2026-05-20', institution: '中铁中心医院', result: '合格', attachment: '20260520_体检单.pdf', remarks: '无异常' }
  ],
  rewards: [
    { id: 'r1', name: '李强', idCard: '420106198805247890', title: '季度百日安全无事故先进个人', level: '项目部级', money: '500', date: '2026-07-08', agency: '中建一局项目部', attachment: '百日安全证书.pdf', remarks: '安全模范示范' },
    { id: 'r2', name: '张建国', idCard: '370102198010123456', title: '生产安全卫士奖', level: '企业级', money: '1000', date: '2026-06-01', agency: '中建一局集团', attachment: '安全卫士.pdf', remarks: '发现重大安全隐患并上报' }
  ],
  punishments: [
    { id: 'p1', name: '王朝阳', idCard: '130102199203154567', reason: '未佩戴安全帽进入施工区域', action: '通报批评并罚款', money: '200', date: '2026-07-05', recorder: '刘巡检', attachment: '罚款单20260705.pdf', remarks: '首次违规进行批评教育' }
  ],
  trainings: [
    { id: 'tr1', name: '张建国', idCard: '370102198010123456', course: '夏季防暑降温与高空防坠落安全教育', hours: '4', result: '合格', date: '2026-07-02', instructor: '赵安全', attachment: '培训签到表.pdf', remarks: '全员培训' },
    { id: 'tr2', name: '李强', idCard: '420106198805247890', course: '脚手架搭设资质复审理论与实操培训', hours: '12', result: '优秀', date: '2026-06-10', instructor: '陈高工', attachment: '特种培训证书.pdf', remarks: '特种作业专项培训' }
  ],
  contests: [
    { id: 'c1', name: '张建国', idCard: '370102198010123456', nameOfContest: '北京市第七届建筑产业工人技能竞赛', jobType: '钢筋绑扎', rank: '二等奖', date: '2026-05-18', prizeMoney: '2000', attachment: '获奖证书.pdf', remarks: '代表集团出赛' }
  ],
  honors: [
    { id: 'h1', name: '张建国', idCard: '370102198010123456', honorName: '首都杰出工匠称号', level: '省级', date: '2026-05-01', agency: '北京市总工会', attachment: '工匠证书.pdf', remarks: '重磅省级荣誉' }
  ]
};

function App() {
  // Navigation State
  const [activeMenu, setActiveMenu] = useState('evaluation-center')
  
  // Evaluation Center Master Tab State: 1 = Realname, 2 = AI, 3 = Manual
  const [masterTab, setMasterTab] = useState(1)

  // Sub-module 1: Real-name Sub-Tabs (1 to 5)
  const [realnameSubTab, setRealnameSubTab] = useState(1)
  const [selectedWorkerDetails, setSelectedWorkerDetails] = useState(null)
  const [isWorkerDrawerOpen, setIsWorkerDrawerOpen] = useState(false)
  const [attendanceDetail, setAttendanceDetail] = useState(null)

  // Sub-module 2: AI Sub-Tabs (1 to 4)
  const [aiSubTab, setAiSubTab] = useState(1)
  const [aiHistory, setAiHistory] = useState(INITIAL_AI_HISTORY)
  const [aiToConfirm, setAiToConfirm] = useState(INITIAL_AI_TO_CONFIRM)
  const [selectedAiRecord, setSelectedAiRecord] = useState(null)
  const [isAiViewOpen, setIsAiViewOpen] = useState(false)
  const [dragActive, setDragActive] = useState(false)
  const fileInputRef = useRef(null)
  const [checkedConfirmIds, setCheckedConfirmIds] = useState([])
  const [isUploading, setIsUploading] = useState(false)

  // Sub-module 3: Manual Sub-Tabs/Types (1=exam, 2=rewards, 3=punishments, 4=trainings, 5=contests, 6=honors)
  const [manualTab, setManualTab] = useState(1)
  const [manualData, setManualData] = useState(INITIAL_MANUAL_DATA)
  const [isAddModalOpen, setIsAddModalOpen] = useState(false)
  const [isImportModalOpen, setIsImportModalOpen] = useState(false)
  const [editingRecord, setEditingRecord] = useState(null)

  // Alert/Message State
  const [notifications, setNotifications] = useState([])

  const triggerNotification = (message, type = 'success') => {
    const id = Date.now().toString()
    setNotifications((prev) => [...prev, { id, message, type }])
    setTimeout(() => {
      setNotifications((prev) => prev.filter((n) => n.id !== id))
    }, 4000)
  }

  // --- AI Sub-module handlers ---
  const handleDrag = (e) => {
    e.preventDefault()
    e.stopPropagation()
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true)
    } else if (e.type === "dragleave") {
      setDragActive(false)
    }
  }

  const handleDrop = (e) => {
    e.preventDefault()
    e.stopPropagation()
    setDragActive(false)
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processUploadedFile(e.dataTransfer.files[0])
    }
  }

  const handleFileInput = (e) => {
    if (e.target.files && e.target.files[0]) {
      processUploadedFile(e.target.files[0])
    }
  }

  const processUploadedFile = (file) => {
    setIsUploading(true)
    triggerNotification(`文件「${file.name}」上传成功，AI正在结构化提取中...`, 'info')
    
    // Simulate OCR delay
    setTimeout(() => {
      setIsUploading(false)
      const newId = (aiHistory.length + 1).toString()
      const newRecord = {
        id: newId,
        fileName: file.name,
        uploadTime: new Date().toLocaleString(),
        status: '待确认',
        type: file.name.includes('体检') ? '体检记录' : file.name.includes('奖') ? '奖励记录' : file.name.includes('罚') ? '处罚记录' : '培训记录',
        size: `${(file.size / (1024 * 1024)).toFixed(1)} MB`,
        data: {
          name: '张建国', // Mock extract
          idCard: '370102198010123456',
          date: '2026-07-09',
          result: '合格(符合岗位规范要求)',
          agency: '中国建筑工程职工医院',
          reward: file.name.includes('奖') ? '安全优胜奖' : '-',
          punishment: file.name.includes('罚') ? '安全违规处罚' : '-',
          confidence: parseFloat((93 + Math.random() * 6).toFixed(1))
        }
      }
      setAiHistory(prev => [newRecord, ...prev])
      setAiToConfirm(prev => [
        {
          id: `c${Date.now()}`,
          worker: newRecord.data.name,
          idCard: newRecord.data.idCard || '370102198010123456',
          type: newRecord.type,
          detail: `AI结构化识别「${newRecord.type}」结论：${newRecord.data.result}`,
          time: newRecord.uploadTime,
          status: '待确认',
          conf: `${newRecord.data.confidence}%`,
          fileId: newId
        },
        ...prev
      ])
      triggerNotification(`AI结构化提取完毕！置信度 ${newRecord.data.confidence}%，已生成待确认台账。`, 'success')
    }, 2000)
  }

  const handleConfirmEntry = (record) => {
    // 1. Update AI History Status to '已确认'
    setAiHistory(prev => prev.map(item => item.id === record.id ? { ...item, status: '已确认' } : item))
    // 2. Remove from AI待确认
    setAiToConfirm(prev => prev.filter(item => item.fileId !== record.id))
    // 3. Add to manual maintenance ledger
    const targetType = record.type
    const resolvedIdCard = record.data.idCard || '370102198010123456'

    if (targetType === '体检记录') {
      const newRecord = {
        id: `e${Date.now()}`,
        name: record.data.name,
        idCard: resolvedIdCard,
        project: '北京CBD东区超高层项目',
        date: record.data.date,
        institution: record.data.agency,
        result: '合格',
        attachment: record.fileName,
        remarks: 'AI智能识别同步入库'
      }
      setManualData(prev => ({ ...prev, exam: [newRecord, ...prev.exam] }))
    } else if (targetType === '奖励记录') {
      const newRecord = {
        id: `r${Date.now()}`,
        name: record.data.name,
        idCard: resolvedIdCard,
        title: record.data.reward !== '-' ? record.data.reward : '安全模范奖励',
        level: '项目部级',
        money: '200',
        date: record.data.date,
        agency: record.data.agency,
        attachment: record.fileName,
        remarks: 'AI智能识别同步入库'
      }
      setManualData(prev => ({ ...prev, rewards: [newRecord, ...prev.rewards] }))
    } else if (targetType === '处罚记录') {
      const newRecord = {
        id: `p${Date.now()}`,
        name: record.data.name,
        idCard: resolvedIdCard,
        reason: record.data.punishment !== '-' ? record.data.punishment : '习惯性违章',
        action: '罚款并通报',
        money: '200',
        date: record.data.date,
        recorder: 'AI安全监控系统',
        attachment: record.fileName,
        remarks: 'AI智能识别同步入库'
      }
      setManualData(prev => ({ ...prev, punishments: [newRecord, ...prev.punishments] }))
    }

    setIsAiViewOpen(false)
    triggerNotification(`文件「${record.fileName}」数据已成功审核并同步至对应人工台账！`, 'success')
  }

  const handleBatchConfirm = () => {
    if (checkedConfirmIds.length === 0) return
    
    // Simulate batch confirm
    setAiToConfirm(prev => prev.filter(item => {
      const isChecked = checkedConfirmIds.includes(item.id)
      if (isChecked) {
        // Also update the matching record in aiHistory
        setAiHistory(h => h.map(hist => hist.id === item.fileId ? { ...hist, status: '已确认' } : hist))
        
        // Add to manual ledger
        const histItem = aiHistory.find(h => h.id === item.fileId)
        if (histItem) {
          const resolvedIdCard = histItem.data.idCard || '370102198010123456'
          if (histItem.type === '体检记录') {
            setManualData(d => ({
              ...d,
              exam: [{
                id: `e${Date.now()}_${Math.random()}`,
                name: histItem.data.name,
                idCard: resolvedIdCard,
                project: '北京CBD东区超高层项目',
                date: histItem.data.date,
                institution: histItem.data.agency,
                result: '合格',
                attachment: histItem.fileName,
                remarks: 'AI批量入库'
              }, ...d.exam]
            }))
          }
        }
      }
      return !isChecked
    }))

    setCheckedConfirmIds([])
    triggerNotification('已批量将选中识别结果审核入库！', 'success')
  }

  // --- Manual Sub-module handlers ---
  const [formData, setFormData] = useState({
    name: '张建国',
    project: '北京CBD东区超高层项目',
    date: '2026-07-09',
    institution: '',
    result: '合格',
    remarks: '',
    title: '',
    level: '项目部级',
    money: '',
    reason: '',
    action: '',
    course: '',
    hours: '',
    instructor: '',
    nameOfContest: '',
    jobType: '',
    rank: '',
    prizeMoney: '',
    honorName: '',
    agency: ''
  })

  const openAddModal = (record = null) => {
    if (record) {
      setEditingRecord(record)
      setFormData({ ...record })
    } else {
      setEditingRecord(null)
      // Reset defaults
      setFormData({
        name: '张建国',
        project: '北京CBD东区超高层项目',
        date: '2026-07-09',
        institution: '北京市朝阳区第二医院',
        result: '合格',
        remarks: '',
        title: '月度安全标兵',
        level: '项目部级',
        money: '300',
        reason: '进入现场未戴安全帽',
        action: '警告并扣减劳务积分',
        course: '三级安全入场培训',
        hours: '8',
        instructor: '雷安全员',
        nameOfContest: '北京市泥水工高空技能比武',
        jobType: '泥工',
        rank: '第三名',
        prizeMoney: '1000',
        honorName: '先进生产者',
        agency: '北京市建筑业协会'
      })
    }
    setIsAddModalOpen(true)
  }

  const handleSaveManualRecord = (e) => {
    e.preventDefault()
    
    const tabsMap = {
      1: 'exam',
      2: 'rewards',
      3: 'punishments',
      4: 'trainings',
      5: 'contests',
      6: 'honors'
    }
    const currentKey = tabsMap[manualTab]

    // Resolve idCard from INITIAL_WORKERS
    const workerObj = INITIAL_WORKERS.find(w => w.name === formData.name)
    const resolvedIdCard = workerObj ? workerObj.idCard : '370102198010123456'

    if (editingRecord) {
      setManualData(prev => ({
        ...prev,
        [currentKey]: prev[currentKey].map(item => item.id === editingRecord.id ? { ...formData, id: item.id, idCard: resolvedIdCard } : item)
      }))
      triggerNotification('台账记录修改成功', 'success')
    } else {
      const newRecord = {
        ...formData,
        id: `m_${Date.now()}`,
        idCard: resolvedIdCard,
        attachment: 'manual_upload.pdf'
      }
      setManualData(prev => ({
        ...prev,
        [currentKey]: [newRecord, ...prev[currentKey]]
      }))
      triggerNotification('新增台账记录成功', 'success')
    }
    setIsAddModalOpen(false)
  }

  const handleDeleteRecord = (id) => {
    if (confirm('确认删除此条台账记录？此操作无法撤销。')) {
      const tabsMap = {
        1: 'exam',
        2: 'rewards',
        3: 'punishments',
        4: 'trainings',
        5: 'contests',
        6: 'honors'
      }
      const currentKey = tabsMap[manualTab]
      setManualData(prev => ({
        ...prev,
        [currentKey]: prev[currentKey].filter(item => item.id !== id)
      }))
      triggerNotification('台账记录删除成功', 'warning')
    }
  }

  const handleExport = () => {
    triggerNotification('正在导出台账数据...', 'info')
    setTimeout(() => {
      triggerNotification('台账数据已成功导出为 Excel 文件！', 'success')
    }, 1500)
  }

  const handleImport = () => {
    setIsImportModalOpen(true)
  }

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-bg-gray">
      {/* Toast Notification Container */}
      <div className="fixed top-6 right-6 z-50 flex flex-col gap-3">
        {notifications.map((n) => (
          <div
            key={n.id}
            className={`flex items-center gap-3 px-4 py-3 rounded shadow-lg text-white border min-w-80 animate-fade-in ${
              n.type === 'success' ? 'bg-[#52C41A] border-[#389e0d]' :
              n.type === 'warning' ? 'bg-[#FA8C16] border-[#d46b08]' :
              n.type === 'info' ? 'bg-[#1890FF] border-[#096dd9]' : 'bg-[#F5222D] border-[#cf1322]'
            }`}
          >
            {n.type === 'success' && <Check className="h-5 w-5 shrink-0" />}
            {n.type === 'warning' && <AlertTriangle className="h-5 w-5 shrink-0" />}
            {n.type === 'info' && <RefreshCw className="h-5 w-5 shrink-0 animate-spin" />}
            {n.type === 'error' && <AlertCircle className="h-5 w-5 shrink-0" />}
            <span className="font-medium text-sm">{n.message}</span>
          </div>
        ))}
      </div>

      {/* LEFT NAVIGATION BAR - White Sidebar Style (matching existing system) */}
      <aside className="w-56 bg-white flex flex-col shrink-0 border-r border-[#E8E8E8] shadow-sm">
        {/* User Profile Area */}
        <div className="p-4 border-b border-[#E8E8E8] flex items-center gap-3">
          <div className="h-10 w-10 bg-[#E6F7FF] rounded-full flex items-center justify-center">
            <UserCheck className="h-5 w-5 text-[#2196F3]" />
          </div>
          <div>
            <h1 className="font-bold text-[13px] text-[#333] leading-tight">系统管理员</h1>
            <p className="text-[11px] text-[#999] leading-tight">中建一局安全部</p>
          </div>
        </div>

        {/* Status badges */}
        <div className="px-4 py-3 border-b border-[#E8E8E8] flex items-center gap-4 text-[12px]">
          <div className="flex items-center gap-1">
            <span className="h-2 w-2 bg-[#F5222D] rounded-full"></span>
            <span className="text-[#666]">待办</span>
            <span className="font-bold text-[#2196F3]">6</span>
          </div>
          <div className="flex items-center gap-1">
            <span className="h-2 w-2 bg-[#FA8C16] rounded-full"></span>
            <span className="text-[#666]">通知</span>
            <span className="font-bold text-[#2196F3]">3</span>
          </div>
        </div>

        {/* Navigation Items */}
        <nav className="flex-1 py-2 overflow-y-auto">
          <div className="px-4 py-2 text-[11px] font-bold text-[#999] tracking-wider">评价体系</div>

          <a
            href="#"
            onClick={() => setActiveMenu('evaluation-center')}
            className={`flex items-center gap-3 px-4 py-2.5 text-[13px] transition-all duration-150 border-r-3 cursor-pointer ${
              activeMenu === 'evaluation-center' || activeMenu === 'home' ? 'bg-[#E6F7FF] text-[#2196F3] font-bold border-r-[#2196F3]' : 'text-[#333] hover:bg-[#F5F5F5] border-r-transparent'
            }`}
          >
            <Cpu className="h-4 w-4" />
            <span>评价数据采集中心</span>
          </a>

          <a
            href="#"
            onClick={() => setActiveMenu('datacenter')}
            className={`flex items-center gap-3 px-4 py-2.5 text-[13px] transition-all duration-150 border-r-3 cursor-pointer ${
              activeMenu === 'datacenter' ? 'bg-[#E6F7FF] text-[#2196F3] font-bold border-r-[#2196F3]' : 'text-[#333] hover:bg-[#F5F5F5] border-r-transparent'
            }`}
          >
            <Database className="h-4 w-4" />
            <span>数据源审计中心</span>
          </a>

          <a
            href="#"
            onClick={() => setActiveMenu('indexcenter')}
            className={`flex items-center gap-3 px-4 py-2.5 text-[13px] transition-all duration-150 border-r-3 cursor-pointer ${
              activeMenu === 'indexcenter' ? 'bg-[#E6F7FF] text-[#2196F3] font-bold border-r-[#2196F3]' : 'text-[#333] hover:bg-[#F5F5F5] border-r-transparent'
            }`}
          >
            <Sliders className="h-4 w-4" />
            <span>评价指标配置中心</span>
          </a>

          <a
            href="#"
            onClick={() => setActiveMenu('evaluation-model')}
            className={`flex items-center gap-3 px-4 py-2.5 text-[13px] transition-all duration-150 border-r-3 cursor-pointer ${
              activeMenu === 'evaluation-model' ? 'bg-[#E6F7FF] text-[#2196F3] font-bold border-r-[#2196F3]' : 'text-[#333] hover:bg-[#F5F5F5] border-r-transparent'
            }`}
          >
            <ClipboardList className="h-4 w-4" />
            <span>工人评价模型</span>
          </a>

          <a
            href="#"
            onClick={() => setActiveMenu('tagcenter')}
            className={`flex items-center gap-3 px-4 py-2.5 text-[13px] transition-all duration-150 border-r-3 cursor-pointer ${
              activeMenu === 'tagcenter' ? 'bg-[#E6F7FF] text-[#2196F3] font-bold border-r-[#2196F3]' : 'text-[#333] hover:bg-[#F5F5F5] border-r-transparent'
            }`}
          >
            <Layers className="h-4 w-4" />
            <span>智能标签配置中心</span>
          </a>

          <div className="px-4 py-2 text-[11px] font-bold text-[#999] tracking-wider mt-2">实名台账</div>

          <a
            href="#"
            onClick={() => setActiveMenu('portraitcenter')}
            className={`flex items-center gap-3 px-4 py-2.5 text-[13px] transition-all duration-150 border-r-3 cursor-pointer ${
              activeMenu === 'portraitcenter' ? 'bg-[#E6F7FF] text-[#2196F3] font-bold border-r-[#2196F3]' : 'text-[#333] hover:bg-[#F5F5F5] border-r-transparent'
            }`}
          >
            <Users className="h-4 w-4" />
            <span>人员画像与人才库</span>
          </a>

          <a
            href="#"
            className="flex items-center gap-3 px-4 py-2.5 text-[13px] text-[#333] hover:bg-[#F5F5F5] border-r-3 border-r-transparent cursor-pointer"
          >
            <Clock className="h-4 w-4" />
            <span>智能考勤查询</span>
          </a>

          <div className="px-4 py-2 text-[11px] font-bold text-[#999] tracking-wider mt-2">系统安全</div>

          <a
            href="#"
            className="flex items-center gap-3 px-4 py-2.5 text-[13px] text-[#333] hover:bg-[#F5F5F5] border-r-3 border-r-transparent cursor-pointer"
          >
            <ShieldCheck className="h-4 w-4" />
            <span>实名接口监控</span>
          </a>
        </nav>

        {/* Sidebar Footer info */}
        <div className="p-3 border-t border-[#E8E8E8] text-[11px] text-[#999] flex flex-col gap-1">
          <div className="flex items-center gap-1.5">
            <span className="h-2 w-2 bg-[#52C41A] rounded-full animate-pulse"></span>
            <span>接口联调：已连接</span>
          </div>
          <div className="text-[10px] text-[#BBB]">版本：v2.4.12</div>
        </div>
      </aside>

      {/* RIGHT WORK AREA */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* TOP STATUS BAR - Blue Header (matching existing system) */}
        <header className="h-12 bg-[#2196F3] flex items-center justify-between px-5 shrink-0 z-10 shadow-sm">
          {/* Left: Logo + Title */}
          <div className="flex items-center gap-3">
            <div className="h-7 w-7 bg-white/20 rounded flex items-center justify-center">
              <Building2 className="h-4 w-4 text-white" />
            </div>
            <span className="text-white font-bold text-[14px] tracking-wide">建筑产业工人智能评价平台</span>
          </div>

          {/* Center: Search box */}
          <div className="hidden md:flex items-center bg-white/20 rounded px-3 py-1 gap-2 w-72">
            <Search className="h-3.5 w-3.5 text-white/70" />
            <input
              type="text"
              placeholder="搜索功能、工人姓名..."
              className="bg-transparent border-none outline-none text-white text-[12px] placeholder-white/60 w-full"
            />
          </div>

          {/* Right: breadcrumb + actions */}
          <div className="flex items-center gap-4">
            <span className="text-white/80 text-[12px]">
              {activeMenu === 'datacenter' ? '数据源与质量审计中心' :
               activeMenu === 'indexcenter' ? '评价指标配置中心' :
               activeMenu === 'evaluation-model' ? '评价模型与执行中心' :
               activeMenu === 'tagcenter' ? '智能标签配置中心' :
               activeMenu === 'portraitcenter' ? '人员画像与企业人才库' : '评价数据采集中心'}
            </span>
            <div className="h-5 w-[1px] bg-white/30"></div>
            <div className="h-7 w-7 bg-white/20 rounded-full flex items-center justify-center text-white text-[11px] font-bold cursor-pointer">
              管
            </div>
          </div>
        </header>

        {/* MAIN CONTAINER */}
        <main className="flex-1 overflow-y-auto p-6 flex flex-col gap-6">
          {activeMenu === 'datacenter' ? (
            <DataCenter triggerNotification={triggerNotification} />
          ) : activeMenu === 'indexcenter' ? (
            <IndexCenter triggerNotification={triggerNotification} />
          ) : activeMenu === 'evaluation-model' ? (
            <ModelCenter triggerNotification={triggerNotification} />
          ) : activeMenu === 'tagcenter' ? (
            <TagCenter triggerNotification={triggerNotification} />
          ) : activeMenu === 'portraitcenter' ? (
            <PortraitCenter triggerNotification={triggerNotification} />
          ) : (
            <DataAcquisitionCenter triggerNotification={triggerNotification} />
          )}
      </main>
      </div>

      {/* ==================== WORKER DRAWER (REALNAME DETAILS) ==================== */}
      {isWorkerDrawerOpen && selectedWorkerDetails && (
        <div className="fixed inset-0 z-40 flex justify-end">
          {/* Overlay */}
          <div className="absolute inset-0 bg-black/40 transition-opacity" onClick={() => setIsWorkerDrawerOpen(false)}></div>
          
          {/* Drawer container */}
          <div className="relative w-full max-w-lg bg-white h-full shadow-2xl flex flex-col z-10 animate-slide-in">
            {/* Header */}
            <div className="p-6 border-b border-border-gray flex items-center justify-between bg-slate-50">
              <div>
                <h3 className="text-base font-black text-text-dark flex items-center gap-2">
                  <span>工人基础信息面板</span>
                </h3>
                <div className="flex flex-wrap gap-1.5 mt-2">
                  <span className="text-[10px] bg-blue-50 text-primary border border-blue-200 px-1.5 py-0.5 rounded font-bold">
                    来源：实名制系统
                  </span>
                  <span className="text-[10px] bg-slate-100 text-slate-500 border border-slate-200 px-1.5 py-0.5 rounded">
                    更新时间：2026-07-09
                  </span>
                  <span className="text-[10px] bg-emerald-50 text-success-green border border-emerald-200 px-1.5 py-0.5 rounded font-bold">
                    同步状态：正常
                  </span>
                </div>
              </div>
              <button onClick={() => setIsWorkerDrawerOpen(false)} className="text-slate-400 hover:text-slate-600 p-1">
                <X className="h-5 w-5" />
              </button>
            </div>

            {/* Read-only Content Form (Disabled) */}
            <div className="flex-1 p-6 overflow-y-auto space-y-4">
              <div className="bg-amber-50 border border-amber-200 rounded p-3 text-[11px] text-[#FA8C16] flex items-start gap-2 font-medium">
                <AlertTriangle className="h-4 w-4 shrink-0 mt-0.5" />
                <span>实名制系统已锁定编辑。如需修改下列工人档案，请前往对应分包企业的实名采集设备端操作，系统将按周期自动覆写。</span>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-text-secondary mb-1">姓名</label>
                  <input type="text" disabled value={selectedWorkerDetails.name} className="w-full bg-slate-100 border border-slate-200 rounded px-3 py-2 text-xs text-text-secondary cursor-not-allowed" />
                </div>
                <div>
                  <label className="block text-xs font-bold text-text-secondary mb-1">性别</label>
                  <input type="text" disabled value={selectedWorkerDetails.sex} className="w-full bg-slate-100 border border-slate-200 rounded px-3 py-2 text-xs text-text-secondary cursor-not-allowed" />
                </div>
                <div className="col-span-2">
                  <label className="block text-xs font-bold text-text-secondary mb-1">身份证号</label>
                  <input type="text" disabled value={selectedWorkerDetails.idCard} className="w-full bg-slate-100 border border-slate-200 rounded px-3 py-2 text-xs text-text-secondary cursor-not-allowed font-mono" />
                </div>
                <div>
                  <label className="block text-xs font-bold text-text-secondary mb-1">核心工种</label>
                  <input type="text" disabled value={selectedWorkerDetails.jobType} className="w-full bg-slate-100 border border-slate-200 rounded px-3 py-2 text-xs text-text-secondary cursor-not-allowed" />
                </div>
                <div>
                  <label className="block text-xs font-bold text-text-secondary mb-1">班组归属</label>
                  <input type="text" disabled value={selectedWorkerDetails.team} className="w-full bg-slate-100 border border-slate-200 rounded px-3 py-2 text-xs text-text-secondary cursor-not-allowed" />
                </div>
                <div className="col-span-2">
                  <label className="block text-xs font-bold text-text-secondary mb-1">所属劳动分包企业</label>
                  <input type="text" disabled value={selectedWorkerDetails.enterprise} className="w-full bg-slate-100 border border-slate-200 rounded px-3 py-2 text-xs text-text-secondary cursor-not-allowed" />
                </div>
                <div>
                  <label className="block text-xs font-bold text-text-secondary mb-1">进场打卡日期</label>
                  <input type="text" disabled value={selectedWorkerDetails.entryDate} className="w-full bg-slate-100 border border-slate-200 rounded px-3 py-2 text-xs text-text-secondary cursor-not-allowed" />
                </div>
                <div>
                  <label className="block text-xs font-bold text-text-secondary mb-1">退场注销日期</label>
                  <input type="text" disabled value={selectedWorkerDetails.exitDate} className="w-full bg-slate-100 border border-slate-200 rounded px-3 py-2 text-xs text-text-secondary cursor-not-allowed" />
                </div>
                <div className="col-span-2">
                  <label className="block text-xs font-bold text-text-secondary mb-1">持证资质与证书编号</label>
                  <input type="text" disabled value={selectedWorkerDetails.certificate} className="w-full bg-slate-100 border border-slate-200 rounded px-3 py-2 text-xs text-text-secondary cursor-not-allowed" />
                </div>
                <div className="col-span-2">
                  <label className="block text-xs font-bold text-text-secondary mb-1">安全培训记录</label>
                  <input type="text" disabled value={selectedWorkerDetails.safetyStatus} className="w-full bg-slate-100 border border-emerald-200 bg-emerald-50 rounded px-3 py-2 text-xs text-success-green font-bold cursor-not-allowed" />
                </div>
              </div>
            </div>

            {/* Bottom buttons */}
            <div className="p-4 border-t border-border-gray bg-slate-50 flex items-center justify-end">
              <button
                onClick={() => setIsWorkerDrawerOpen(false)}
                className="px-4 py-2 bg-primary hover:bg-primary-hover text-white text-xs font-bold rounded shadow cursor-pointer transition-colors"
              >
                关闭面板
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ==================== AI DOUBLE COLUMN VERIFICATION DIALOG ==================== */}
      {isAiViewOpen && selectedAiRecord && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/60" onClick={() => setIsAiViewOpen(false)}></div>
          <div className="relative bg-white rounded-lg shadow-2xl w-full max-w-4xl max-h-[85vh] flex flex-col z-10 overflow-hidden animate-zoom-in">
            {/* Header */}
            <div className="p-4 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-text-dark flex items-center gap-2">
                  <span>AI 识别结果双栏校对视图</span>
                  <span className="text-xs bg-[#FA8C16]/10 text-warning-orange border border-[#FA8C16]/20 px-2 py-0.5 rounded font-black">
                    待校对审核
                  </span>
                </h3>
              </div>
              <button onClick={() => setIsAiViewOpen(false)} className="text-slate-400 hover:text-slate-600">
                <X className="h-5 w-5" />
              </button>
            </div>

            {/* Body */}
            <div className="flex-grow flex overflow-hidden">
              {/* Left Column: Attachment PDF/Image placeholder */}
              <div className="w-1/2 p-4 border-r border-slate-200 bg-slate-100 flex flex-col justify-between overflow-y-auto">
                <div className="text-xs font-bold text-text-secondary mb-2">附件预览: {selectedAiRecord.fileName}</div>
                <div className="flex-1 bg-white border border-slate-300 rounded shadow-inner flex flex-col items-center justify-center p-6 text-center gap-3 relative min-h-[300px]">
                  {/* Mock PDF structure */}
                  <div className="absolute inset-4 border border-slate-200 p-4 text-[10px] text-left text-slate-400 space-y-4">
                    <div className="text-center font-bold text-sm text-text-dark border-b pb-2">北京市职业健康监护报告单</div>
                    <div className="grid grid-cols-2 gap-2 border-b pb-2">
                      <div>姓名：张建国</div>
                      <div>身份证：370102198010123456</div>
                      <div>科室：高处作业体检科</div>
                      <div>日期：2026-07-09</div>
                    </div>
                    <div className="space-y-1">
                      <div className="font-bold text-[11px] text-text-dark">临床诊断意见：</div>
                      <div className="text-[11px] text-emerald-600 font-bold bg-emerald-50 p-1 border border-emerald-100 rounded">
                        血压：128/82 mmHg；心电图常规无异常；血常规、尿常规化验均合格。符合高空特种作业工种上岗健康标准。
                      </div>
                    </div>
                    <div className="text-right pt-10">检测机构：北京市朝阳区第二医院 (盖章)</div>
                  </div>
                  {/* AI bounding boxes mocks */}
                  <div className="absolute top-16 left-12 border-2 border-[#FA8C16] bg-amber-500/10 px-1 py-0.5 text-[9px] text-warning-orange font-bold rounded">
                    姓名: 张建国
                  </div>
                  <div className="absolute top-24 left-12 border-2 border-[#FA8C16] bg-amber-500/10 px-1 py-0.5 text-[9px] text-warning-orange font-bold rounded">
                    身份证号
                  </div>
                  <div className="absolute bottom-20 left-12 border-2 border-[#52C41A] bg-emerald-500/10 px-1 py-0.5 text-[9px] text-success-green font-bold rounded">
                    结论意见: 合格
                  </div>
                </div>
              </div>

              {/* Right Column: AI Fields form */}
              <form className="w-1/2 p-6 overflow-y-auto space-y-4 bg-white" onSubmit={(e) => e.preventDefault()}>
                <div className="text-xs font-bold text-text-dark border-b pb-2 flex items-center justify-between">
                  <span>AI提取表单 (可编辑修正)</span>
                  <div className="text-xs text-success-green font-bold">
                    综合置信度: {selectedAiRecord.data.confidence}%
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-text-secondary mb-1">被评价工人姓名</label>
                  <input
                    type="text"
                    value={selectedAiRecord.data.name}
                    onChange={(e) => {
                      const updated = { ...selectedAiRecord }
                      updated.data.name = e.target.value
                      setSelectedAiRecord(updated)
                    }}
                    className="w-full bg-white border border-slate-300 rounded px-3 py-2 text-xs text-text-dark focus:ring-1 focus:ring-primary"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-text-secondary mb-1">身份证号</label>
                  <input
                    type="text"
                    value={selectedAiRecord.data.idCard}
                    onChange={(e) => {
                      const updated = { ...selectedAiRecord }
                      updated.data.idCard = e.target.value
                      setSelectedAiRecord(updated)
                    }}
                    className="w-full bg-white border border-slate-300 rounded px-3 py-2 text-xs text-text-dark font-mono focus:ring-1 focus:ring-primary"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-text-secondary mb-1">识别所得日期</label>
                    <input
                      type="date"
                      value={selectedAiRecord.data.date}
                      onChange={(e) => {
                        const updated = { ...selectedAiRecord }
                        updated.data.date = e.target.value
                        setSelectedAiRecord(updated)
                      }}
                      className="w-full bg-white border border-slate-300 rounded px-3 py-2 text-xs text-text-dark focus:ring-1 focus:ring-primary"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-text-secondary mb-1">识别业务类型</label>
                    <select
                      value={selectedAiRecord.type}
                      onChange={(e) => {
                        const updated = { ...selectedAiRecord }
                        updated.type = e.target.value
                        setSelectedAiRecord(updated)
                      }}
                      className="w-full bg-white border border-slate-300 rounded px-3 py-1.5 text-xs text-text-dark focus:ring-1 focus:ring-primary"
                    >
                      <option value="体检记录">体检记录</option>
                      <option value="奖励记录">奖励记录</option>
                      <option value="处罚记录">处罚记录</option>
                      <option value="培训记录">培训记录</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-text-secondary mb-1">检测识别结论 / 评语</label>
                  <textarea
                    rows="2"
                    value={selectedAiRecord.data.result}
                    onChange={(e) => {
                      const updated = { ...selectedAiRecord }
                      updated.data.result = e.target.value
                      setSelectedAiRecord(updated)
                    }}
                    className="w-full bg-white border border-slate-300 rounded px-3 py-2 text-xs text-text-dark focus:ring-1 focus:ring-primary"
                  ></textarea>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-text-secondary mb-1">关联奖励名称 (如有)</label>
                    <input
                      type="text"
                      value={selectedAiRecord.data.reward}
                      onChange={(e) => {
                        const updated = { ...selectedAiRecord }
                        updated.data.reward = e.target.value
                        setSelectedAiRecord(updated)
                      }}
                      className="w-full bg-white border border-slate-300 rounded px-3 py-2 text-xs text-text-dark"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-text-secondary mb-1">关联处罚手段 (如有)</label>
                    <input
                      type="text"
                      value={selectedAiRecord.data.punishment}
                      onChange={(e) => {
                        const updated = { ...selectedAiRecord }
                        updated.data.punishment = e.target.value
                        setSelectedAiRecord(updated)
                      }}
                      className="w-full bg-white border border-slate-300 rounded px-3 py-2 text-xs text-text-dark"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-text-secondary mb-1">识别公信机构 / 鉴定主体</label>
                  <input
                    type="text"
                    value={selectedAiRecord.data.agency}
                    onChange={(e) => {
                      const updated = { ...selectedAiRecord }
                      updated.data.agency = e.target.value
                      setSelectedAiRecord(updated)
                    }}
                    className="w-full bg-white border border-slate-300 rounded px-3 py-2 text-xs text-text-dark"
                  />
                </div>
              </form>
            </div>

            {/* Footer buttons */}
            <div className="p-4 border-t border-slate-200 bg-slate-50 flex items-center justify-between shrink-0">
              <div className="text-xs text-text-secondary">
                审核人: <span className="font-bold text-text-dark">中建一局安全部主管</span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setIsAiViewOpen(false)}
                  className="px-4 py-2 bg-white hover:bg-slate-100 border border-slate-300 text-text-dark text-xs font-bold rounded shadow-sm cursor-pointer"
                >
                  取消关闭
                </button>
                <button
                  onClick={() => {
                    triggerNotification('重新识别触发中...', 'info')
                    setTimeout(() => {
                      const updated = { ...selectedAiRecord }
                      updated.data.confidence = parseFloat((95 + Math.random() * 4.9).toFixed(1))
                      setSelectedAiRecord(updated)
                      triggerNotification('重新识别成功，置信度略微提升。', 'success')
                    }, 1000)
                  }}
                  className="px-4 py-2 bg-white hover:bg-slate-100 border border-slate-300 text-primary text-xs font-bold rounded shadow-sm cursor-pointer"
                >
                  重新识别
                </button>
                <button
                  onClick={() => {
                    triggerNotification('已保存为草稿', 'warning')
                    setIsAiViewOpen(false)
                  }}
                  className="px-4 py-2 bg-[#FA8C16] hover:bg-amber-600 text-white text-xs font-bold rounded shadow cursor-pointer transition-colors"
                >
                  保存草稿
                </button>
                <button
                  onClick={() => handleConfirmEntry(selectedAiRecord)}
                  className="px-4 py-2 bg-[#52C41A] hover:bg-emerald-600 text-white text-xs font-bold rounded shadow cursor-pointer transition-colors"
                >
                  确认入库
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ==================== MANUAL ADD/EDIT MODAL ==================== */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/50" onClick={() => setIsAddModalOpen(false)}></div>
          <form
            className="relative bg-white rounded-lg shadow-2xl w-full max-w-xl flex flex-col z-10 overflow-hidden animate-zoom-in"
            onSubmit={handleSaveManualRecord}
          >
            {/* Header */}
            <div className="p-4 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
              <h3 className="text-sm font-bold text-text-dark">
                {editingRecord ? '修改台账记录' : '新增台账记录'} - {
                  manualTab === 1 ? '体检记录' :
                  manualTab === 2 ? '奖励记录' :
                  manualTab === 3 ? '处罚记录' :
                  manualTab === 4 ? '培训记录' :
                  manualTab === 5 ? '技能竞赛' : '荣誉记录'
                }
              </h3>
              <button type="button" onClick={() => setIsAddModalOpen(false)} className="text-slate-400 hover:text-slate-600">
                <X className="h-5 w-5" />
              </button>
            </div>

            {/* Form Fields */}
            <div className="p-6 space-y-4 max-h-[70vh] overflow-y-auto">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-text-secondary mb-1">被考核工人 (首选搜索)</label>
                  <select
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full bg-white border border-slate-300 rounded px-3 py-1.5 text-xs text-text-dark focus:ring-1 focus:ring-primary"
                  >
                    {INITIAL_WORKERS.map(w => (
                      <option key={w.id} value={w.name}>{w.name} ({w.jobType})</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-text-secondary mb-1">归属工程项目</label>
                  <select
                    value={formData.project}
                    onChange={(e) => setFormData({ ...formData, project: e.target.value })}
                    className="w-full bg-white border border-slate-300 rounded px-3 py-1.5 text-xs text-text-dark focus:ring-1 focus:ring-primary"
                  >
                    <option value="北京CBD东区超高层项目">北京CBD东区超高层项目</option>
                    <option value="北京轨道交通28号线项目">北京轨道交通28号线项目</option>
                    <option value="城市绿心剧院机电安装项目">城市绿心剧院机电安装项目</option>
                  </select>
                </div>
              </div>

              {/* Dynamic Sub-form based on active manualTab */}
              {/* 1. 体检 */}
              {manualTab === 1 && (
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-text-secondary mb-1">体检健康结论</label>
                      <select
                        value={formData.result}
                        onChange={(e) => setFormData({ ...formData, result: e.target.value })}
                        className="w-full bg-white border border-slate-300 rounded px-3 py-1.5 text-xs text-text-dark"
                      >
                        <option value="合格">合格</option>
                        <option value="不合格">不合格(需复检)</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-text-secondary mb-1">体检日期</label>
                      <input
                        type="date"
                        value={formData.date}
                        onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                        className="w-full bg-white border border-slate-300 rounded px-3 py-2 text-xs text-text-dark"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-text-secondary mb-1">体检筛查机构</label>
                    <input
                      type="text"
                      required
                      value={formData.institution}
                      onChange={(e) => setFormData({ ...formData, institution: e.target.value })}
                      placeholder="例如：北京市朝阳区第二医院"
                      className="w-full bg-white border border-slate-300 rounded px-3 py-2 text-xs text-text-dark"
                    />
                  </div>
                </div>
              )}

              {/* 2. 奖励 */}
              {manualTab === 2 && (
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-text-secondary mb-1">奖金金额 (元)</label>
                      <input
                        type="number"
                        value={formData.money}
                        onChange={(e) => setFormData({ ...formData, money: e.target.value })}
                        placeholder="例如：500"
                        className="w-full bg-white border border-slate-300 rounded px-3 py-2 text-xs text-text-dark"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-text-secondary mb-1">奖励时间</label>
                      <input
                        type="date"
                        value={formData.date}
                        onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                        className="w-full bg-white border border-slate-300 rounded px-3 py-2 text-xs text-text-dark"
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-text-secondary mb-1">奖励级别</label>
                      <select
                        value={formData.level}
                        onChange={(e) => setFormData({ ...formData, level: e.target.value })}
                        className="w-full bg-white border border-slate-300 rounded px-3 py-1.5 text-xs text-text-dark"
                      >
                        <option value="项目部级">项目部级</option>
                        <option value="企业级">企业级</option>
                        <option value="省部级">省部级</option>
                        <option value="国家级">国家级</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-text-secondary mb-1">授予颁发单位</label>
                      <input
                        type="text"
                        value={formData.agency}
                        onChange={(e) => setFormData({ ...formData, agency: e.target.value })}
                        placeholder="例如：中建一局安全监察部"
                        className="w-full bg-white border border-slate-300 rounded px-3 py-2 text-xs text-text-dark"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-text-secondary mb-1">奖励证书/表彰名称</label>
                    <input
                      type="text"
                      required
                      value={formData.title}
                      onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                      placeholder="例如：百日安全卫士表彰"
                      className="w-full bg-white border border-slate-300 rounded px-3 py-2 text-xs text-text-dark"
                    />
                  </div>
                </div>
              )}

              {/* 3. 处罚 */}
              {manualTab === 3 && (
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-text-secondary mb-1">罚款金额 (元)</label>
                      <input
                        type="number"
                        value={formData.money}
                        onChange={(e) => setFormData({ ...formData, money: e.target.value })}
                        placeholder="例如：200"
                        className="w-full bg-white border border-slate-300 rounded px-3 py-2 text-xs text-text-dark"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-text-secondary mb-1">处罚惩戒日期</label>
                      <input
                        type="date"
                        value={formData.date}
                        onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                        className="w-full bg-white border border-slate-300 rounded px-3 py-2 text-xs text-text-dark"
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-text-secondary mb-1">处置惩戒方式</label>
                      <input
                        type="text"
                        value={formData.action}
                        onChange={(e) => setFormData({ ...formData, action: e.target.value })}
                        placeholder="例如：警告并罚款/下场清退"
                        className="w-full bg-white border border-slate-300 rounded px-3 py-2 text-xs text-text-dark"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-text-secondary mb-1">安全督查记录人</label>
                      <input
                        type="text"
                        value={formData.recorder}
                        onChange={(e) => setFormData({ ...formData, recorder: e.target.value })}
                        placeholder="例如：李监察"
                        className="w-full bg-white border border-slate-300 rounded px-3 py-2 text-xs text-text-dark"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-text-secondary mb-1">具体违规行为事实</label>
                    <textarea
                      required
                      rows="2"
                      value={formData.reason}
                      onChange={(e) => setFormData({ ...formData, reason: e.target.value })}
                      placeholder="描述违规原因事实，如：进入基坑吊装区域未按规定配戴红色安全防护帽。"
                      className="w-full bg-white border border-slate-300 rounded px-3 py-2 text-xs text-text-dark"
                    ></textarea>
                  </div>
                </div>
              )}

              {/* 4. 培训 */}
              {manualTab === 4 && (
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-text-secondary mb-1">培训总学时 (小时)</label>
                      <input
                        type="number"
                        value={formData.hours}
                        onChange={(e) => setFormData({ ...formData, hours: e.target.value })}
                        className="w-full bg-white border border-slate-300 rounded px-3 py-2 text-xs text-text-dark"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-text-secondary mb-1">考核时间</label>
                      <input
                        type="date"
                        value={formData.date}
                        onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                        className="w-full bg-white border border-slate-300 rounded px-3 py-2 text-xs text-text-dark"
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-text-secondary mb-1">考核结论</label>
                      <select
                        value={formData.result}
                        onChange={(e) => setFormData({ ...formData, result: e.target.value })}
                        className="w-full bg-white border border-slate-300 rounded px-3 py-1.5 text-xs text-text-dark"
                      >
                        <option value="合格">合格</option>
                        <option value="优秀">优秀</option>
                        <option value="不合格">不合格</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-text-secondary mb-1">主要授课讲师</label>
                      <input
                        type="text"
                        value={formData.instructor}
                        onChange={(e) => setFormData({ ...formData, instructor: e.target.value })}
                        placeholder="讲师姓名"
                        className="w-full bg-white border border-slate-300 rounded px-3 py-2 text-xs text-text-dark"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-text-secondary mb-1">培训课程主题</label>
                    <input
                      type="text"
                      required
                      value={formData.course}
                      onChange={(e) => setFormData({ ...formData, course: e.target.value })}
                      placeholder="例如：特种塔吊高空防倾翻安全规程培训"
                      className="w-full bg-white border border-slate-300 rounded px-3 py-2 text-xs text-text-dark"
                    />
                  </div>
                </div>
              )}

              {/* 5. 技能竞赛 */}
              {manualTab === 5 && (
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-text-secondary mb-1">参赛获评工种</label>
                      <input
                        type="text"
                        value={formData.jobType}
                        onChange={(e) => setFormData({ ...formData, jobType: e.target.value })}
                        placeholder="例如：电焊工"
                        className="w-full bg-white border border-slate-300 rounded px-3 py-2 text-xs text-text-dark"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-text-secondary mb-1">名次荣誉</label>
                      <input
                        type="text"
                        value={formData.rank}
                        onChange={(e) => setFormData({ ...formData, rank: e.target.value })}
                        placeholder="例如：二等奖 / 第三名"
                        className="w-full bg-white border border-slate-300 rounded px-3 py-2 text-xs text-text-dark"
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-text-secondary mb-1">竞赛奖金 (元)</label>
                      <input
                        type="number"
                        value={formData.prizeMoney}
                        onChange={(e) => setFormData({ ...formData, prizeMoney: e.target.value })}
                        placeholder="1000"
                        className="w-full bg-white border border-slate-300 rounded px-3 py-2 text-xs text-text-dark"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-text-secondary mb-1">获奖日期</label>
                      <input
                        type="date"
                        value={formData.date}
                        onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                        className="w-full bg-white border border-slate-300 rounded px-3 py-2 text-xs text-text-dark"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-text-secondary mb-1">技能竞赛全称</label>
                    <input
                      type="text"
                      required
                      value={formData.nameOfContest}
                      onChange={(e) => setFormData({ ...formData, nameOfContest: e.target.value })}
                      placeholder="例如：北京市第七届建筑特种行业操作技能竞赛"
                      className="w-full bg-white border border-slate-300 rounded px-3 py-2 text-xs text-text-dark"
                    />
                  </div>
                </div>
              )}

              {/* 6. 荣誉记录 */}
              {manualTab === 6 && (
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-text-secondary mb-1">授予荣誉级别</label>
                      <select
                        value={formData.level}
                        onChange={(e) => setFormData({ ...formData, level: e.target.value })}
                        className="w-full bg-white border border-slate-300 rounded px-3 py-1.5 text-xs text-text-dark"
                      >
                        <option value="项目部级">项目部级</option>
                        <option value="企业级">企业级</option>
                        <option value="省级">省级</option>
                        <option value="国家级">国家级</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-text-secondary mb-1">授予表彰日期</label>
                      <input
                        type="date"
                        value={formData.date}
                        onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                        className="w-full bg-white border border-slate-300 rounded px-3 py-2 text-xs text-text-dark"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-text-secondary mb-1">授予/发证机构单位</label>
                    <input
                      type="text"
                      value={formData.agency}
                      onChange={(e) => setFormData({ ...formData, agency: e.target.value })}
                      placeholder="例如：中国建筑业协会"
                      className="w-full bg-white border border-slate-300 rounded px-3 py-2 text-xs text-text-dark"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-text-secondary mb-1">荣誉称号全称</label>
                    <input
                      type="text"
                      required
                      value={formData.honorName}
                      onChange={(e) => setFormData({ ...formData, honorName: e.target.value })}
                      placeholder="例如：全国优秀青工模范称号"
                      className="w-full bg-white border border-slate-300 rounded px-3 py-2 text-xs text-text-dark"
                    />
                  </div>
                </div>
              )}

              {/* Shared Fields */}
              <div className="border-t border-slate-200 pt-4 space-y-4">
                <div>
                  <label className="block text-xs font-bold text-slate-400 mb-1">附件佐证资料</label>
                  <div className="border border-dashed border-slate-300 rounded p-4 flex items-center justify-center gap-2 bg-slate-50 cursor-pointer hover:bg-slate-100">
                    <Upload className="h-4 w-4 text-text-secondary" />
                    <span className="text-xs text-text-secondary">点击或拖拽上传扫描件PDF、红头文件等 (限制20M)</span>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-text-secondary mb-1">备注说明</label>
                  <textarea
                    rows="2"
                    value={formData.remarks}
                    onChange={(e) => setFormData({ ...formData, remarks: e.target.value })}
                    placeholder="输入其他补充审计信息"
                    className="w-full bg-white border border-slate-300 rounded px-3 py-2 text-xs text-text-dark"
                  ></textarea>
                </div>
              </div>
            </div>

            {/* Footer */}
            <div className="p-4 border-t border-slate-200 bg-slate-50 flex items-center justify-end gap-2 shrink-0">
              <button
                type="button"
                onClick={() => setIsAddModalOpen(false)}
                className="px-4 py-2 bg-white hover:bg-slate-100 border border-slate-300 text-text-dark text-xs font-bold rounded shadow-sm cursor-pointer"
              >
                取消
              </button>
              <button
                type="submit"
                className="px-4 py-2 bg-primary hover:bg-primary-hover text-white text-xs font-bold rounded shadow cursor-pointer transition-colors"
              >
                保存并入库
              </button>
            </div>
          </form>
        </div>
      )}

      {/* ==================== MOCK ATTENDANCE LOCATION MODAL ==================== */}
      {attendanceDetail && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/50" onClick={() => setAttendanceDetail(null)}></div>
          <div className="relative bg-white rounded-lg shadow-2xl w-full max-w-md flex flex-col z-10 overflow-hidden animate-zoom-in">
            <div className="p-4 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
              <h3 className="text-sm font-bold text-text-dark">打卡详情 - {attendanceDetail.name}</h3>
              <button onClick={() => setAttendanceDetail(null)} className="text-slate-400 hover:text-slate-600">
                <X className="h-5 w-5" />
              </button>
            </div>
            <div className="p-6 space-y-4">
              <div className="bg-slate-100 rounded-lg h-40 flex items-center justify-center relative border overflow-hidden">
                {/* Mock Map */}
                <div className="absolute inset-0 opacity-40 bg-[radial-gradient(#e5e7eb_1px,transparent_1px)] [background-size:16px_16px]"></div>
                <div className="absolute h-4 w-4 bg-primary rounded-full animate-ping"></div>
                <div className="absolute h-3 w-3 bg-[#11356A] rounded-full border-2 border-white shadow"></div>
                <div className="absolute bottom-2 left-2 bg-white/95 border px-2 py-0.5 rounded text-[10px] font-bold text-text-dark">
                  地理坐标: 39.9087, 116.3975 (北京东区工地)
                </div>
              </div>
              <div className="space-y-2 text-xs">
                <div>打卡地点：<span className="font-bold text-text-dark">{attendanceDetail.location}</span></div>
                <div>考勤闸机ID：<span className="font-mono text-text-dark bg-slate-100 px-1 rounded">{attendanceDetail.deviceId}</span></div>
                <div>打卡时间：<span className="font-mono text-text-dark">{attendanceDetail.clockIn} (签到) / {attendanceDetail.clockOut} (签退)</span></div>
                <div>人脸核验状态：<span className="text-success-green font-bold flex items-center gap-1 inline-flex"><ShieldCheck className="h-3.5 w-3.5" />已通过实名核验(高可靠度)</span></div>
              </div>
            </div>
            <div className="p-4 border-t border-slate-200 bg-slate-50 flex justify-end">
              <button onClick={() => setAttendanceDetail(null)} className="px-4 py-2 bg-primary text-white text-xs font-bold rounded shadow cursor-pointer">
                知道了
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ==================== MOCK IMPORT EXCEL MODAL ==================== */}
      {isImportModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/50" onClick={() => setIsImportModalOpen(false)}></div>
          <div className="relative bg-white rounded-lg shadow-2xl w-full max-w-md flex flex-col z-10 overflow-hidden animate-zoom-in">
            <div className="p-4 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
              <h3 className="text-sm font-bold text-text-dark">批量导入 Excel 台账</h3>
              <button onClick={() => setIsImportModalOpen(false)} className="text-slate-400 hover:text-slate-600">
                <X className="h-5 w-5" />
              </button>
            </div>
            <div className="p-6 space-y-4">
              <div className="border-2 border-dashed border-slate-300 hover:border-primary rounded-lg p-6 flex flex-col items-center justify-center text-center gap-3 cursor-pointer bg-slate-50 transition-colors">
                <FileSpreadsheet className="h-10 w-10 text-slate-400" />
                <span className="text-xs font-bold text-text-dark">点击选择或拖拽 Excel 文件到此处</span>
                <span className="text-[10px] text-text-secondary">仅支持 xls, xlsx 格式，单文件限 10M</span>
              </div>
              <div className="bg-blue-50 border border-blue-200 rounded p-3 text-xs flex flex-col gap-1 text-primary">
                <div className="font-bold flex items-center gap-1">
                  <HelpCircle className="h-3.5 w-3.5" />
                  导入指引
                </div>
                <div>请先下载系统标准台账模板填报，确保姓名、身份证号等信息与实名制系统库中的人名完全一致，否则将无法匹配建档。</div>
                <a href="#" onClick={(e) => { e.preventDefault(); triggerNotification('已为您开始下载空模板文件...', 'success') }} className="text-xs font-bold underline mt-1 block">
                  下载「系统数据导入标准模板.xlsx」
                </a>
              </div>
            </div>
            <div className="p-4 border-t border-slate-200 bg-slate-50 flex justify-end gap-2">
              <button onClick={() => setIsImportModalOpen(false)} className="px-4 py-2 bg-white border border-slate-300 text-text-dark text-xs font-bold rounded shadow-sm">
                取消
              </button>
              <button
                onClick={() => {
                  setIsImportModalOpen(false)
                  triggerNotification('Excel 表格导入解析成功！已成功批量导入 12 条记录', 'success')
                }}
                className="px-4 py-2 bg-primary text-white text-xs font-bold rounded shadow"
              >
                开始解析导入
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  )
}

export default App
