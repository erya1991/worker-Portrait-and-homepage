import { useState, useMemo } from 'react'
import {
  Layers,
  Plus,
  Filter,
  Check,
  X,
  Search,
  ArrowDown,
  ArrowRight,
  Info,
  Edit2,
  Trash2,
  Settings,
  HelpCircle,
  AlertCircle,
  Workflow,
  Sparkles,
  Heart,
  ShieldAlert,
  Cpu,
  History,
  Award,
  ArrowLeft,
  Copy,
  FileSpreadsheet,
  Activity,
  Play,
  TrendingUp,
  Download,
  Upload,
  RefreshCw,
  CheckCircle2
} from 'lucide-react'

// Initial Tag Categories Mock Data
const INITIAL_CATEGORIES = [
  { id: 'cat1', name: '职业能力', count: 8, updated: '2026-07-09', status: true, desc: '反映工人专业技能等级、操作资质及竞赛奖励' },
  { id: 'cat2', name: '履约能力', desc: '考核打卡考勤天数、工时合同备案及流动稳定性', count: 6, updated: '2026-07-09', status: true },
  { id: 'cat3', name: '安全能力', desc: '监控现场施工违章行为、安全培训受训状态', count: 5, updated: '2026-07-08', status: true },
  { id: 'cat4', name: '健康能力', desc: '体现职业病防护、体检报告筛查及身体健康状态', count: 3, updated: '2026-07-09', status: true },
  { id: 'cat5', name: '信用能力', desc: '联合征信平台、失信记录核实及红黑榜通报', count: 4, updated: '2026-07-07', status: true },
  { id: 'cat6', name: '系统标签', desc: '由系统后台规则引擎根据行为统计自动生成', count: 5, updated: '2026-07-09', status: true },
  { id: 'cat7', name: '自定义标签', desc: '管理员根据特定项目自主定制的手工维护标签', count: 3, updated: '2026-07-06', status: true }
];

// Initial Tags Mock Data
const INITIAL_TAGS = [
  { id: 'TAG-001', name: '工匠先锋', code: 'TAG_CRAFT_HERO', category: '职业能力', color: '#11356A', textCol: '#FFFFFF', method: '系统', hits: 24, status: true, version: 'v1.2.0', desc: '综合评价分在95分以上极优秀工人' },
  { id: 'TAG-002', name: '金牌架子工', code: 'TAG_GOLD_SCAFF', category: '职业能力', color: '#1890FF', textCol: '#FFFFFF', method: 'AI', hits: 12, status: true, version: 'v1.2.0', desc: '特种脚手架持证验证合格且履约良好' },
  { id: 'TAG-003', name: '优秀履约', code: 'TAG_PERF_EXCELLENT', category: '履约能力', color: '#52C41A', textCol: '#FFFFFF', method: '系统', hits: 184, status: true, version: 'v1.1.8', desc: '单月考勤出勤天数达26天及以上' },
  { id: 'TAG-004', name: '全勤标兵', code: 'TAG_ATTEND_HERO', category: '履约能力', color: '#13C2C2', textCol: '#FFFFFF', method: '系统', hits: 95, status: true, version: 'v1.2.0', desc: '连续出勤大于180天无任何请假' },
  { id: 'TAG-005', name: '违章警示', code: 'TAG_SAFE_WARN', category: '安全能力', color: '#FA8C16', textCol: '#FFFFFF', method: 'AI', hits: 15, status: true, version: 'v1.2.0', desc: '违规次数大于2次或进入红线限制' },
  { id: 'TAG-006', name: '安全可信', code: 'TAG_SAFE_TRUST', category: '安全能力', color: '#2F54EB', textCol: '#FFFFFF', method: 'AI', hits: 320, status: true, version: 'v1.1.2', desc: '入场至今无任何安全违章处罚记录' },
  { id: 'TAG-007', name: '高空禁忌', code: 'TAG_HEALTH_FORBID', category: '健康能力', color: '#F5222D', textCol: '#FFFFFF', method: '系统', hits: 2, status: true, version: 'v1.2.0', desc: '体检含高血压或恐高症等禁忌结论' },
  { id: 'TAG-008', name: '市劳模标兵', code: 'TAG_HONOR_MODEL', category: '自定义标签', color: '#FAAD14', textCol: '#FFFFFF', method: '人工', hits: 3, status: true, version: 'v1.0.5', desc: '获得市建协技能比武名次荣誉者' }
];

// Initial Rules Mock Data
const INITIAL_RULES = [
  {
    id: 'RULE-101',
    name: '优秀履约骨干自动贴签规则',
    matchType: 'AND',
    conditions: [
      { field: '出勤天数', op: '大于', val: '26' },
      { field: '违章次数', op: '等于', val: '0' }
    ],
    outputTag: '优秀履约',
    status: true,
    desc: '贴签条件：考勤达标且无处罚'
  },
  {
    id: 'RULE-102',
    name: '高空风险行为自动强控规则',
    matchType: 'OR',
    conditions: [
      { field: '违章次数', op: '大于', val: '2' },
      { field: '体检结论', op: '等于', val: '高空禁忌项' }
    ],
    outputTag: '违章警示',
    status: true,
    desc: '贴签条件：发生违章或体检不合格'
  }
];

// Mock Workers list for simulation
const MOCK_WORKERS = [
  { id: 'w1', name: '张建国', score: 94, tags: ['优秀履约', '安全可信', '全勤标兵'], photo: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150' },
  { id: 'w2', name: '李强', score: 85, tags: ['金牌架子工', '优秀履约'], photo: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=150' },
  { id: 'w3', name: '王朝阳', score: 72, tags: ['安全可信'], photo: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150' },
  { id: 'w4', name: '刘小虎', score: 58, tags: ['高空禁忌', '违章警示'], photo: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150' }
];

// Initial Versions Mock Data
const INITIAL_VERSIONS = [
  { id: 'v1', version: 'v1.2.0', time: '2026-07-09 11:20:15', creator: '张经理', status: '当前激活', desc: '增加了信用能力分类，补充了全勤标兵标签判定公式' },
  { id: 'v2', version: 'v1.1.8', time: '2026-06-15 10:00:00', creator: '李安全', status: '历史版本', desc: '微调高空风险安全扣分界定阈值，调低全勤贴签天数' },
  { id: 'v3', version: 'v1.0.5', time: '2026-05-12 14:30:00', creator: '张经理', status: '历史版本', desc: '初始版本上线，支持三级分类和规则引擎贴签' }
];

export default function TagCenter({ triggerNotification }) {
  const [activeTab, setActiveTab] = useState('categories') // categories, tags, rules, preview, versions

  // Filters
  const [searchKeyword, setSearchKeyword] = useState('')
  const [filterCat, setFilterCat] = useState('ALL')
  const [filterMethod, setFilterMethod] = useState('ALL')

  // Lists state
  const [categories, setCategories] = useState(INITIAL_CATEGORIES)
  const [tags, setTags] = useState(INITIAL_TAGS)
  const [rules, setRules] = useState(INITIAL_RULES)
  const [versions, setVersions] = useState(INITIAL_VERSIONS)

  // Drawer Form Dialogs
  const [isAddTagOpen, setIsAddTagOpen] = useState(false)
  const [editingTag, setEditingTag] = useState(null)
  const [isDetailDrawerOpen, setIsDetailDrawerOpen] = useState(false)
  const [selectedDetails, setSelectedDetails] = useState(null)

  // Form states
  const [tagForm, setTagForm] = useState({
    id: '',
    name: '',
    code: '',
    category: '职业能力',
    color: '#11356A',
    method: '系统',
    desc: '',
    status: true,
    version: 'v1.2.0',
    remarks: ''
  })

  const [isAddCatOpen, setIsAddCatOpen] = useState(false)
  const [catForm, setCatForm] = useState({ id: '', name: '', count: 0, updated: '2026-07-09', status: true, desc: '' })

  // Active Rules editing workstation (Tab 3)
  const [ruleName, setRuleName] = useState('优秀核心骨干自动贴签规则')
  const [ruleMatchType, setRuleMatchType] = useState('AND')
  const [ruleConditions, setRuleConditions] = useState([
    { field: '出勤天数', op: '大于', val: '26' },
    { field: '违章次数', op: '等于', val: '0' }
  ])
  const [ruleOutputTag, setRuleOutputTag] = useState('优秀履约')

  // Simulation parameters (Tab 4)
  const [simWorkerId, setSimWorkerId] = useState('w1')
  const [simulating, setSimulating] = useState(false)
  const [simResult, setSimResult] = useState(null)

  // AI Recommendations bubble
  const aiRecommendedTags = [
    { rule: '安全培训次数 >= 5 且 无违规', tag: '安全标兵', color: '#FA8C16', reason: '工人能够连续参与5次安全例会培训并维持零违章，说明其主观安全意识优异，建议配置自动赋签「安全标兵」。' },
    { rule: '综合评分 >= 92 且 实操技能优秀', tag: '工匠模范', color: '#FAAD14', reason: '结合技能大比武奖项数据，系统建议直接关联「工匠模范」以突出高级技工的业务标杆价值。' }
  ]

  // Dynamic Rule semantic preview translation
  const computedRuleTranslation = useMemo(() => {
    const condStr = ruleConditions.map((c, i) => {
      const relation = i === 0 ? '' : ` ${ruleMatchType === 'AND' ? '且' : '或'} `
      return `${relation}当工人的「${c.field}」 ${c.op} 「${c.val}」`
    }).join('')
    return `【规则判定】：系统在夜间调度清洗时，${condStr}，系统将自动为其关联绑定标签「${ruleOutputTag}」，并推送到工人画像卡片。`
  }, [ruleMatchType, ruleConditions, ruleOutputTag])

  // Drill down filter from categories
  const handleEnterCategory = (catName) => {
    setFilterCat(catName)
    setActiveTab('tags')
    triggerNotification(`已为您筛选分类为「${catName}」的标签台账`, 'info')
  }

  // Save new tag form
  const handleSaveTag = (e) => {
    e.preventDefault()
    if (editingTag) {
      setTags(prev => prev.map(t => t.id === editingTag.id ? { ...tagForm } : t))
      triggerNotification('标签元数据更新成功。', 'success')
    } else {
      const newT = {
        ...tagForm,
        id: `TAG-00${tags.length + 1}`
      }
      setTags(prev => [newT, ...prev])
      triggerNotification('新增评价标签入库成功！', 'success')
    }
    setIsAddTagOpen(false)
  }

  // Toggle Category state
  const handleToggleCategory = (id, currentStatus, name) => {
    setCategories(prev => prev.map(c => {
      if (c.id === id) {
        const next = !currentStatus
        triggerNotification(`已${next ? '激活' : '禁用'}标签分类: ${name}`, 'warning')
        return { ...c, status: next }
      }
      return c
    }))
  }

  // Add condition line
  const handleAddConditionRow = () => {
    setRuleConditions([...ruleConditions, { field: '出勤天数', op: '大于', val: '30' }])
  }

  // Simulate worker tagging
  const handleRunSimulator = () => {
    setSimulating(true)
    setSimResult(null)
    triggerNotification('自动标签规则引擎匹配特征中...', 'info')

    setTimeout(() => {
      const match = MOCK_WORKERS.find(w => w.id === simWorkerId)
      if (match) {
        setSimResult(match)
        triggerNotification(`模拟生成工人「${match.name}」画像标签云！`, 'success')
      }
      setSimulating(false)
    }, 600)
  }

  return (
    <div className="flex-grow flex flex-col gap-6">
      
      {/* 1. Page Header */}
      <div className="bg-white border border-border-gray rounded p-5 flex flex-col md:flex-row md:items-center justify-between gap-4 shrink-0 shadow-sm">
        <div>
          <h2 className="text-xl font-bold text-text-dark flex items-center gap-2">
            <Layers className="h-5.5 w-5.5 text-primary animate-pulse" />
            智能标签配置中心
            <span className="text-xs font-normal text-indigo-700 bg-indigo-50 border border-indigo-200 px-2 py-0.5 rounded">
              数据治理规则引擎
            </span>
          </h2>
          <p className="text-xs text-text-secondary mt-1.5">
            设计IF-THEN复合条件关系，配置安全、履约等评价规则引擎，系统每日全自动将清洗洗涤特征匹配标签投射到人员画像。
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => triggerNotification('标签全库健康状态良好，共计命中 658 人次。', 'success')}
            className="px-3 py-1.5 bg-slate-100 border rounded font-bold text-xs text-text-dark flex items-center gap-1 cursor-pointer"
          >
            <Workflow className="h-3.5 w-3.5 text-primary" />
            全局贴签规则已就绪
          </button>
        </div>
      </div>

      {/* 2. Top KPI Cards (5 Columns) */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-6 shrink-0">
        {[
          { title: '标签总数量', val: `${tags.length} 个`, desc: '7 大类分类标签', time: '自动更新', icon: <Layers className="h-5 w-5 text-primary" /> },
          { title: '自动贴签规则', val: `${rules.length} 条`, desc: '规则自动跑分计算', time: '发版归档', icon: <Workflow className="h-5 w-5 text-indigo-500" /> },
          { title: '人工评定标签', val: '2 个', desc: '供评优表彰手工补登', time: '更新于昨日', icon: <Edit2 className="h-5 w-5 text-[#52C41A]" /> },
          { title: '激活启用标签', val: `${tags.filter(t => t.status).length} 个`, desc: '覆盖率达到 88%', time: '自动状态', icon: <CheckCircle2 className="h-5 w-5 text-success-green" /> },
          { title: '今日新增命中', val: '14 人次', desc: '闸机考勤自动匹配', time: '今日跑跑结果', icon: <Sparkles className="h-5 w-5 text-orange-500" /> }
        ].map((kpi, idx) => (
          <div key={idx} className="bg-white border border-border-gray p-4 rounded-lg shadow-sm flex flex-col justify-between hover:shadow-md transition-all border-l-4 border-l-primary">
            <div className="flex items-start justify-between">
              <div className="text-[10px] text-text-secondary font-bold uppercase tracking-wider">{kpi.title}</div>
              <div className="bg-slate-50 p-1.5 rounded">{kpi.icon}</div>
            </div>
            <div className="mt-2.5">
              <div className="text-xl font-black text-text-dark font-mono leading-none">{kpi.val}</div>
              <div className="flex items-center justify-between text-[10px] text-text-secondary mt-2">
                <span className="font-semibold text-primary">{kpi.desc}</span>
                <span>{kpi.time.split(' ')[0]}</span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* 3. Tab Navigation */}
      <div className="bg-white border border-border-gray rounded shadow-sm flex flex-col min-h-[500px] flex-grow">
        
        {/* Navigation tabs menu */}
        <div className="flex border-b border-border-gray bg-slate-50 px-4 pt-3 shrink-0">
          {[
            { id: 'categories', label: '标签分类管理', icon: <Layers className="h-4 w-4" /> },
            { id: 'tags', label: '标签库台账', icon: <Filter className="h-4 w-4" /> },
            { id: 'rules', label: '规则引擎编辑器', icon: <Workflow className="h-4 w-4" /> },
            { id: 'preview', label: '标签命中与拓扑预览', icon: <Activity className="h-4 w-4" /> },
            { id: 'versions', label: '贴签版本历史', icon: <History className="h-4 w-4" /> }
          ].map(t => (
            <button
              key={t.id}
              onClick={() => setActiveTab(t.id)}
              className={`flex items-center gap-1.5 px-4.5 py-3 text-xs font-bold border-t-2 border-x transition-all duration-150 cursor-pointer ${
                activeTab === t.id
                  ? 'bg-white border-x-border-gray border-t-primary text-primary -mb-[1px] relative z-10 shadow-[0_-2px_10px_rgba(0,0,0,0.03)]'
                  : 'bg-transparent border-transparent text-text-secondary hover:text-primary hover:bg-slate-100'
              }`}
            >
              {t.icon}
              <span>{t.label}</span>
            </button>
          ))}
        </div>

        {/* Dynamic Panels */}
        <div className="p-6 flex-grow flex flex-col min-h-[380px]">
          
          {/* ==========================================
              TAB 1: 标签分类 (Card Grid)
              ========================================== */}
          {activeTab === 'categories' && (
            <div className="flex-grow flex flex-col gap-6">
              
              <div className="flex items-center justify-between border-b pb-3 shrink-0">
                <div className="text-xs text-text-secondary font-bold">
                  系统对标签进行 7 大科学分类归档，支持灵活开关。点击卡片可直接查看分类下具体标签细明。
                </div>
                <button
                  onClick={() => {
                    setCatForm({
                      id: `cat_${Date.now()}`,
                      name: '工会荣誉标志',
                      count: 0,
                      updated: '2026-07-09',
                      status: true,
                      desc: '融合省市级各产业总工会对工人的红色标兵、杰出人物表彰标志。'
                    })
                    setIsAddCatOpen(true)
                  }}
                  className="px-3.5 py-1.5 bg-[#52C41A] hover:bg-emerald-600 text-white rounded font-bold text-xs shadow-sm cursor-pointer flex items-center gap-1"
                >
                  <Plus className="h-3.5 w-3.5" />
                  新增分类
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-4 gap-6 flex-grow">
                {categories.map(c => (
                  <div key={c.id} className="bg-slate-50 border border-slate-200 rounded-lg p-5 flex flex-col justify-between hover:shadow-md transition-shadow relative">
                    <div className="absolute top-0 right-0 h-1.5 w-full bg-[#11356A]" style={{ opacity: c.status ? 1 : 0.2 }}></div>
                    <div>
                      <div className="flex items-center justify-between mb-3">
                        <h3 className="font-bold text-text-dark text-sm flex items-center gap-1.5">
                          {c.name}
                          <span className={`inline-block h-2 w-2 rounded-full ${c.status ? 'bg-success-green' : 'bg-slate-400'}`}></span>
                        </h3>
                        <input
                          type="checkbox"
                          checked={c.status}
                          onChange={() => handleToggleCategory(c.id, c.status, c.name)}
                          className="h-3.5 w-3.5 cursor-pointer"
                        />
                      </div>
                      <p className="text-xs text-text-secondary leading-relaxed mb-4">{c.desc}</p>
                    </div>

                    <div className="border-t pt-3 mt-4 space-y-2 text-xs">
                      <div className="flex justify-between font-mono">
                        <span className="text-text-secondary">标签数量：</span>
                        <span className="font-bold text-[#11356A]">{c.count} 个</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-text-secondary">最后更新时间：</span>
                        <span className="font-mono text-text-secondary">{c.updated}</span>
                      </div>
                      <div className="flex items-center justify-end pt-2">
                        <button
                          onClick={() => handleEnterCategory(c.name)}
                          className="px-3 py-1 bg-white hover:bg-slate-100 border border-slate-300 text-text-dark text-xs font-bold rounded shadow-sm cursor-pointer flex items-center gap-0.5"
                        >
                          进入标签
                          <ArrowRight className="h-3 w-3" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

            </div>
          )}

          {/* ==========================================
              TAB 2: 标签库台账 (Table list)
              ========================================== */}
          {activeTab === 'tags' && (
            <div className="flex-grow flex flex-col gap-6">
              
              {/* Search bar */}
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-50 p-4 border border-border-gray rounded shrink-0">
                <div className="flex items-center gap-4 flex-wrap">
                  <div className="relative">
                    <input
                      type="text"
                      value={searchKeyword}
                      onChange={(e) => setSearchKeyword(e.target.value)}
                      placeholder="搜索标签名称/编码..."
                      className="bg-white border border-slate-300 rounded px-2.5 pl-8 py-1 text-xs text-text-dark w-48"
                    />
                    <Search className="absolute left-2.5 top-2 h-3.5 w-3.5 text-slate-400" />
                  </div>

                  <div>
                    <select
                      value={filterCat}
                      onChange={(e) => setFilterCat(e.target.value)}
                      className="bg-white border border-slate-300 rounded px-2 py-1 text-xs text-text-dark"
                    >
                      <option value="ALL">全部标签分类</option>
                      <option value="职业能力">职业能力</option>
                      <option value="履约能力">履约能力</option>
                      <option value="安全能力">安全能力</option>
                      <option value="健康能力">健康能力</option>
                      <option value="信用能力">信用能力</option>
                      <option value="自定义标签">自定义标签</option>
                    </select>
                  </div>

                  <div>
                    <select
                      value={filterMethod}
                      onChange={(e) => setFilterMethod(e.target.value)}
                      className="bg-white border border-slate-300 rounded px-2 py-1 text-xs text-text-dark"
                    >
                      <option value="ALL">全部生成方式</option>
                      <option value="系统">系统生成</option>
                      <option value="AI">AI 识别</option>
                      <option value="人工">人工评定</option>
                    </select>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button onClick={() => triggerNotification('正在过滤筛选标签库...', 'info')} className="px-3.5 py-1.5 bg-[#11356A] hover:bg-primary-hover text-white text-xs font-bold rounded shadow-sm cursor-pointer">查询</button>
                  <button onClick={() => { setSearchKeyword(''); setFilterCat('ALL'); setFilterMethod('ALL') }} className="px-3.5 py-1.5 bg-white hover:bg-slate-50 text-text-dark border border-slate-300 text-xs font-bold rounded shadow-sm cursor-pointer">重置</button>
                </div>
              </div>

              {/* Toolbar */}
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white border border-border-gray p-4 rounded shrink-0">
                <div className="text-xs text-text-secondary font-bold flex items-center gap-1.5">
                  <Filter className="h-4 w-4 text-primary animate-pulse" />
                  <span>当前筛选出 {tags.length} 个评价标签</span>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => {
                      setTagForm({
                        id: '',
                        name: '优秀泥工标兵',
                        code: 'TAG_MUD_HERO',
                        category: '职业能力',
                        color: '#722ED1',
                        method: '系统',
                        desc: '实操能力分大于90分且项目经理核发好评。',
                        status: true,
                        version: 'v1.2.0',
                        remarks: ''
                      })
                      setEditingTag(null)
                      setIsAddTagOpen(true)
                    }}
                    className="px-3 py-1.5 bg-[#52C41A] hover:bg-emerald-600 text-white rounded font-bold text-xs shadow-sm cursor-pointer flex items-center gap-1"
                  >
                    <Plus className="h-3.5 w-3.5" />
                    新增标签
                  </button>
                  <button
                    onClick={() => triggerNotification('Excel 导出完成！', 'success')}
                    className="px-3 py-1.5 bg-white border border-slate-300 text-text-dark rounded font-bold text-xs shadow-sm cursor-pointer flex items-center gap-1 hover:bg-slate-50"
                  >
                    <Download className="h-3.5 w-3.5" />
                    导出Excel
                  </button>
                </div>
              </div>

              {/* Table */}
              <div className="flex-grow border border-border-gray rounded-lg overflow-x-auto">
                <table className="b-table text-xs">
                  <thead>
                    <tr>
                      <th>标签编码</th>
                      <th>标签名称</th>
                      <th>所属大分类</th>
                      <th>生成方式</th>
                      <th>覆盖命中人数</th>
                      <th>启用状态</th>
                      <th>创建版本</th>
                      <th>最后更新</th>
                      <th>备注/说明</th>
                      <th className="text-right">操作</th>
                    </tr>
                  </thead>
                  <tbody>
                    {tags.map(item => (
                      <tr key={item.id} className="hover:bg-slate-50 transition-colors">
                        <td className="font-mono font-bold text-[#11356A]">{item.code}</td>
                        <td>
                          <span
                            className="px-2.5 py-0.8 rounded-full font-bold text-[10.5px] shadow-sm text-white"
                            style={{ backgroundColor: item.color }}
                          >
                            {item.name}
                          </span>
                        </td>
                        <td>
                          <span className="bg-slate-100 text-text-dark border px-2 py-0.5 rounded text-[10px] font-bold">
                            {item.category}
                          </span>
                        </td>
                        <td>
                          <span className={`text-[10px] px-1.5 py-0.5 rounded font-black border ${
                            item.method === 'AI' ? 'bg-indigo-50 text-indigo-700 border-indigo-200' :
                            item.method === '人工' ? 'bg-amber-50 text-amber-700 border-amber-200' :
                            'bg-slate-50 text-slate-700 border-slate-200'
                          }`}>
                            {item.method}
                          </span>
                        </td>
                        <td className="font-mono font-bold text-primary">{item.hits} 人</td>
                        <td>
                          <input
                            type="checkbox"
                            checked={item.status}
                            onChange={() => {
                              setTags(prev => prev.map(t => t.id === item.id ? { ...t, status: !t.status } : t))
                              triggerNotification(`标签状态已切换。`, 'info')
                            }}
                            className="h-3.5 w-3.5 cursor-pointer"
                          />
                        </td>
                        <td className="font-mono text-text-secondary">{item.version}</td>
                        <td className="font-mono text-text-secondary">2026-07-09</td>
                        <td className="max-w-[150px] truncate text-text-secondary" title={item.desc}>{item.desc}</td>
                        <td className="text-right">
                          <div className="flex items-center justify-end gap-1.5">
                            <button
                              onClick={() => {
                                setSelectedDetails(item)
                                setIsDetailDrawerOpen(true)
                              }}
                              className="text-text-secondary hover:text-text-dark font-bold text-xs bg-slate-50 border px-2 py-1 rounded cursor-pointer"
                            >
                              查看
                            </button>
                            <button
                              onClick={() => {
                                setEditingTag(item)
                                setTagForm({ ...item })
                                setIsAddTagOpen(true)
                              }}
                              className="text-primary hover:text-primary-hover font-bold text-xs bg-primary/5 border border-primary/20 px-2 py-1 rounded cursor-pointer"
                            >
                              编辑
                            </button>
                            <button
                              onClick={() => {
                                const copied = {
                                  ...item,
                                  id: `TAG-00${tags.length + 1}`,
                                  code: `${item.code}_COPY`,
                                  name: `${item.name}_复制`
                                }
                                setTags(prev => [...prev, copied])
                                triggerNotification(`标签「${item.name}」已克隆生成副本。`, 'success')
                              }}
                              className="text-indigo-600 hover:text-indigo-800 font-bold text-xs bg-indigo-50 border border-indigo-200 px-2 py-1 rounded cursor-pointer"
                            >
                              复制
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

            </div>
          )}

          {/* ==========================================
              TAB 3: 规则引擎编辑器 (IF THEN Builder)
              ========================================== */}
          {activeTab === 'rules' && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 flex-grow">
              
              {/* Left: IF THEN condition editor */}
              <div className="lg:col-span-8 bg-white border border-border-gray rounded-lg p-5 flex flex-col gap-5 shadow-sm">
                
                {/* AI Rec bubbles */}
                <div className="bg-indigo-50 border border-indigo-150 p-4 rounded-lg flex items-start gap-3 text-xs shrink-0">
                  <Cpu className="h-6 w-6 text-indigo-500 animate-bounce shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold text-[#11356A] block">AI 标签规则推荐算法助手</span>
                    <p className="text-text-secondary text-[11px] leading-relaxed mt-1">
                      通过对已建档 1,265 名工人的大数据多维挖掘，AI 智能发现如下极优贴签规则公式：
                    </p>
                    <div className="mt-2 space-y-2 border-t pt-2 border-indigo-150">
                      {aiRecommendedTags.map((rec, idx) => (
                        <div key={idx} className="bg-white border p-3 rounded space-y-1">
                          <div className="flex items-center justify-between">
                            <span className="font-mono text-indigo-700 font-bold">IF: {rec.rule}</span>
                            <span className="px-2 py-0.5 rounded font-black text-[10px] text-white" style={{ backgroundColor: rec.color }}>
                              THEN: {rec.tag}
                            </span>
                          </div>
                          <p className="text-[10px] text-text-secondary leading-normal">{rec.reason}</p>
                          <button
                            onClick={() => {
                              setRuleOutputTag(rec.tag)
                              setRuleConditions([
                                { field: '安全培训次数', op: '大于', val: '5' },
                                { field: '违章次数', op: '等于', val: '0' }
                              ])
                              triggerNotification(`已导入 AI 推荐的「${rec.tag}」判定配置。`, 'success')
                            }}
                            className="text-[10px] text-indigo-600 font-black hover:underline mt-1 block"
                          >
                            采纳并载入此 AI 推荐公式
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* IF block */}
                <div className="space-y-4">
                  <div className="text-xs font-bold text-text-dark border-l-4 border-primary pl-2 uppercase tracking-wide">
                    第一步：IF - 判定触发条件组合
                  </div>
                  
                  <div className="flex items-center gap-4 bg-slate-50 p-3 border rounded text-xs">
                    <span className="font-bold text-text-secondary shrink-0">条件关系联结：</span>
                    <div className="flex bg-slate-200 p-0.5 rounded">
                      <button
                        type="button"
                        onClick={() => setRuleMatchType('AND')}
                        className={`px-3 py-1 font-bold text-[10px] rounded cursor-pointer transition-colors ${
                          ruleMatchType === 'AND' ? 'bg-[#11356A] text-white shadow-sm' : 'text-text-secondary'
                        }`}
                      >
                        AND (全部满足)
                      </button>
                      <button
                        type="button"
                        onClick={() => setRuleMatchType('OR')}
                        className={`px-3 py-1 font-bold text-[10px] rounded cursor-pointer transition-colors ${
                          ruleMatchType === 'OR' ? 'bg-[#11356A] text-white shadow-sm' : 'text-text-secondary'
                        }`}
                      >
                        OR (任一满足)
                      </button>
                    </div>
                    <button
                      type="button"
                      onClick={handleAddConditionRow}
                      className="text-primary hover:text-primary-hover font-bold ml-auto flex items-center gap-0.5 cursor-pointer"
                    >
                      <Plus className="h-3.5 w-3.5" />
                      添加判定行
                    </button>
                  </div>

                  <div className="space-y-2 text-xs">
                    {ruleConditions.map((cond, idx) => (
                      <div key={idx} className="flex items-center gap-3 bg-slate-50 border p-3 rounded">
                        <span className="font-bold text-text-secondary w-16">条件行 {idx + 1}:</span>
                        
                        <select
                          value={cond.field}
                          onChange={(e) => setRuleConditions(ruleConditions.map((c, i) => i === idx ? { ...c, field: e.target.value } : c))}
                          className="bg-white border rounded px-2 py-1.5 w-36"
                        >
                          <option value="出勤天数">出勤天数 (履约)</option>
                          <option value="违章次数">违章次数 (安全)</option>
                          <option value="综合评分">工人综合评分 (画像)</option>
                          <option value="体检结论">体检结论 (健康)</option>
                          <option value="特种证验证">特种证验证 (能力)</option>
                        </select>

                        <select
                          value={cond.op}
                          onChange={(e) => setRuleConditions(ruleConditions.map((c, i) => i === idx ? { ...c, op: e.target.value } : c))}
                          className="bg-white border rounded px-2 py-1.5 w-24"
                        >
                          <option value="大于">大于</option>
                          <option value="等于">等于</option>
                          <option value="小于">小于</option>
                          <option value="包含">包含</option>
                        </select>

                        <input
                          type="text"
                          value={cond.val}
                          onChange={(e) => setRuleConditions(ruleConditions.map((c, i) => i === idx ? { ...c, val: e.target.value } : c))}
                          className="bg-white border rounded px-2.5 py-1.5 w-32 font-bold text-text-dark text-center"
                        />

                        {ruleConditions.length > 1 && (
                          <button
                            type="button"
                            onClick={() => setRuleConditions(ruleConditions.filter((c, i) => i !== idx))}
                            className="text-danger-red hover:text-red-700 ml-auto cursor-pointer"
                          >
                            <Trash2 className="h-4.5 w-4.5" />
                          </button>
                        )}
                      </div>
                    ))}
                  </div>
                </div>

                {/* THEN block */}
                <div className="space-y-3 pt-4 border-t border-dashed">
                  <div className="text-xs font-bold text-text-dark border-l-4 border-primary pl-2 uppercase tracking-wide">
                    第二步：THEN - 贴附目标评估标签
                  </div>

                  <div className="grid grid-cols-2 gap-4 text-xs">
                    <div>
                      <label className="block text-text-secondary mb-1">公式标签规则名称</label>
                      <input
                        type="text"
                        value={ruleName}
                        onChange={(e) => setRuleName(e.target.value)}
                        className="w-full bg-white border rounded px-3 py-1.5 text-text-dark"
                      />
                    </div>
                    <div>
                      <label className="block text-text-secondary mb-1">对应输出的标签</label>
                      <select
                        value={ruleOutputTag}
                        onChange={(e) => setRuleOutputTag(e.target.value)}
                        className="w-full bg-white border rounded px-2.5 py-1.5 text-text-dark font-bold text-[#11356A]"
                      >
                        {tags.map(t => (
                          <option key={t.id} value={t.name}>{t.name}</option>
                        ))}
                      </select>
                    </div>
                  </div>
                </div>

                <div className="flex justify-end gap-2 border-t pt-4">
                  <button
                    onClick={() => {
                      const newRule = {
                        id: `RULE-${Date.now().toString().slice(-3)}`,
                        name: ruleName,
                        matchType: ruleMatchType,
                        conditions: [...ruleConditions],
                        outputTag: ruleOutputTag,
                        status: true,
                        desc: `AI-OCR贴签规则`
                      }
                      setRules(prev => [newRule, ...prev])
                      triggerNotification('判定逻辑引擎公式已保存并发布！', 'success')
                    }}
                    className="px-5 py-2 bg-primary hover:bg-[#1b3d6f] text-white text-xs font-bold rounded shadow-sm cursor-pointer"
                  >
                    保存并激活规则
                  </button>
                </div>

              </div>

              {/* Right: Rules semantic previews */}
              <div className="lg:col-span-4 bg-indigo-50/40 border border-indigo-100 rounded-lg p-5 flex flex-col gap-4 shadow-sm">
                <div className="flex items-center gap-1.5 text-[#11356A] font-bold text-xs shrink-0 border-b pb-2">
                  <Workflow className="h-4.5 w-4.5 text-indigo-600" />
                  <span>条件规则引擎语义翻译</span>
                </div>

                <div className="bg-white border border-indigo-150 p-4 rounded shadow-sm space-y-3 text-xs flex-grow">
                  <div className="font-bold text-text-dark">规则名：{ruleName}</div>
                  <div className="text-[11px] text-text-secondary">组合联结方式：{ruleMatchType}</div>
                  <div className="h-[1px] bg-slate-200"></div>
                  <p className="text-indigo-850 font-semibold leading-relaxed">
                    {computedRuleTranslation}
                  </p>
                </div>

                <div className="bg-white border rounded p-3 text-[10px] text-text-secondary space-y-1">
                  <div className="font-bold text-text-dark">最近运行统计：</div>
                  <div>- 日运行频率：每天凌晨 00:30</div>
                  <div>- 昨日自动命中贴签总数：142 人</div>
                </div>
              </div>

            </div>
          )}

          {/* ==========================================
              TAB 4: 标签预览与分析 (Simulation + Coverage charts + Topology)
              ========================================== */}
          {activeTab === 'preview' && (
            <div className="flex-grow flex flex-col gap-8">
              
              {/* Simulation Sandbox */}
              <div className="bg-white border rounded-lg p-5 flex flex-col gap-4 shadow-sm shrink-0">
                <div className="flex items-center justify-between border-b pb-2 text-xs">
                  <span className="font-bold text-text-dark flex items-center gap-1">
                    <Sparkles className="h-4.5 w-4.5 text-indigo-600 animate-pulse" />
                    工人贴签画像实时测演模拟
                  </span>
                  <div>
                    <select value={simWorkerId} onChange={(e) => setSimWorkerId(e.target.value)} className="bg-white border rounded px-2.5 py-1 text-xs text-text-dark">
                      <option value="w1">张建国 (特种塔吊工)</option>
                      <option value="w2">李强 (架子工)</option>
                      <option value="w3">王朝阳 (泥工)</option>
                      <option value="w4">刘小虎 (安全风险警退人员)</option>
                    </select>
                  </div>
                </div>

                <button onClick={handleRunSimulator} disabled={simulating} className="w-full py-2 bg-primary text-white text-xs font-bold rounded shadow cursor-pointer">
                  {simulating ? '引擎匹配运算中...' : '生成模拟工人画像标签云'}
                </button>

                {simResult && (
                  <div className="bg-slate-50 border border-slate-200 p-5 rounded-lg flex flex-col md:flex-row items-center gap-6 animate-zoom-in text-xs">
                    <div className="flex items-center gap-4 border-r pr-6 shrink-0">
                      <div className="h-14 w-14 bg-primary text-white rounded-full flex items-center justify-center font-bold text-sm border-2 border-white shadow">
                        {simResult.name.slice(0, 1)}
                      </div>
                      <div>
                        <div className="text-sm font-bold text-text-dark">{simResult.name}</div>
                        <div className="text-[10px] text-[#52C41A] font-bold bg-emerald-50 px-2 py-0.5 rounded mt-1 border border-emerald-150">
                          综合评价：{simResult.score}分
                        </div>
                      </div>
                    </div>

                    <div className="flex flex-wrap gap-2 flex-grow">
                      {simResult.tags.map((tag, idx) => {
                        const matchingTagObj = tags.find(t => t.name === tag)
                        return (
                          <div
                            key={idx}
                            onClick={() => triggerNotification(`标签「${tag}」命中原因：${matchingTagObj?.desc || '规则自动贴签'}`, 'info')}
                            className="px-3.5 py-1.5 rounded-full font-bold text-[10.5px] cursor-pointer hover:scale-105 transition-all text-white shadow-sm flex items-center gap-1"
                            style={{ backgroundColor: matchingTagObj?.color || '#11356A' }}
                          >
                            <span>{tag}</span>
                            <Info className="h-3 w-3" />
                          </div>
                        )
                      })}
                    </div>
                  </div>
                )}
              </div>

              {/* Hit count Analytics (Custom SVG) & Topology */}
              <div className="grid grid-cols-1 md:grid-cols-12 gap-8 flex-grow">
                
                {/* Hit analytics */}
                <div className="md:col-span-6 bg-white border border-border-gray rounded-lg p-5 flex flex-col justify-between shadow-sm">
                  <div className="text-xs font-bold text-text-dark mb-4 border-b pb-2">标签命中人数与覆盖率分析</div>
                  
                  {/* SVG Bar Chart */}
                  <div className="h-44 w-full flex items-end justify-between border-b border-l pb-2 pl-2">
                    {[
                      { name: '全勤标兵', count: 95, cover: '7.5%' },
                      { name: '安全可信', count: 320, cover: '25%' },
                      { name: '优秀履约', count: 184, cover: '14.5%' },
                      { name: '违章警示', count: 15, cover: '1.2%' }
                    ].map((bar, idx) => (
                      <div key={idx} className="flex flex-col items-center gap-2 flex-1">
                        <div className="text-[10px] font-bold text-primary font-mono">{bar.count}人</div>
                        <div className="bg-[#11356A] rounded-t w-10 transition-all duration-300 hover:bg-indigo-700" style={{ height: `${(bar.count / 320) * 110}px` }}></div>
                        <div className="text-[9px] text-text-secondary truncate max-w-[80px] text-center" title={bar.name}>{bar.name}</div>
                      </div>
                    ))}
                  </div>

                  <div className="text-[10px] text-text-secondary mt-3">说明：反映当前在场劳务工人被贴签的分布结构，以防止个别标签覆盖率偏畸。</div>
                </div>

                {/* Tag topology chains (light background flow) */}
                <div className="md:col-span-6 bg-slate-50 border border-slate-200 rounded-lg p-5 flex flex-col justify-between shadow-sm">
                  <div className="text-xs font-bold text-[#11356A] mb-4 border-b pb-2">评价模型与智能标签传导拓扑关系</div>
                  
                  {/* SVG Topology Nodes Map */}
                  <div className="flex-grow flex flex-col items-center justify-center py-4">
                    <div className="flex flex-col items-center gap-1.5 bg-white border-2 border-indigo-250 p-2.5 rounded shadow-sm text-xs w-48 text-center">
                      <span className="font-bold text-text-dark">1. 实名制/AI 原始数据流入</span>
                      <span className="text-[9px] text-text-secondary font-mono">考勤打卡、安全积分扣减</span>
                    </div>
                    
                    <div className="h-5 w-[2px] bg-slate-400 my-1 relative">
                      <div className="absolute top-1 -left-1 text-[8px] text-slate-400">▼</div>
                    </div>

                    <div className="flex flex-col items-center gap-1.5 bg-white border-2 border-emerald-250 p-2.5 rounded shadow-sm text-xs w-48 text-center">
                      <span className="font-bold text-text-dark">2. 综合评价打分引擎</span>
                      <span className="text-[9px] text-text-secondary font-mono">计算综合分: 94分</span>
                    </div>

                    <div className="h-5 w-[2px] bg-slate-400 my-1 relative">
                      <div className="absolute top-1 -left-1 text-[8px] text-slate-400">▼</div>
                    </div>

                    <div className="flex flex-col items-center gap-1.5 bg-indigo-600 p-2.5 rounded shadow text-xs w-48 text-center text-white">
                      <span className="font-bold">3. 自动匹配判定引擎贴签</span>
                      <span className="text-[9px] text-indigo-200 font-mono">命中：「优秀履约」标签</span>
                    </div>
                  </div>

                  <div className="text-[10px] text-text-secondary">点击拓扑链中的任何一环，即可实时向右穿透对应的底层评价流水。</div>
                </div>

              </div>

            </div>
          )}

          {/* ==========================================
              TAB 5: 标签版本管理
              ========================================== */}
          {activeTab === 'versions' && (
            <div className="flex-grow flex flex-col gap-6">
              
              <div className="flex-grow border border-border-gray rounded-lg overflow-x-auto">
                <table className="b-table text-xs">
                  <thead>
                    <tr>
                      <th>版本归档号</th>
                      <th>发版时间</th>
                      <th>发版操作员</th>
                      <th>版本发版说明</th>
                      <th>使用状态</th>
                      <th className="text-right">操作</th>
                    </tr>
                  </thead>
                  <tbody>
                    {versions.map(v => (
                      <tr key={v.id} className="hover:bg-slate-50 transition-colors">
                        <td className="font-mono font-bold text-[#11356A]">{v.version}</td>
                        <td className="font-mono text-text-secondary">{v.time}</td>
                        <td className="font-bold text-text-dark">{v.creator}</td>
                        <td className="max-w-md truncate text-text-secondary" title={v.desc}>{v.desc}</td>
                        <td>
                          <span className={`px-2 py-0.5 rounded text-[10px] font-black ${
                            v.status === '当前激活' ? 'bg-emerald-50 text-success-green border border-emerald-250' : 'bg-slate-100 text-slate-400 border border-slate-200'
                          }`}>
                            {v.status}
                          </span>
                        </td>
                        <td className="text-right font-bold">
                          <div className="flex items-center justify-end gap-1.5">
                            <button
                              onClick={() => triggerNotification(`已成功克隆归档贴签规则：${v.version}`, 'success')}
                              className="text-text-secondary hover:text-text-dark font-bold text-xs bg-slate-50 border px-2 py-1 rounded cursor-pointer"
                            >
                              复制
                            </button>
                            <button
                              onClick={() => {
                                if (confirm(`确认回滚标签规则至历史版本「${v.version}」吗？`)) {
                                  triggerNotification(`标签规则库成功回退至版本: ${v.version}！正在重新预刷画像...`, 'success')
                                }
                              }}
                              disabled={v.status === '当前激活'}
                              className={`font-bold text-xs border px-2 py-1 rounded ${
                                v.status === '当前激活'
                                  ? 'bg-slate-100 text-slate-400 border-slate-200 cursor-not-allowed'
                                  : 'text-primary hover:text-primary-hover bg-primary/5 border-primary/20 cursor-pointer'
                              }`}
                            >
                              回滚至此版本
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

            </div>
          )}

        </div>
      </div>

      {/* ======================================================================
          DRAWER 1: ADD/EDIT TAG (新增/修改标签右侧抽屉)
          ====================================================================== */}
      {isAddTagOpen && (
        <div className="fixed inset-0 z-50 flex justify-end">
          {/* Overlay */}
          <div className="absolute inset-0 bg-black/50 transition-opacity" onClick={() => setIsAddTagOpen(false)}></div>

          {/* Form Panel */}
          <form
            onSubmit={handleSaveTag}
            className="relative w-full max-w-lg bg-white h-full shadow-2xl flex flex-col z-10 animate-slide-in"
          >
            {/* Header */}
            <div className="p-5 border-b bg-slate-50 border-slate-200 flex items-center justify-between shrink-0">
              <h3 className="text-sm font-black text-text-dark flex items-center gap-1.5">
                <Layers className="h-5 w-5 text-primary animate-pulse" />
                <span>{editingTag ? '编辑评价标签' : '新增评价标签'}</span>
              </h3>
              <button type="button" onClick={() => setIsAddTagOpen(false)} className="text-slate-400 hover:text-slate-600 p-1">
                <X className="h-5 w-5" />
              </button>
            </div>

            {/* Scrollable inputs */}
            <div className="flex-grow p-6 overflow-y-auto space-y-4 text-xs">
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block font-bold text-text-secondary mb-1">所属大分类</label>
                  <select
                    value={tagForm.category}
                    onChange={(e) => setTagForm({ ...tagForm, category: e.target.value })}
                    className="w-full bg-white border border-slate-300 rounded px-2.5 py-1.5 text-text-dark"
                  >
                    <option value="职业能力">职业能力</option>
                    <option value="履约能力">履约能力</option>
                    <option value="安全能力">安全能力</option>
                    <option value="健康能力">健康能力</option>
                    <option value="信用能力">信用能力</option>
                    <option value="自定义标签">自定义标签</option>
                  </select>
                </div>
                <div>
                  <label className="block font-bold text-text-secondary mb-1">标签唯一编码</label>
                  <input
                    type="text"
                    required
                    value={tagForm.code}
                    onChange={(e) => setTagForm({ ...tagForm, code: e.target.value })}
                    placeholder="如: TAG_ATTEND_HERO"
                    className="w-full bg-white border border-slate-300 rounded px-2.5 py-1.5 text-text-dark font-mono font-bold"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block font-bold text-text-secondary mb-1">标签显示名称</label>
                  <input
                    type="text"
                    required
                    value={tagForm.name}
                    onChange={(e) => setTagForm({ ...tagForm, name: e.target.value })}
                    placeholder="标签全名"
                    className="w-full bg-white border border-slate-300 rounded px-2.5 py-1.5 text-text-dark"
                  />
                </div>
                <div>
                  <label className="block font-bold text-text-secondary mb-1">数据生成方式</label>
                  <select
                    value={tagForm.method}
                    onChange={(e) => setTagForm({ ...tagForm, method: e.target.value })}
                    className="w-full bg-white border border-slate-300 rounded px-2.5 py-1.5 text-text-dark font-bold text-primary"
                  >
                    <option value="系统">系统生成</option>
                    <option value="AI">AI 识别</option>
                    <option value="人工">人工评定</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block font-bold text-text-secondary mb-1">标签视觉颜色</label>
                  <input
                    type="color"
                    value={tagForm.color}
                    onChange={(e) => setTagForm({ ...tagForm, color: e.target.value })}
                    className="w-full h-8 cursor-pointer rounded border"
                  />
                </div>
                <div>
                  <label className="block font-bold text-text-secondary mb-1">文字视觉颜色</label>
                  <input
                    type="color"
                    value={tagForm.textCol}
                    onChange={(e) => setTagForm({ ...tagForm, textCol: e.target.value })}
                    className="w-full h-8 cursor-pointer rounded border"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-text-secondary mb-1">标签评定逻辑说明</label>
                <textarea
                  required
                  rows="3"
                  value={tagForm.desc}
                  onChange={(e) => setTagForm({ ...tagForm, desc: e.target.value })}
                  placeholder="该判定逻辑需要满足的具体条件说明..."
                  className="w-full bg-white border border-slate-300 rounded px-2.5 py-1.5 text-xs text-text-dark"
                ></textarea>
              </div>

            </div>

            {/* Footer */}
            <div className="p-4 border-t bg-slate-50 border-slate-200 flex items-center justify-end gap-2 shrink-0">
              <button
                type="button"
                onClick={() => setIsAddTagOpen(false)}
                className="px-4 py-2 bg-white border border-slate-300 text-text-dark font-bold rounded shadow-sm cursor-pointer"
              >
                取消
              </button>
              <button
                type="submit"
                className="px-5 py-2 bg-primary hover:bg-[#1b3d6f] text-white font-bold rounded shadow cursor-pointer transition-colors"
              >
                保存并发布
              </button>
            </div>
          </form>
        </div>
      )}

      {/* ======================================================================
          DRAWER 2: TAG DETAIL VIEW (查看标签详情右侧抽屉)
          ====================================================================== */}
      {isDetailDrawerOpen && selectedDetails && (
        <div className="fixed inset-0 z-50 flex justify-end">
          {/* Overlay */}
          <div className="absolute inset-0 bg-black/50 transition-opacity" onClick={() => setIsDetailDrawerOpen(false)}></div>

          {/* Details Panel */}
          <div className="relative w-full max-w-lg bg-white h-full shadow-2xl flex flex-col z-10 animate-slide-in">
            {/* Header */}
            <div className="p-5 border-b bg-slate-50 border-slate-200 flex items-center justify-between shrink-0">
              <h3 className="text-sm font-black text-text-dark flex items-center gap-1.5">
                <Info className="h-4.5 w-4.5 text-primary" />
                <span>评价标签元数据详情</span>
              </h3>
              <button onClick={() => setIsDetailDrawerOpen(false)} className="text-slate-400 hover:text-slate-600 p-1">
                <X className="h-5 w-5" />
              </button>
            </div>

            {/* Body */}
            <div className="flex-1 p-6 overflow-y-auto space-y-6 text-xs">
              
              <div className="bg-slate-50 border rounded-lg p-5 space-y-3">
                <div className="flex justify-between items-center">
                  <span className="font-mono font-bold text-[#11356A] text-sm">{selectedDetails.code}</span>
                  <span
                    className="px-2.5 py-0.8 rounded-full font-bold text-[10.5px] shadow-sm text-white"
                    style={{ backgroundColor: selectedDetails.color }}
                  >
                    {selectedDetails.name}
                  </span>
                </div>
                <p className="text-text-secondary leading-relaxed">{selectedDetails.desc}</p>
              </div>

              {/* Scope details */}
              <div className="space-y-3">
                <div className="text-xs font-bold text-text-dark border-l-4 border-primary pl-2 uppercase tracking-wide">
                  数据治理生命周期
                </div>
                <div className="bg-slate-50 border rounded p-4 space-y-3">
                  <div>
                    <span className="text-text-secondary">所属大分类：</span>
                    <span className="font-bold text-text-dark">{selectedDetails.category}</span>
                  </div>
                  <div>
                    <span className="text-text-secondary">系统生成方式：</span>
                    <span className="font-bold text-indigo-700">{selectedDetails.method}</span>
                  </div>
                  <div>
                    <span className="text-text-secondary">当前版本：</span>
                    <span className="font-bold text-text-dark">{selectedDetails.version}</span>
                  </div>
                  <div>
                    <span className="text-text-secondary">覆盖命中人数：</span>
                    <span className="font-bold font-mono text-[#52C41A]">{selectedDetails.hits} 人</span>
                  </div>
                </div>
              </div>

            </div>

            {/* Footer */}
            <div className="p-4 border-t bg-slate-50 border-slate-200 flex items-center justify-end shrink-0">
              <button
                onClick={() => setIsDetailDrawerOpen(false)}
                className="px-4 py-2 bg-primary hover:bg-[#1b3d6f] text-white text-xs font-bold rounded shadow-sm cursor-pointer"
              >
                确认关闭
              </button>
            </div>

          </div>
        </div>
      )}

      {/* ======================================================================
          MODAL: ADD CATEGORY (新增标签分类对话框/模态窗口)
          ====================================================================== */}
      {isAddCatOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/50" onClick={() => setIsAddCatOpen(false)}></div>
          <form
            onSubmit={(e) => {
              e.preventDefault()
              setCategories([...categories, catForm])
              triggerNotification(`已新增标签大分类: ${catForm.name}`, 'success')
              setIsAddCatOpen(false)
            }}
            className="relative bg-white rounded-lg shadow-2xl w-full max-w-md flex flex-col z-10 overflow-hidden animate-zoom-in text-xs"
          >
            <div className="p-4 border-b bg-slate-50 border-slate-200 flex items-center justify-between">
              <h3 className="text-sm font-bold text-text-dark">新增标签大分类</h3>
              <button type="button" onClick={() => setIsAddCatOpen(false)} className="text-slate-400 hover:text-slate-600">
                <X className="h-5 w-5" />
              </button>
            </div>
            <div className="p-6 space-y-4">
              <div>
                <label className="block font-bold text-text-secondary mb-1">分类名称</label>
                <input
                  type="text"
                  required
                  value={catForm.name}
                  onChange={(e) => setCatForm({ ...catForm, name: e.target.value })}
                  placeholder="如: 工会模范表彰类"
                  className="w-full bg-white border border-slate-300 rounded px-3 py-1.5 text-text-dark"
                />
              </div>
              <div>
                <label className="block font-bold text-text-secondary mb-1">分类功能方向描述</label>
                <textarea
                  required
                  rows="3"
                  value={catForm.desc}
                  onChange={(e) => setCatForm({ ...catForm, desc: e.target.value })}
                  placeholder="简要描述该维度用于什么样的贴签规则判定..."
                  className="w-full bg-white border border-slate-300 rounded px-3 py-2 text-text-dark"
                ></textarea>
              </div>
            </div>
            <div className="p-4 border-t bg-slate-50 border-slate-200 flex justify-end gap-2">
              <button type="button" onClick={() => setIsAddCatOpen(false)} className="px-4 py-2 bg-white border rounded shadow-sm font-bold text-text-dark cursor-pointer">
                取消
              </button>
              <button type="submit" className="px-4 py-2 bg-[#52C41A] text-white rounded shadow font-bold cursor-pointer">
                新增分类
              </button>
            </div>
          </form>
        </div>
      )}

    </div>
  )
}
