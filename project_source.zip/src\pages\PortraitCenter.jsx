import { useState, useMemo } from 'react'
import {
  Users,
  Search,
  Filter,
  ChevronDown,
  ChevronUp,
  MapPin,
  Building2,
  Sliders,
  Check,
  Tag,
  Phone,
  Briefcase,
  Calendar,
  Award,
  AlertCircle,
  AlertTriangle,
  ArrowRight,
  FileText,
  Heart,
  TrendingUp,
  ArrowLeft,
  ShieldCheck,
  Activity,
  QrCode,
  UserCheck,
  Plus,
  X,
  Sparkles,
  Download,
  Printer,
  RefreshCw,
  Layers,
  CheckCircle2,
  Cpu,
  Info
} from 'lucide-react'

// Workers Database
const INITIAL_WORKERS = [
  {
    id: 'w1',
    name: '张建国',
    age: 46,
    idCard: '3701021980******56',
    score: 94,
    grade: 'A 级',
    team: '钢筋一班',
    enterprise: '中建一局集团',
    jobType: '特种塔吊工',
    status: '在岗',
    years: 15,
    region: '北京朝阳',
    photo: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150',
    tags: ['全勤标兵', '工匠先锋', '健康良好', '安全之星', '优秀班组', 'A级工人'],
    radar: { ability: 95, fulfill: 90, safety: 96, health: 92, credit: 98 },
    history: {
      projects: [
        { time: '2026.01 - 至今', name: '北京CBD东区超高层项目', duty: '特种塔吊班组长', eval: '技术极其过硬，安全意识卓越' },
        { time: '2024.03 - 2025.12', name: '北京大兴机场二期航站楼', duty: '塔吊信号指挥工', eval: '无任何安全违章，按时打卡考勤' }
      ],
      rewards: [
        { time: '2026.07.08', title: '季度百日安全生产卫士奖', agency: '中建一局项目部', file: 'cert_safe_2026.pdf' },
        { time: '2026.06.01', title: '集团百日安全卫士证书', agency: '中建一局集团', file: 'award_group.pdf' }
      ],
      punishments: [],
      certs: [
        { name: '特种作业操作证(塔式起重机驾驶)', grade: '特种高级', agency: '北京市建设委员会', time: '2028-10-12', file: 'cert_lift_verify.pdf' }
      ],
      health: [
        { time: '2026.07.08', result: '健康良好', forbid: '无职业禁忌', agency: '北京市朝阳区第二医院', trend: '血压稳定' }
      ]
    },
    trend: [88, 89, 91, 90, 92, 92, 93, 94, 94, 94, 94, 94]
  },
  {
    id: 'w2',
    name: '李强',
    age: 38,
    idCard: '4201061988******90',
    score: 85,
    grade: 'B 级',
    team: '架子二班',
    enterprise: '中建一局集团',
    jobType: '架子工',
    status: '在岗',
    years: 10,
    region: '湖北武汉',
    photo: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=150',
    tags: ['安全可信', '优秀履约', '健康良好'],
    radar: { ability: 82, fulfill: 88, safety: 80, health: 90, credit: 92 },
    history: {
      projects: [
        { time: '2026.02 - 至今', name: '北京CBD东区超高层项目', duty: '高处双排脚手架搭设工', eval: '高空防护严密，遵守违章红线' }
      ],
      rewards: [
        { time: '2026.07.08', title: '优秀班组标兵表彰', agency: '中建一局项目部', file: 'reward_team.pdf' }
      ],
      punishments: [],
      certs: [
        { name: '建筑施工特种作业操作证(建筑架子工)', grade: '中级', agency: '湖北省建设厅', time: '2027-08-15', file: 'cert_scaff_verify.pdf' }
      ],
      health: [
        { time: '2026.06.15', result: '健康良好', forbid: '无职业禁忌', agency: '建工体检中心', trend: '正常' }
      ]
    },
    trend: [82, 83, 85, 84, 85, 85, 86, 85, 85, 85, 85, 85]
  },
  {
    id: 'w3',
    name: '王朝阳',
    age: 34,
    idCard: '1301021992******67',
    score: 72,
    grade: 'C 级',
    team: '泥工一班',
    enterprise: '中铁十一局',
    jobType: '泥工',
    status: '待入场',
    years: 8,
    region: '河北石家庄',
    photo: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150',
    tags: ['健康良好', '安全可信'],
    radar: { ability: 78, fulfill: 65, safety: 70, health: 80, credit: 75 },
    history: {
      projects: [
        { time: '2026.03 - 2026-06', name: '北京轨道交通28号线项目', duty: '普通混凝土泥水工', eval: '服从项目日常调度，实操考核及格' }
      ],
      rewards: [],
      punishments: [],
      certs: [
        { name: '普通行业抹灰上岗资格证', grade: '初级', agency: '石家庄技能鉴定所', time: '2029-01-10', file: 'cert_plaster.pdf' }
      ],
      health: [
        { time: '2026.03.01', result: '健康良好', forbid: '无职业禁忌', agency: '石家庄市第三医院', trend: '正常' }
      ]
    },
    trend: [70, 71, 71, 72, 72, 72, 72, 72, 72, 72, 72, 72]
  },
  {
    id: 'w4',
    name: '刘小虎',
    age: 29,
    idCard: '5101051997******45',
    score: 58,
    grade: 'E 级',
    team: '普工班组',
    enterprise: '中铁十一局',
    jobType: '普工',
    status: '离场',
    years: 3,
    region: '四川成都',
    photo: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150',
    tags: ['高空禁忌', '违章警示'],
    radar: { capability: 50, attendance: 62, safety: 45, health: 80, credit: 60 },
    history: {
      projects: [
        { time: '2026.04 - 2026-07', name: '北京轨道交通28号线项目', duty: '材料搬运及辅助杂工', eval: '多次高空违章作业警告，扣减安全分' }
      ],
      rewards: [],
      punishments: [
        { time: '2026.06.12', title: '未戴安全防护帽警告通报', agency: '安检部', file: 'punish_record.pdf' }
      ],
      certs: [],
      health: [
        { time: '2026.04.10', result: '高血压禁忌项', forbid: '高血压、恐高症高空作业禁忌', agency: '北京市朝阳区第二医院', trend: '轻度异常' }
      ]
    },
    trend: [65, 62, 60, 58, 58, 58, 58, 58, 58, 58, 58, 58]
  }
];

export default function PortraitCenter({ triggerNotification }) {
  const [activeTab, setActiveTab] = useState('talent-pool') // talent-pool, compare-analytics

  // Search filters
  const [searchKeyword, setSearchKeyword] = useState('')
  const [filterJob, setFilterJob] = useState('ALL')
  const [filterCorp, setFilterCorp] = useState('ALL')
  const [filterLevel, setFilterLevel] = useState('ALL')
  const [isAdvancedFiltersOpen, setIsAdvancedFiltersOpen] = useState(false)

  // Worker select for Right digital portrait visualizer
  const [selectedWorkerId, setSelectedWorkerId] = useState('w1')
  const [rightSubTab, setRightSubTab] = useState('portrait') // portrait, experience, certs, ai-advice

  // Worker compare states
  const [compareWorkerAId, setCompareWorkerAId] = useState('w1')
  const [compareWorkerBId, setCompareWorkerBId] = useState('w2')

  // PDF report export drawer state
  const [isPdfDrawerOpen, setIsPdfDrawerOpen] = useState(false)

  // Selected worker object
  const activeWorker = useMemo(() => {
    return INITIAL_WORKERS.find(w => w.id === selectedWorkerId) || INITIAL_WORKERS[0]
  }, [selectedWorkerId])

  // Filters search query
  const filteredWorkers = useMemo(() => {
    return INITIAL_WORKERS.filter(w => {
      const matchKey = w.name.includes(searchKeyword) || w.idCard.includes(searchKeyword)
      const matchJob = filterJob === 'ALL' || w.jobType === filterJob
      const matchCorp = filterCorp === 'ALL' || w.enterprise.includes(filterCorp)
      const matchLevel = filterLevel === 'ALL' || w.grade === filterLevel
      return matchKey && matchJob && matchCorp && matchLevel
    })
  }, [searchKeyword, filterJob, filterCorp, filterLevel])

  return (
    <div className="flex-grow flex flex-col gap-6">
      
      {/* 1. Page Header */}
      <div className="bg-white border border-border-gray rounded p-5 flex flex-col md:flex-row md:items-center justify-between gap-4 shrink-0 shadow-sm">
        <div>
          <h2 className="text-xl font-bold text-text-dark flex items-center gap-2">
            <Users className="h-5.5 w-5.5 text-primary animate-pulse" />
            产业工人人才画像中心
            <span className="text-xs font-normal text-text-secondary bg-[#11356A]/5 border border-[#11356A]/20 px-2 py-0.5 rounded">
              大数据劳务建档大厅
            </span>
          </h2>
          <p className="text-xs text-text-secondary mt-1.5">
            穿透查看在场产业工人的五维雷达大模型评价、折线成长轨迹、智能贴签画像，以及安全/奖励/处罚/体检综合成长履历。
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              setIsPdfDrawerOpen(true)
              triggerNotification('开始编译 PDF 画像报告模板预览...', 'success')
            }}
            className="px-3.5 py-1.5 bg-[#11356A] hover:bg-primary-hover text-white rounded font-bold text-xs shadow-sm cursor-pointer flex items-center gap-1"
          >
            <Printer className="h-3.5 w-3.5" />
            一键导出画像报告
          </button>
        </div>
      </div>

      {/* 2. Top KPI Cards (5 Columns) */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-6 shrink-0">
        {[
          { title: '累计评价工人数', val: '1,265 人', desc: '全建制在册库', time: '自动同步', icon: <Users className="h-5 w-5 text-primary" /> },
          { title: 'A级杰出人才数', val: '248 人', desc: '综合评分 90 分以上', time: '模型评定', icon: <Award className="h-5 w-5 text-success-green" /> },
          { title: '重点培养工人数', val: '124 人', desc: '塔吊/架子核心班组', time: 'AI画像识别', icon: <Sparkles className="h-5 w-5 text-orange-500" /> },
          { title: '高风险警退人数', val: '15 人', desc: '含高血压/高频违章', time: '系统预警', icon: <AlertTriangle className="h-5 w-5 text-danger-red animate-pulse" /> },
          { title: '今日评价更新', val: '142 人次', desc: '新增打卡画像重塑', time: '今日跑分', icon: <Activity className="h-5 w-5 text-indigo-600" /> }
        ].map((kpi, idx) => (
          <div key={idx} className="bg-white border border-border-gray p-4 rounded-lg shadow-sm flex flex-col justify-between hover:shadow-md transition-all border-l-4 border-l-primary">
            <div className="flex items-start justify-between">
              <div className="text-[10px] text-text-secondary font-bold uppercase tracking-wider">{kpi.title}</div>
              <div className="bg-slate-50 p-1.5 rounded">{kpi.icon}</div>
            </div>
            <div className="mt-2.5">
              <div className="text-xl font-black text-text-dark font-mono leading-none">{kpi.val}</div>
              <div className="flex items-center justify-between text-[10px] text-text-secondary mt-2">
                <span className="font-semibold text-primary">{kpi.desc}</span>
                <span>{kpi.time.split(' ')[0]}</span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* 3. Primary Tabs Navigation */}
      <div className="bg-white border border-border-gray rounded shadow-sm flex flex-col flex-grow min-h-[500px]">
        
        {/* Navigation tabs */}
        <div className="flex border-b border-border-gray bg-slate-50 px-4 pt-3 shrink-0">
          {[
            { id: 'talent-pool', label: '企业人才库与画像看板 (左右布局)', icon: <Users className="h-4 w-4" /> },
            { id: 'compare-analytics', label: '人才对比与报告分析', icon: <Sliders className="h-4 w-4" /> }
          ].map(t => (
            <button
              key={t.id}
              onClick={() => setActiveTab(t.id)}
              className={`flex items-center gap-1.5 px-4.5 py-3 text-xs font-bold border-t-2 border-x transition-all duration-150 cursor-pointer ${
                activeTab === t.id
                  ? 'bg-white border-x-border-gray border-t-primary text-primary -mb-[1px] relative z-10 shadow-[0_-2px_10px_rgba(0,0,0,0.03)]'
                  : 'bg-transparent border-transparent text-text-secondary hover:text-primary hover:bg-slate-100'
              }`}
            >
              {t.icon}
              <span>{t.label}</span>
            </button>
          ))}
        </div>

        {/* Dynamic Panels */}
        <div className="p-6 flex-grow flex flex-col min-h-[380px]">
          
          {/* ==========================================
              TAB 1: 企业人才库与画像看板 (左右布局 40% : 60%)
              ========================================== */}
          {activeTab === 'talent-pool' && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 flex-grow">
              
              {/* Left Column (40% width): Enterprise Talent Pool Grid Table */}
              <div className="lg:col-span-5 bg-white border border-border-gray rounded-lg p-4 flex flex-col gap-4 shadow-sm overflow-hidden">
                
                {/* Advanced Search bar */}
                <div className="space-y-3 shrink-0">
                  <div className="flex items-center gap-2">
                    <div className="relative flex-grow">
                      <input
                        type="text"
                        value={searchKeyword}
                        onChange={(e) => setSearchKeyword(e.target.value)}
                        placeholder="检索姓名、身份证号..."
                        className="w-full bg-white border border-slate-300 rounded px-2.5 pl-8 py-1.5 text-xs text-text-dark"
                      />
                      <Search className="absolute left-2.5 top-2.5 h-3.5 w-3.5 text-slate-400" />
                    </div>
                    <button
                      onClick={() => setIsAdvancedFiltersOpen(!isAdvancedFiltersOpen)}
                      className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 border rounded font-bold text-xs text-text-dark flex items-center gap-1 cursor-pointer"
                    >
                      <Filter className="h-3.5 w-3.5 text-primary" />
                      高级筛选
                    </button>
                  </div>

                  {isAdvancedFiltersOpen && (
                    <div className="grid grid-cols-2 gap-3 bg-slate-50 border p-3 rounded-lg text-xs animate-slide-down">
                      <div>
                        <label className="block text-text-secondary mb-1">选择工种</label>
                        <select value={filterJob} onChange={(e) => setFilterJob(e.target.value)} className="w-full bg-white border rounded p-1">
                          <option value="ALL">全部工种</option>
                          <option value="特种塔吊工">特种塔吊工</option>
                          <option value="架子工">架子工</option>
                          <option value="电焊工">电焊工</option>
                          <option value="泥工">泥工</option>
                          <option value="普工">普工</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-text-secondary mb-1">选择企业</label>
                        <select value={filterCorp} onChange={(e) => setFilterCorp(e.target.value)} className="w-full bg-white border rounded p-1">
                          <option value="ALL">全部合作分包企业</option>
                          <option value="中建一局">中建一局集团</option>
                          <option value="中铁十一局">中铁十一局</option>
                          <option value="上海建工">上海建工</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-text-secondary mb-1">选择评价级别</label>
                        <select value={filterLevel} onChange={(e) => setFilterLevel(e.target.value)} className="w-full bg-white border rounded p-1 font-mono font-bold">
                          <option value="ALL">全部等级</option>
                          <option value="A 级">A 级</option>
                          <option value="B 级">B 级</option>
                          <option value="C 级">C 级</option>
                          <option value="E 级">E 级</option>
                        </select>
                      </div>
                    </div>
                  )}
                </div>

                {/* Workers list table */}
                <div className="flex-grow border border-slate-200 rounded-lg overflow-y-auto">
                  <table className="b-table text-xs">
                    <thead>
                      <tr>
                        <th>姓名</th>
                        <th>工种</th>
                        <th>所属项目/状态</th>
                        <th>评分/等级</th>
                        <th className="text-right">操作</th>
                      </tr>
                    </thead>
                    <tbody>
                      {filteredWorkers.map(item => (
                        <tr
                          key={item.id}
                          onClick={() => setSelectedWorkerId(item.id)}
                          className={`cursor-pointer hover:bg-slate-50 transition-colors ${
                            selectedWorkerId === item.id ? 'bg-[#11356A]/5 border-l-4 border-l-[#11356A]' : ''
                          }`}
                        >
                          <td className="font-bold text-text-dark">
                            <div className="flex items-center gap-2">
                              <div className="h-6 w-6 bg-primary text-white rounded-full flex items-center justify-center font-bold text-[10px]">
                                {item.name.slice(0, 1)}
                              </div>
                              {item.name}
                            </div>
                          </td>
                          <td>{item.jobType}</td>
                          <td>
                            <div className="space-y-0.5">
                              <div className="truncate max-w-[120px] text-text-secondary">北京东区工地</div>
                              <span className={`inline-block text-[9.5px] px-1.5 py-0.2 rounded font-bold ${
                                item.status === '在岗' ? 'bg-emerald-50 text-success-green border border-emerald-200' :
                                item.status === '待入场' ? 'bg-blue-50 text-primary border border-blue-200 animate-pulse' :
                                'bg-slate-100 text-slate-400 border border-slate-200'
                              }`}>
                                {item.status}
                              </span>
                            </div>
                          </td>
                          <td>
                            <div className="flex items-center gap-1.5">
                              <span className="font-mono font-bold">{item.score}分</span>
                              <span
                                className="px-1.5 py-0.2 rounded font-mono font-bold text-[9px] text-white"
                                style={{
                                  backgroundColor:
                                    item.grade === 'A 级' ? '#52C41A' :
                                    item.grade === 'B 级' ? '#1890FF' :
                                    item.grade === 'C 级' ? '#722ED1' : '#F5222D'
                                }}
                              >
                                {item.grade.split(' ')[0]}
                              </span>
                            </div>
                          </td>
                          <td className="text-right">
                            <button
                              onClick={(e) => {
                                e.stopPropagation()
                                setSelectedWorkerId(item.id)
                                setIsPdfDrawerOpen(true)
                              }}
                              className="text-[#11356A] hover:text-primary-hover font-bold text-xs bg-slate-50 border px-2 py-1 rounded"
                            >
                              画像报告
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

              </div>

              {/* Right Column (60% width): Digital Portrait workspace panel */}
              <div className="lg:col-span-7 bg-white border border-border-gray rounded-lg p-5 flex flex-col gap-6 shadow-sm overflow-y-auto max-h-[700px]">
                
                {/* 1. Top Identity block */}
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b pb-4 shrink-0 bg-slate-50/50 p-4 rounded-lg">
                  <div className="flex items-center gap-4">
                    <div className="h-16 w-16 bg-[#11356A] text-white rounded-full flex items-center justify-center font-bold text-xl border-4 border-white shadow">
                      {activeWorker.name.slice(0, 1)}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="text-base font-black text-text-dark leading-none">{activeWorker.name}</h3>
                        <span className="bg-[#11356A]/10 text-primary border border-primary/20 px-2 py-0.5 rounded text-[10px] font-bold">
                          {activeWorker.jobType}
                        </span>
                      </div>
                      <p className="text-[10px] text-text-secondary mt-1.5 flex items-center gap-1">
                        <Building2 className="h-3 w-3" />
                        <span>所属：{activeWorker.enterprise} | {activeWorker.team}</span>
                      </p>
                      <p className="text-[9px] text-slate-400 font-mono mt-1">身份证号：{activeWorker.idCard}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-4 shrink-0">
                    {/* Rank indices */}
                    <div className="text-right text-[10px] text-text-secondary space-y-0.5 font-semibold">
                      <div>项目排名：<strong className="text-primary font-mono text-xs">第 3 名</strong></div>
                      <div>企业排名：<strong className="text-primary font-mono text-xs">第 12 名</strong></div>
                      <div>全国排名：<strong className="text-slate-400 font-mono text-[10px]">前 2.5%</strong></div>
                    </div>
                    
                    {/* Overall score gauge */}
                    <div className="bg-white border rounded p-2 flex flex-col items-center justify-center shadow-sm">
                      <span className="text-[9px] text-text-secondary font-bold uppercase leading-none mb-1">大模型综合分</span>
                      <span className="text-2xl font-black font-mono text-[#52C41A] leading-none">{activeWorker.score}</span>
                      <span
                        className="px-1.5 py-0.2 rounded font-mono font-bold text-[9px] text-white mt-1"
                        style={{
                          backgroundColor:
                            activeWorker.grade === 'A 级' ? '#52C41A' :
                            activeWorker.grade === 'B 级' ? '#1890FF' :
                            activeWorker.grade === 'C 级' ? '#722ED1' : '#F5222D'
                        }}
                      >
                        {activeWorker.grade}
                      </span>
                    </div>

                    <div className="bg-white border rounded p-1 flex items-center justify-center shadow-sm" title="电子工人卡二维码">
                      <QrCode className="h-10 w-10 text-text-dark" />
                    </div>
                  </div>
                </div>

                {/* 2. AI Comprehensive Evaluation Card */}
                <div className="bg-indigo-50 border border-indigo-150 rounded-lg p-4 flex items-start gap-3 text-xs shrink-0">
                  <div className="bg-indigo-500/10 p-1.5 rounded-full shrink-0">
                    <Cpu className="h-5.5 w-5.5 text-indigo-500 animate-spin" />
                  </div>
                  <div>
                    <span className="font-bold text-[#11356A] block">AI 综合评价推演分析</span>
                    <p className="text-[11px] text-indigo-900 leading-relaxed mt-1">
                      该工人近一年履约表现优秀，连续出勤超过180天，无安全处罚，拥有特种操作证，综合评价等级为 {activeWorker.grade}。
                      建议：<strong>列为特种高空作业班组长后备人选</strong>，并积极推荐参加一级建造施工及BIM建模实操课程。
                    </p>
                  </div>
                </div>

                {/* 3. Sub Tabs within digital portrait workspace */}
                <div className="flex bg-slate-100 p-1 rounded-lg border border-slate-200 self-start shrink-0">
                  {[
                    { id: 'portrait', label: '维度雷达 & 画像标签' },
                    { id: 'experience', label: '成长履历与经历' },
                    { id: 'certs', label: '证书资质与健康' },
                    { id: 'ai-advice', label: '培养建议与风险' }
                  ].map(tab => (
                    <button
                      key={tab.id}
                      onClick={() => setRightSubTab(tab.id)}
                      className={`px-3 py-1 text-[11px] font-bold rounded transition-all cursor-pointer ${
                        rightSubTab === tab.id ? 'bg-[#11356A] text-white shadow-sm' : 'text-text-secondary hover:text-primary'
                      }`}
                    >
                      {tab.label}
                    </button>
                  ))}
                </div>

                {/* 4. Sub panels */}
                <div className="flex-grow flex flex-col gap-6 min-h-[300px]">
                  
                  {/* Sub panel: Portrait (Radar & tag cloud) */}
                  {rightSubTab === 'portrait' && (
                    <div className="flex-grow flex flex-col gap-6">
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 flex-grow">
                        {/* Radar Chart */}
                        <div className="bg-slate-50 border rounded-lg p-4 flex flex-col items-center justify-center shadow-sm">
                          <span className="font-bold text-[10px] text-text-secondary mb-4 uppercase">五维画像雷达评分</span>
                          
                          {/* SVG Radar */}
                          <div className="relative w-44 h-44 flex items-center justify-center">
                            <svg className="w-full h-full" viewBox="0 0 100 100">
                              {/* Background grid */}
                              <polygon points="50,15 85,40 72,80 28,80 15,40" fill="transparent" stroke="#E2E8F0" strokeWidth="1" />
                              <polygon points="50,25 78,45 68,75 32,75 22,45" fill="transparent" stroke="#E2E8F0" strokeWidth="1" />
                              <polygon points="50,35 71,50 63,70 37,70 29,50" fill="transparent" stroke="#CBD5E1" strokeWidth="0.5" />
                              
                              {/* Axis lines */}
                              <line x1="50" y1="50" x2="50" y2="15" stroke="#CBD5E1" strokeWidth="0.5" />
                              <line x1="50" y1="50" x2="85" y2="40" stroke="#CBD5E1" strokeWidth="0.5" />
                              <line x1="50" y1="50" x2="72" y2="80" stroke="#CBD5E1" strokeWidth="0.5" />
                              <line x1="50" y1="50" x2="28" y2="80" stroke="#CBD5E1" strokeWidth="0.5" />
                              <line x1="50" y1="50" x2="15" y2="40" stroke="#CBD5E1" strokeWidth="0.5" />

                              {/* Value Polygon */}
                              {(() => {
                                const abilityY = 50 - (activeWorker.radar.ability || activeWorker.radar.capability || 80) * 0.35
                                const fulfillX = 50 + (activeWorker.radar.fulfill || activeWorker.radar.attendance || 80) * 0.35
                                const safetyY = 50 + (activeWorker.radar.safety || 80) * 0.3
                                const healthX = 50 - (activeWorker.radar.health || 80) * 0.22
                                const creditX = 50 - (activeWorker.radar.credit || 80) * 0.35
                                return (
                                  <polygon
                                    points={`50,${abilityY} ${fulfillX},40 72,${safetyY} 28,80 ${creditX},40`}
                                    fill="rgba(17, 53, 106, 0.2)"
                                    stroke="#11356A"
                                    strokeWidth="1.5"
                                  />
                                )
                              })()}
                            </svg>

                            {/* Label tags */}
                            <span className="absolute top-0 text-[8px] font-bold text-text-dark bg-white px-1 border rounded">职业能力 ({activeWorker.radar.ability || activeWorker.radar.capability})</span>
                            <span className="absolute right-0 top-16 text-[8px] font-bold text-text-dark bg-white px-1 border rounded">履约 ({activeWorker.radar.fulfill || activeWorker.radar.attendance})</span>
                            <span className="absolute bottom-0 right-2 text-[8px] font-bold text-text-dark bg-white px-1 border rounded">安全 ({activeWorker.radar.safety})</span>
                            <span className="absolute bottom-0 left-2 text-[8px] font-bold text-text-dark bg-white px-1 border rounded">健康 ({activeWorker.radar.health})</span>
                            <span className="absolute left-0 top-16 text-[8px] font-bold text-text-dark bg-white px-1 border rounded">信用 ({activeWorker.radar.credit})</span>
                          </div>
                        </div>

                        {/* Growth line chart */}
                        <div className="bg-slate-50 border rounded-lg p-4 flex flex-col justify-between shadow-sm">
                          <span className="font-bold text-[10px] text-text-secondary mb-2 uppercase">12个月综合评分成长曲线</span>
                          
                          {/* SVG Line chart */}
                          <div className="h-28 w-full flex items-end justify-between border-b border-l pb-2 pl-2">
                            <svg className="w-full h-full" viewBox="0 0 120 40">
                              {/* Gradient Area under curve */}
                              <path
                                d={`M10,35 L20,33 L30,30 L40,32 L50,28 L60,26 L70,22 L80,20 L90,20 L100,20 L110,20 L120,20 L120,40 L10,40 Z`}
                                fill="rgba(17, 53, 106, 0.05)"
                              />
                              {/* Actual Line */}
                              <path
                                d={`M10,35 L20,33 L30,30 L40,32 L50,28 L60,26 L70,22 L80,20 L90,20 L100,20 L110,20 L120,20`}
                                fill="transparent"
                                stroke="#11356A"
                                strokeWidth="1.5"
                                strokeLinecap="round"
                              />
                            </svg>
                          </div>
                          
                          <div className="flex items-center justify-between text-[9px] text-slate-400 font-mono mt-1">
                            <span>前12月</span>
                            <span>前6月</span>
                            <span>本月</span>
                          </div>
                        </div>
                      </div>

                      {/* Tag Cloud */}
                      <div className="space-y-2">
                        <span className="text-[10px] font-bold text-text-secondary block">画像智能诊断标签云（点击查看逻辑）</span>
                        <div className="flex flex-wrap gap-2 bg-slate-50 border p-4 rounded-lg">
                          {activeWorker.tags.map((tag, idx) => (
                            <span
                              key={idx}
                              onClick={() => triggerNotification(`标签「${tag}」源于大模型判定逻辑匹配。`, 'info')}
                              className="px-3.5 py-1.5 rounded-full font-bold text-[10.5px] cursor-pointer hover:scale-105 transition-all text-white shadow-sm"
                              style={{
                                backgroundColor:
                                  tag === '工匠先锋' || tag === 'A级工人' ? '#FAAD14' :
                                  tag === '全勤标兵' || tag === '优秀履约' ? '#52C41A' :
                                  tag === '安全之星' ? '#1890FF' : '#722ED1'
                              }}
                            >
                              {tag}
                            </span>
                          ))}
                        </div>
                      </div>

                    </div>
                  )}

                  {/* Sub panel: Experience (Timeline) */}
                  {rightSubTab === 'experience' && (
                    <div className="flex-grow flex flex-col gap-4 text-xs">
                      
                      <div className="space-y-4">
                        <span className="font-bold text-text-secondary block">工人成长活动时间轴</span>
                        
                        <div className="space-y-4 pl-4 border-l border-slate-200">
                          {/* Timeline items */}
                          <div className="relative">
                            <div className="absolute -left-[21px] top-0 h-4 w-4 rounded-full border-2 border-emerald-500 bg-white flex items-center justify-center">
                              <div className="h-2 w-2 bg-[#52C41A] rounded-full"></div>
                            </div>
                            <div className="bg-slate-50 border p-3 rounded-lg">
                              <span className="font-mono text-[10px] text-text-secondary">2026.07 - 至今</span>
                              <div className="font-bold text-text-dark mt-1">入职项目及首发结算：北京CBD东区超高层项目</div>
                              <p className="text-[11px] text-text-secondary mt-1">岗位职务：{activeWorker.history.projects[0]?.duty || '特种架手'}</p>
                            </div>
                          </div>

                          <div className="relative">
                            <div className="absolute -left-[21px] top-0 h-4 w-4 rounded-full border-2 border-indigo-500 bg-white flex items-center justify-center">
                              <div className="h-2 w-2 bg-primary rounded-full"></div>
                            </div>
                            <div className="bg-slate-50 border p-3 rounded-lg">
                              <span className="font-mono text-[10px] text-text-secondary">2026.07.08</span>
                              <div className="font-bold text-text-dark mt-1">季度百日安全生产卫士奖表彰奖励</div>
                              <p className="text-[11px] text-text-secondary mt-1">颁发机关：中建一局安全督察部</p>
                            </div>
                          </div>

                          {activeWorker.history.rewards.length > 1 && (
                            <div className="relative">
                              <div className="absolute -left-[21px] top-0 h-4 w-4 rounded-full border-2 border-indigo-500 bg-white flex items-center justify-center">
                                <div className="h-2 w-2 bg-primary rounded-full"></div>
                              </div>
                              <div className="bg-slate-50 border p-3 rounded-lg">
                                <span className="font-mono text-[10px] text-text-secondary">2026.06.01</span>
                                <div className="font-bold text-text-dark mt-1">集团百日安全卫士加分</div>
                                <p className="text-[11px] text-text-secondary mt-1">评定为 A级 评级工人</p>
                              </div>
                            </div>
                          )}

                        </div>
                      </div>

                    </div>
                  )}

                  {/* Sub panel: Certs & Health */}
                  {rightSubTab === 'certs' && (
                    <div className="flex-grow flex flex-col gap-6 text-xs">
                      
                      {/* Certificates */}
                      <div className="space-y-2">
                        <span className="font-bold text-text-secondary block">执业及特种作业资格证书</span>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          {activeWorker.history.certs.length > 0 ? (
                            activeWorker.history.certs.map((c, i) => (
                              <div key={i} className="bg-slate-50 border border-slate-200 p-4 rounded-lg flex flex-col justify-between shadow-sm">
                                <div>
                                  <div className="flex items-center justify-between mb-2">
                                    <span className="font-bold text-text-dark">{c.name}</span>
                                    <span className="bg-emerald-50 text-success-green border border-emerald-250 text-[9px] px-1.5 py-0.2 rounded font-bold">
                                      {c.grade}
                                    </span>
                                  </div>
                                  <div className="text-[10px] text-text-secondary space-y-1">
                                    <div>核发机关：{c.agency}</div>
                                    <div>有效期至：<span className="font-mono">{c.time}</span></div>
                                  </div>
                                </div>
                                <a href="#" onClick={(e) => { e.preventDefault(); triggerNotification(`证书附件 ${c.file} 加载成功！`, 'success') }} className="text-[10px] text-primary font-bold hover:underline flex items-center gap-0.5 mt-3">
                                  <span>查看证件扫描件 PDF</span>
                                  <ArrowRight className="h-3 w-3" />
                                </a>
                              </div>
                            ))
                          ) : (
                            <div className="bg-slate-50 border p-4 rounded-lg text-text-secondary font-semibold text-center md:col-span-2">
                              无证书备案数据。
                            </div>
                          )}
                        </div>
                      </div>

                      {/* Health Logs */}
                      <div className="space-y-2">
                        <span className="font-bold text-text-secondary block">最近体检筛查与健康档案</span>
                        <div className="bg-slate-50 border rounded-lg p-4 text-xs space-y-3">
                          <div className="grid grid-cols-2 gap-4">
                            <div>体检日期：<span className="font-bold font-mono text-text-dark">{activeWorker.history.health[0]?.time || '无数据'}</span></div>
                            <div>结论状态：<span className="font-bold text-success-green">{activeWorker.history.health[0]?.result || '无数据'}</span></div>
                            <div>职业病禁忌：<span className="font-semibold text-danger-red">{activeWorker.history.health[0]?.forbid || '无禁忌'}</span></div>
                            <div>诊断趋势：<span className="font-semibold text-text-secondary">{activeWorker.history.health[0]?.trend || '稳定'}</span></div>
                          </div>
                          <div className="text-[10.5px] text-text-secondary border-t pt-2 mt-2">
                            体检实施机构：{activeWorker.history.health[0]?.agency || '无'}
                          </div>
                        </div>
                      </div>

                    </div>
                  )}

                  {/* Sub panel: AI advice & risks */}
                  {rightSubTab === 'ai-advice' && (
                    <div className="flex-grow flex flex-col gap-6 text-xs">
                      
                      {/* AI advice */}
                      <div className="space-y-3">
                        <div className="text-xs font-bold text-text-dark border-l-4 border-primary pl-2 uppercase tracking-wide">
                          🧠 AI 大脑培养策略建议
                        </div>
                        <div className="bg-slate-50 border rounded-lg p-4 space-y-2 leading-relaxed">
                          <div className="flex items-center gap-1.5 font-bold text-text-dark">
                            <Sparkles className="h-4.5 w-4.5 text-indigo-500 animate-pulse" />
                            <span>推荐培养方向：特种塔吊金牌工长</span>
                          </div>
                          <div className="space-y-1 text-text-secondary">
                            <div>- 建议委任为项目“班组长后备库”，带领新进场学徒组建班组。</div>
                            <div>- 推荐参与“特种设备安全防倾翻实操技能大赛”获取省市级竞赛加分。</div>
                            <div>- 建议下周安排参与“智能吊装数据化终端”操作培训。</div>
                          </div>
                        </div>
                      </div>

                      {/* AI risks */}
                      <div className="space-y-3">
                        <div className="text-xs font-bold text-text-dark border-l-4 border-danger-red pl-2 uppercase tracking-wide">
                          ⚠️ AI 风险隐患预警通知
                        </div>
                        <div className="bg-red-50/50 border border-red-200 rounded-lg p-4 space-y-2">
                          <div className="flex items-center gap-1.5 font-bold text-danger-red">
                            <AlertCircle className="h-4.5 w-4.5 animate-bounce" />
                            <span>中度风险警告</span>
                          </div>
                          <div className="space-y-1 text-text-secondary">
                            {activeWorker.id === 'w4' ? (
                              <>
                                <div>- <strong>健康禁忌风险：</strong> 体检诊断含有高血压且高空禁忌，已拦截其高空施工派工单！</div>
                                <div>- <strong>违章高频风险：</strong> 发生过习惯性不戴安全帽违章，需进行三级安全重考。</div>
                              </>
                            ) : (
                              <>
                                <div>- <strong>证件临期预警：</strong> 塔吊特种特业证将在 90 天内到期，请督促其到建委端口申请延期审核。</div>
                                <div>- <strong>连续作业提醒：</strong> 最近连续作业超过 14 天，建议适当排班轮休防止疲劳操作。</div>
                              </>
                            )}
                          </div>
                        </div>
                      </div>

                    </div>
                  )}

                </div>

              </div>

            </div>
          )}

          {/* ==========================================
              TAB 2: 人才对比与报告分析 (Dynamic workbench)
              ========================================== */}
          {activeTab === 'compare-analytics' && (
            <div className="flex-grow flex flex-col gap-6 text-xs">
              
              <div className="grid grid-cols-2 gap-6 bg-slate-50 border p-4 rounded-lg">
                <div>
                  <label className="block text-text-secondary font-bold mb-1.5">对比人才 A</label>
                  <select value={compareWorkerAId} onChange={(e) => setCompareWorkerAId(e.target.value)} className="w-full bg-white border rounded px-3 py-2 text-xs">
                    {INITIAL_WORKERS.map(w => (
                      <option key={w.id} value={w.id}>{w.name} ({w.jobType} - {w.score}分)</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-text-secondary font-bold mb-1.5">对比人才 B</label>
                  <select value={compareWorkerBId} onChange={(e) => setCompareWorkerBId(e.target.value)} className="w-full bg-white border rounded px-3 py-2 text-xs">
                    {INITIAL_WORKERS.map(w => (
                      <option key={w.id} value={w.id}>{w.name} ({w.jobType} - {w.score}分)</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-6 flex-grow">
                {/* Panel Worker A */}
                {(() => {
                  const workerA = INITIAL_WORKERS.find(w => w.id === compareWorkerAId)
                  if (!workerA) return null
                  return (
                    <div className="bg-white border border-slate-200 rounded-lg p-5 space-y-4 shadow-sm">
                      <div className="flex items-center gap-3 border-b pb-3">
                        <div className="h-8 w-8 bg-primary text-white rounded-full flex items-center justify-center font-bold text-xs">
                          {workerA.name.slice(0, 1)}
                        </div>
                        <div>
                          <span className="font-bold text-sm text-text-dark">{workerA.name}</span>
                          <span className="bg-slate-100 text-text-secondary text-[10px] px-1.5 rounded ml-2">{workerA.jobType}</span>
                        </div>
                      </div>

                      <div className="space-y-2">
                        <div>综合评分：<strong className="text-[#52C41A] font-mono text-sm">{workerA.score}分</strong> ({workerA.grade})</div>
                        <div>所属企业：<span className="text-text-secondary">{workerA.enterprise}</span></div>
                        <div className="flex flex-wrap gap-1 mt-2">
                          {workerA.tags.map((t, idx) => <span key={idx} className="bg-slate-100 text-slate-700 px-2 py-0.5 rounded text-[9.5px] border">{t}</span>)}
                        </div>
                      </div>
                    </div>
                  )
                })()}

                {/* Panel Worker B */}
                {(() => {
                  const workerB = INITIAL_WORKERS.find(w => w.id === compareWorkerBId)
                  if (!workerB) return null
                  return (
                    <div className="bg-white border border-slate-200 rounded-lg p-5 space-y-4 shadow-sm">
                      <div className="flex items-center gap-3 border-b pb-3">
                        <div className="h-8 w-8 bg-[#1890FF] text-white rounded-full flex items-center justify-center font-bold text-xs">
                          {workerB.name.slice(0, 1)}
                        </div>
                        <div>
                          <span className="font-bold text-sm text-text-dark">{workerB.name}</span>
                          <span className="bg-slate-100 text-text-secondary text-[10px] px-1.5 rounded ml-2">{workerB.jobType}</span>
                        </div>
                      </div>

                      <div className="space-y-2">
                        <div>综合评分：<strong className="text-[#52C41A] font-mono text-sm">{workerB.score}分</strong> ({workerB.grade})</div>
                        <div>所属企业：<span className="text-text-secondary">{workerB.enterprise}</span></div>
                        <div className="flex flex-wrap gap-1 mt-2">
                          {workerB.tags.map((t, idx) => <span key={idx} className="bg-slate-100 text-slate-700 px-2 py-0.5 rounded text-[9.5px] border">{t}</span>)}
                        </div>
                      </div>
                    </div>
                  )
                })()}
              </div>

            </div>
          )}

        </div>
      </div>

      {/* ======================================================================
          DRAWER: EXPORT PDF PREVIEW (PDF 报告导出及预览右侧抽屉)
          ====================================================================== */}
      {isPdfDrawerOpen && activeWorker && (
        <div className="fixed inset-0 z-50 flex justify-end">
          {/* Overlay */}
          <div className="absolute inset-0 bg-black/60 transition-opacity" onClick={() => setIsPdfDrawerOpen(false)}></div>

          {/* PDF Page layout */}
          <div className="relative w-full max-w-2xl bg-white h-full shadow-2xl flex flex-col z-10 animate-slide-in">
            {/* Header */}
            <div className="p-4 border-b bg-slate-50 border-slate-200 flex items-center justify-between shrink-0 text-xs">
              <h3 className="font-black text-text-dark flex items-center gap-1.5">
                <Printer className="h-4.5 w-4.5 text-primary" />
                <span>产业工人人才数字画像 PDF 报告模板预览</span>
              </h3>
              <button onClick={() => setIsPdfDrawerOpen(false)} className="text-slate-400 hover:text-slate-600 p-1">
                <X className="h-5 w-5" />
              </button>
            </div>

            {/* Printable canvas container */}
            <div className="flex-1 p-8 overflow-y-auto bg-slate-100 flex justify-center">
              
              {/* Simulated A4 Page */}
              <div className="bg-white p-8 shadow-lg border rounded text-left space-y-6 max-w-xl w-full text-xs font-serif leading-relaxed text-text-dark">
                
                {/* Header branding */}
                <div className="flex justify-between items-start border-b-2 border-primary pb-3">
                  <div>
                    <h1 className="text-lg font-black tracking-wide text-[#11356A]">建筑产业工人数字画像评估报告</h1>
                    <span className="text-[9px] text-text-secondary font-sans font-semibold">国家建筑产业工人智能评价体系评估中心</span>
                  </div>
                  <QrCode className="h-10 w-10 text-slate-800" />
                </div>

                {/* Grid identity */}
                <div className="flex items-center gap-4 bg-slate-50 p-4 border rounded">
                  <div className="h-14 w-14 bg-primary text-white rounded-full flex items-center justify-center font-bold text-sm font-sans">
                    {activeWorker.name.slice(0, 1)}
                  </div>
                  <div className="grid grid-cols-2 gap-x-6 gap-y-1.5 flex-grow font-sans text-[10px]">
                    <div><strong>姓名：</strong> {activeWorker.name}</div>
                    <div><strong>工种分类：</strong> {activeWorker.jobType}</div>
                    <div><strong>身份证号：</strong> {activeWorker.idCard}</div>
                    <div><strong>工作年限：</strong> {activeWorker.years} 年</div>
                    <div className="col-span-2"><strong>所属企业：</strong> {activeWorker.enterprise}</div>
                  </div>
                </div>

                {/* Score & Radar */}
                <div className="grid grid-cols-2 gap-4 pt-2">
                  <div className="bg-slate-50 border p-4 rounded flex flex-col items-center justify-center text-center">
                    <span className="font-sans font-bold text-[10px] text-text-secondary uppercase">综合评价大模型得分</span>
                    <div className="text-4xl font-black font-mono text-[#52C41A] mt-2">{activeWorker.score}</div>
                    <span className="px-2 py-0.5 rounded font-sans font-bold text-[10px] text-white bg-[#52C41A] mt-2">
                      {activeWorker.grade}
                    </span>
                  </div>
                  
                  <div className="bg-slate-50 border p-3 rounded font-sans space-y-1.5 text-[9.5px]">
                    <div className="font-bold border-b pb-1 mb-1">五维画像评分细节：</div>
                    <div>职业能力得：{activeWorker.radar.ability || activeWorker.radar.capability}分</div>
                    <div>履约天数得：{activeWorker.radar.fulfill || activeWorker.radar.attendance}分</div>
                    <div>安全质量得：{activeWorker.radar.safety}分</div>
                    <div>信用管理得：{activeWorker.radar.credit}分</div>
                    <div>健康档案得：{activeWorker.radar.health}分</div>
                  </div>
                </div>

                {/* AI Comprehensive report */}
                <div className="bg-indigo-50/50 border border-indigo-150 p-4 rounded-lg font-sans">
                  <span className="font-bold text-[#11356A] block text-[10.5px]">🧠 AI 大脑画像审计结论：</span>
                  <p className="text-[10px] text-indigo-900 mt-1.5 leading-relaxed">
                    该工人近一年履约表现优秀，出勤稳定达标，且其特种设备执业证书经 OCR 校对处于真实有效状态。安全违规处罚记录零异常。
                    建议：<strong>符合骨干班组长培养条件</strong>。
                  </p>
                </div>

                {/* Footer timestamp */}
                <div className="text-right text-[8px] text-slate-400 font-sans pt-12 border-t mt-8">
                  防伪验证编码: RPT_EVAL_987625143 | 出具时间: 2026-07-09
                </div>

              </div>

            </div>

            {/* Footer operations */}
            <div className="p-4 border-t bg-slate-50 border-slate-200 flex items-center justify-end gap-2 shrink-0">
              <button
                type="button"
                onClick={() => setIsPdfDrawerOpen(false)}
                className="px-4 py-2 bg-white border border-slate-300 text-text-dark font-bold rounded shadow-sm text-xs cursor-pointer"
              >
                关闭预览
              </button>
              <button
                type="button"
                onClick={() => {
                  triggerNotification('PDF 画像评估报告开始本地序列化生成...', 'success')
                  setIsPdfDrawerOpen(false)
                }}
                className="px-5 py-2 bg-[#52C41A] hover:bg-emerald-600 text-white font-bold rounded shadow text-xs cursor-pointer flex items-center gap-1"
              >
                <Download className="h-4 w-4" />
                下载 PDF 报告文档
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  )
}
