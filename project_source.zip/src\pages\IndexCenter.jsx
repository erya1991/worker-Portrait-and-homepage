import { useState, useMemo } from 'react'
import {
  Sliders,
  Plus,
  Edit,
  Trash2,
  X,
  Check,
  Search,
  Eye,
  Info,
  HelpCircle,
  TrendingUp,
  LayoutGrid,
  FileCode,
  Brackets,
  FolderPlus,
  RefreshCw,
  SlidersHorizontal,
  Layers,
  Download,
  Upload,
  Activity,
  Sparkles,
  Cpu,
  History,
  Award,
  ArrowLeft,
  Copy,
  FileSpreadsheet,
  Play,
  CheckCircle,
  AlertCircle
} from 'lucide-react'

// Initial Dimension Mock Data
const INITIAL_DIMENSIONS = [
  { id: 'd1', name: '职业能力', desc: '评估工人专业岗位技能、特种持证资质、实操比赛获奖及劳动贡献程度。', count: 5, weight: 30, updated: '2026-07-09', status: true },
  { id: 'd2', name: '履约能力', desc: '考核工人进出场合规度、闸机考勤打卡天数、劳动力工时合同履约情况。', count: 4, weight: 25, updated: '2026-07-09', status: true },
  { id: 'd3', name: '安全能力', desc: '监控工人违章通报处罚、日常安全晨会表现、三级安全教育培训及积分。', count: 6, weight: 20, updated: '2026-07-08', status: true },
  { id: 'd4', name: '健康能力', desc: '评估工人健康体检合格状况、高空作业禁忌症筛查、心理评测得分。', count: 3, weight: 10, updated: '2026-07-09', status: true },
  { id: 'd5', name: '信用能力', desc: '融合工人社会信用底账评分、征信守信率、无犯罪记录及守法表现。', count: 3, weight: 15, updated: '2026-07-07', status: true }
];

// Initial Index Mock Data
const INITIAL_INDICES = [
  { id: 'IDX-001', name: '特种作业证件真伪核验率', dimension: '职业能力', source: 'AI智能采集', algType: '加分项', desc: '通过AI智能比对特种设备操作证，确保证件在有效期内且为真证。', status: true, version: 'v2.4.1', remarks: '国标级审核' },
  { id: 'IDX-002', name: '月度班组考勤出勤天数', dimension: '履约能力', source: '实名制系统', algType: '阶梯评分', desc: '根据项目部要求，按照工人每月打卡打满天数进行阶梯式评级。', status: true, version: 'v2.4.0', remarks: '按打卡数累计' },
  { id: 'IDX-003', name: '季度百日安全标兵红榜奖励', dimension: '安全能力', source: '人工维护', algType: '加分项', desc: '对获得安全标兵、优秀班长称号的工人实施信用分值奖励。', status: true, version: 'v2.4.1', remarks: '优秀红榜加分' },
  { id: 'IDX-004', name: '现场违章施工安全通报处罚', dimension: '安全能力', source: 'AI智能采集', algType: '扣分项', desc: '日常高空坠落演练及安全巡查违章扣减指标。', status: true, version: 'v2.3.8', remarks: '红线违章' },
  { id: 'IDX-005', name: '入场职业健康体检合格率', dimension: '健康能力', source: 'API接口', algType: '基准分', desc: '凡建档合格并有合同核销的加满基准分，中途脱岗拉黑扣分。', status: true, version: 'v2.4.1', remarks: '必备前置指标' },
  { id: 'IDX-006', name: '信用守信无失信记录率', dimension: '信用能力', source: '系统计算', algType: '固定分值', desc: '融合国家失信被执行人接口进行联合风控审核评价。', status: true, version: 'v2.1.2', remarks: '接口联动' }
];

// Initial Penetration / Database Source Mock Data
const INITIAL_SOURCES = [
  { id: 'src1', indexName: '特种作业证件真伪核验率', type: 'AI智能采集', system: 'AI智能OCR单据识别系统', field: 't_worker_ocr.cert_verify_status', sync: '上传时触发', updated: '2026-07-09 11:20:15', status: '正常' },
  { id: 'src2', indexName: '月度班组考勤出勤天数', type: '实名制系统', system: '现场闸机刷卡微服务端口', field: 't_attendance.monthly_clock_days', sync: '每日 02:00 自动', updated: '2026-07-09 10:00:00', status: '正常' },
  { id: 'src3', indexName: '季度百日安全标兵红榜奖励', type: '人工维护', system: '平台录入后台台账', field: 't_manual_rewards.award_level', sync: '操作员保存触发', updated: '2026-07-09 09:30:00', status: '正常' },
  { id: 'src4', indexName: '现场违章施工安全通报处罚', type: 'AI智能采集', system: 'AI安全督查记录终端', field: 't_manual_punishments.fine_amount', sync: '实时推入数据', updated: '2026-07-08 17:45:00', status: '正常' },
  { id: 'src5', indexName: '入场职业健康体检合格率', type: 'API接口', system: '住建部实名制保险接口', field: 't_realname_workers.auth_status', sync: '每小时轮询同步', updated: '2026-07-09 12:00:00', status: '正常' }
];

// Initial Version Mock Data
const INITIAL_VERSIONS = [
  { id: 'v1', version: 'v2.4.1', creator: '张主管', time: '2026-07-09 11:20:15', status: '当前激活', desc: '增加了健康评价维度，补齐了特种起重操作证真伪校验加分公式' },
  { id: 'v2', version: 'v2.4.0', creator: '李经理', time: '2026-06-15 10:00:00', status: '历史版本', desc: '重新调整了安全履约天数和出勤扣分上限配置' },
  { id: 'v3', version: 'v2.3.8', creator: '张主管', time: '2026-05-12 14:30:00', status: '历史版本', desc: '删除了多余的技能测试阶梯，合并为固定分值考核' }
];

export default function IndexCenter({ triggerNotification }) {
  const [activeTab, setActiveTab] = useState('dimensions') // dimensions, indices, sources, alg, versions

  // Search and query filters
  const [searchKeyword, setSearchKeyword] = useState('')
  const [filterDimension, setFilterDimension] = useState('ALL')
  const [filterAlg, setFilterAlg] = useState('ALL')
  const [isFiltersOpen, setIsFiltersOpen] = useState(false)

  // Database list states
  const [dimensions, setDimensions] = useState(INITIAL_DIMENSIONS)
  const [indices, setIndices] = useState(INITIAL_INDICES)
  const [sources, setSources] = useState(INITIAL_SOURCES)
  const [versions, setVersions] = useState(INITIAL_VERSIONS)

  // Drawer modal states
  const [isAddIndexOpen, setIsAddIndexOpen] = useState(false)
  const [editingIndex, setEditingIndex] = useState(null)
  const [isDetailDrawerOpen, setIsDetailDrawerOpen] = useState(false)
  const [selectedDetails, setSelectedDetails] = useState(null)

  // Form states
  const [indexForm, setIndexForm] = useState({
    id: '',
    name: '',
    dimension: '职业能力',
    desc: '',
    source: '实名制系统',
    algType: '基准分',
    status: true,
    version: 'v2.4.1',
    remarks: ''
  })

  const [dimForm, setDimForm] = useState({
    id: '',
    name: '',
    desc: '',
    count: 0,
    weight: 20,
    status: true
  })
  const [isAddDimOpen, setIsAddDimOpen] = useState(false)

  // Active Algorithm editing configuration workspace
  const [selectedAlgIndexId, setSelectedAlgIndexId] = useState('IDX-002') // Default: 考勤出勤天数
  const [algType, setAlgType] = useState('阶梯评分') // Default type matching selected index

  // Sub-configuration forms based on selected type
  const [baseValue, setBaseValue] = useState('80')
  const [bonusCond, setBonusCond] = useState('获得优秀工匠称号')
  const [bonusScore, setBonusScore] = useState('10')
  const [bonusMax, setBonusMax] = useState('20')
  
  const [deductCond, setDeductCond] = useState('进入基坑不戴红色安全帽')
  const [deductScore, setDeductScore] = useState('15')
  const [deductMin, setDeductMin] = useState('-30')

  const [weightValue, setWeightValue] = useState('30')
  const [weightBase, setWeightBase] = useState('80')

  const [stepwiseRows, setStepwiseRows] = useState([
    { id: 1, limit: '连续出勤30天', days: 30, score: 5 },
    { id: 2, limit: '连续出勤90天', days: 90, score: 10 },
    { id: 3, limit: '连续出勤180天', days: 180, score: 20 }
  ])

  const [capPerItem, setCapPerItem] = useState('5')
  const [capMax, setCapMax] = useState('30')

  const [intervalRows, setIntervalRows] = useState([
    { min: '0', max: '30', score: '60' },
    { min: '31', max: '80', score: '85' },
    { min: '81', max: '100', score: '100' }
  ])

  // Simulation parameters
  const [mockInputVal, setMockInputVal] = useState('180')
  const [simulationResult, setSimulationResult] = useState(null)
  const [simulationTrace, setSimulationTrace] = useState([])

  // AI recommendations parameters
  const [aiSelectedRec, setAiSelectedRec] = useState({
    title: 'IDX-004 安全培训通报次数',
    recommends: '区间评分',
    reason: '安全培训次数高代表工人参与的合规度高。分值应成区间阶梯式上升，当次数大于10次时得分应为满分以形成良好正向激励。建议配置 [0-3次: 60分, 4-8次: 80分, 8次以上: 100分]。'
  })

  // Dynamic logic translation builder (AI natural translation)
  const computedLogicTranslation = useMemo(() => {
    if (algType === '基准分') {
      return `【自然语言评估】：凡是满足该指标合规底线要求的工人，默认基础得分为 ${baseValue} 分，在此基础上加减其他惩罚权重。`
    }
    if (algType === '加分项') {
      return `【自然语言评估】：当检测到工人满足条件「${bonusCond}」时，系统自动在其分值上累加 ${bonusScore} 分，累计奖励最高不超过 ${bonusMax} 分。`
    }
    if (algType === '扣分项') {
      return `【自然语言评估】：当工人在施工现场触发违规条件「${deductCond}」时，系统自动扣减评分 ${deductScore} 分，下限保底扣至 ${deductMin} 分不再累计。`
    }
    if (algType === '权重计分') {
      return `【自然语言评估】：以指标的原始基准分 ${weightBase} 分乘以权重比例 ${weightValue}%，最终计算出该指标对应的评估得占比分值。`
    }
    if (algType === '阶梯评分') {
      const stepsStr = stepwiseRows.map(r => `出勤 ${r.days} 天得 ${r.score} 分`).join('；');
      return `【自然语言评估】：指标以打卡考勤为依据，进行阶梯式跳跃算分：${stepsStr}。最高可得 ${Math.max(...stepwiseRows.map(r => r.score))} 分。`
    }
    if (algType === '区间评分') {
      const intervalsStr = intervalRows.map(r => `[${r.min}-${r.max}%]区间得 ${r.score} 分`).join('；');
      return `【自然语言评估】：指标分值采用区间滑块划分：${intervalsStr}。`
    }
    if (algType === '封顶评分') {
      return `【自然语言评估】：每项发生的合格指标计 ${capPerItem} 分，随着频次不断累计，但总得分上限被锁死封顶为 ${capMax} 分。`
    }
    return '【自然语言评估】：配置的评价指标得分为固定满分数值，通过/未通过即代表 100/0 分。'
  }, [algType, baseValue, bonusCond, bonusScore, bonusMax, deductCond, deductScore, deductMin, weightValue, weightBase, stepwiseRows, intervalRows, capPerItem, capMax])

  // Run scoring simulation sandbox
  const handleRunSimulation = () => {
    const val = parseFloat(mockInputVal) || 0
    let score = 0
    let trace = []

    trace.push(`[开始执行] 启动仿真引擎加载评价指标：${selectedAlgIndexId}`)
    trace.push(`[参数注入] 注入模拟输入数据: ${val}`)

    if (algType === '基准分') {
      score = parseFloat(baseValue)
      trace.push(`[规则判断] 基准分算法，加载默认分值: ${score}`)
    } else if (algType === '加分项') {
      const added = parseFloat(bonusScore)
      const max = parseFloat(bonusMax)
      score = Math.min(max, added)
      trace.push(`[规则判断] 加分项规则触发，加分分值: ${added}，限制最大封顶: ${max}`)
    } else if (algType === '扣分项') {
      const deducted = parseFloat(deductScore)
      const min = parseFloat(deductMin)
      score = Math.max(min, -deducted)
      trace.push(`[规则判断] 扣分项规则触发，扣减分值: ${deducted}，保底最少扣减至: ${min}`)
    } else if (algType === '阶梯评分') {
      // Find step
      const sortedSteps = [...stepwiseRows].sort((a, b) => b.days - a.days)
      const matchedStep = sortedSteps.find(s => val >= s.days)
      if (matchedStep) {
        score = matchedStep.score
        trace.push(`[规则判断] 满足出勤阶梯条件 「连续出勤天数 >= ${matchedStep.days} 天」`)
        trace.push(`[计分结果] 匹配得分: ${score} 分`)
      } else {
        score = 0
        trace.push(`[警告] 模拟天数 ${val} 低于最低阶梯限制，无出勤得分`)
      }
    } else if (algType === '区间评分') {
      const matchedInterval = intervalRows.find(r => val >= parseFloat(r.min) && val <= parseFloat(r.max))
      if (matchedInterval) {
        score = parseFloat(matchedInterval.score)
        trace.push(`[规则判断] 满足区间匹配 [${matchedInterval.min} - ${matchedInterval.max}]`)
        trace.push(`[计分结果] 获得区间分数: ${score}`)
      } else {
        score = 0
        trace.push(`[警告] 输入数值超出所有区间配置，默认得 0 分`)
      }
    } else {
      score = 100
      trace.push(`[计分结果] 默认计算规则，获得满分分值: 100分`)
    }

    trace.push(`[计算结束] 输出该工人模拟最终评价得分: ${score} 分`)
    setSimulationResult(score)
    setSimulationTrace(trace)
    triggerNotification('算法模拟计算成功！已输出公式推导流水', 'success')
  }

  // Dimension switches
  const handleToggleDimension = (id, currentStatus, name) => {
    setDimensions(prev => prev.map(d => {
      if (d.id === id) {
        const nextStatus = !currentStatus
        triggerNotification(`已${nextStatus ? '激活' : '禁用'}评价维度: 「${name}」`, 'warning')
        return { ...d, status: nextStatus }
      }
      return d
    }))
  }

  // Drill down from dimension card to index manager
  const handleEnterDimension = (name) => {
    setFilterDimension(name)
    setActiveTab('indices')
    triggerNotification(`已为您筛选维度为「${name}」的指标管理台账`, 'info')
  }

  // Advanced filters reset
  const handleQuery = () => {
    triggerNotification('正在按条件检索评价指标库...', 'info')
  }

  const handleReset = () => {
    setSearchKeyword('')
    setFilterDimension('ALL')
    setFilterAlg('ALL')
    triggerNotification('筛选过滤条件已清空', 'info')
  }

  // Drawer Form Save
  const openAddIndexDrawer = (record = null) => {
    if (record) {
      setEditingIndex(record)
      setIndexForm({ ...record })
    } else {
      setEditingIndex(null)
      setIndexForm({
        id: `IDX-00${indices.length + 1}`,
        name: '特种架子安拆实操红榜考核',
        dimension: '职业能力',
        desc: '对取得施工特种架手架合规安拆资格并在现场红榜表彰的工人予以评估分值。',
        source: 'AI智能采集',
        algType: '加分项',
        status: true,
        version: 'v2.4.1',
        remarks: '项目部评优使用'
      })
    }
    setIsAddIndexOpen(true)
  }

  const handleSaveIndexForm = (e) => {
    e.preventDefault()
    if (editingIndex) {
      setIndices(prev => prev.map(item => item.id === editingIndex.id ? { ...indexForm } : item))
      triggerNotification('评价指标更新成功！', 'success')
    } else {
      setIndices(prev => [indexForm, ...prev])
      triggerNotification('新增评价指标成功，已自动提交指标版本底账备案！', 'success')
    }
    setIsAddIndexOpen(false)
  }

  // Delete
  const handleDeleteIndex = (id) => {
    if (confirm(`警告！删除该评价指标可能会导致正在评估的模型输出产生数据断裂，确认删除 [${id}]？`)) {
      setIndices(prev => prev.filter(item => item.id !== id))
      triggerNotification('指标已成功卸载删除。', 'warning')
    }
  }

  // Copy
  const handleCopyIndex = (item) => {
    const copied = {
      ...item,
      id: `IDX-00${indices.length + 1}_COPY`,
      name: `${item.name}_复制版`
    }
    setIndices(prev => [copied, ...prev])
    triggerNotification(`已成功复制并克隆指标: ${item.name}`, 'success')
  }

  // Version rollback
  const handleRollbackVersion = (ver) => {
    if (confirm(`确认要将指标库的维度及权重回滚至历史版本「${ver}」吗？这会覆盖当前的所有配置！`)) {
      triggerNotification(`平台指标已成功整体回滚至 ${ver} 版本！正在重新预编译模型中...`, 'success')
    }
  }

  return (
    <div className="flex-grow flex flex-col gap-6">
      
      {/* 1. Page Title Header */}
      <div className="bg-white border border-border-gray rounded p-5 flex flex-col md:flex-row md:items-center justify-between gap-4 shrink-0 shadow-sm">
        <div>
          <h2 className="text-xl font-bold text-text-dark flex items-center gap-2">
            <Sliders className="h-5.5 w-5.5 text-primary animate-pulse" />
            评价指标配置中心
            <span className="text-xs font-normal text-[#11356A] bg-[#11356A]/5 border border-[#11356A]/20 px-2 py-0.5 rounded">
              国企集团统一备案库
            </span>
          </h2>
          <p className="text-xs text-text-secondary mt-1.5">
            统一维护工人评价模型的维度划分、基础指标计算公式和原始数据映射源，修改后历史评价数据不受影响，自动生成版本归档。
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => triggerNotification('版本已发布归档，当前版本：v2.4.1', 'success')}
            className="px-3 py-1.5 bg-slate-100 border rounded font-bold text-xs text-text-dark flex items-center gap-1 cursor-pointer"
          >
            <History className="h-3 w-3 text-primary animate-spin" />
            当前指标库版本：v2.4.1
          </button>
        </div>
      </div>

      {/* 2. Top KPI Cards (5 Columns) */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-6 shrink-0">
        {[
          { title: '评价维度数量', val: `${dimensions.length} 个`, desc: '安全、履约、能力等', time: '今日 14:00', icon: <LayoutGrid className="h-5 w-5 text-primary" /> },
          { title: '评价指标数量', val: `${indices.length} 项`, desc: '覆盖全业务指标项', time: '10分钟前', icon: <SlidersHorizontal className="h-5 w-5 text-indigo-500" /> },
          { title: '启用中指标', val: `${indices.filter(i => i.status).length} 项`, desc: '模型正常跑分调用', time: '自动同步中', icon: <CheckCircle className="h-5 w-5 text-success-green" /> },
          { title: '停用中指标', val: `${indices.filter(i => !i.status).length} 项`, desc: '历史过期或配置保留', time: '历史库可查', icon: <AlertCircle className="h-5 w-5 text-danger-red" /> },
          { title: '指标最新版本', val: 'v2.4.1', desc: '包含AI智能匹配解释', time: '更新于2026-07-09', icon: <FileCode className="h-5 w-5 text-orange-500" /> }
        ].map((kpi, idx) => (
          <div key={idx} className="bg-white border border-border-gray p-4 rounded-lg shadow-sm flex flex-col justify-between hover:shadow-md transition-all border-l-4 border-l-primary">
            <div className="flex items-start justify-between">
              <div className="text-[10px] text-text-secondary font-bold uppercase tracking-wider">{kpi.title}</div>
              <div className="bg-slate-50 p-1.5 rounded">{kpi.icon}</div>
            </div>
            <div className="mt-2.5">
              <div className="text-xl font-black text-text-dark font-mono leading-none">{kpi.val}</div>
              <div className="flex items-center justify-between text-[10px] text-text-secondary mt-2">
                <span className="font-semibold text-primary">{kpi.desc}</span>
                <span>{kpi.time.split(' ')[0]}</span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* 3. Primary Tabs Navigation */}
      <div className="bg-white border border-border-gray rounded shadow-sm flex flex-col min-h-[500px] flex-grow">
        
        {/* Navigation tabs */}
        <div className="flex border-b border-border-gray bg-slate-50 px-4 pt-3 shrink-0">
          {[
            { id: 'dimensions', label: '评价维度 (核心)', icon: <LayoutGrid className="h-4 w-4" /> },
            { id: 'indices', label: '指标管理台账', icon: <SlidersHorizontal className="h-4 w-4" /> },
            { id: 'sources', label: '数据来源映射', icon: <Brackets className="h-4 w-4" /> },
            { id: 'alg', label: '评分算法编辑器', icon: <FileCode className="h-4 w-4" /> },
            { id: 'versions', label: '指标版本管理', icon: <History className="h-4 w-4" /> }
          ].map(t => (
            <button
              key={t.id}
              onClick={() => setActiveTab(t.id)}
              className={`flex items-center gap-1.5 px-4.5 py-3 text-xs font-bold border-t-2 border-x transition-all duration-150 cursor-pointer ${
                activeTab === t.id
                  ? 'bg-white border-x-border-gray border-t-primary text-primary -mb-[1px] relative z-10 shadow-[0_-2px_10px_rgba(0,0,0,0.03)]'
                  : 'bg-transparent border-transparent text-text-secondary hover:text-primary hover:bg-slate-100'
              }`}
            >
              {t.icon}
              <span>{t.label}</span>
            </button>
          ))}
        </div>

        {/* Dynamic Panels */}
        <div className="p-6 flex-grow flex flex-col min-h-[380px]">
          
          {/* ==========================================
              TAB 1: 评价维度 (Card Layout)
              ========================================== */}
          {activeTab === 'dimensions' && (
            <div className="flex-grow flex flex-col gap-6">
              
              <div className="flex items-center justify-between border-b pb-3 shrink-0">
                <div className="text-xs text-text-secondary font-bold">
                  平台划定 5 大评价主维度，点击维度卡片可直接穿透查看对应的底层细分评价指标。
                </div>
                <button
                  onClick={() => {
                    setDimForm({
                      id: `d_${Date.now()}`,
                      name: '综合发展素质',
                      desc: '评价工人自主进行线上工法创新、新材料应用及工伤防范素养评分。',
                      count: 0,
                      weight: 15,
                      status: true
                    })
                    setIsAddDimOpen(true)
                  }}
                  className="px-3.5 py-1.5 bg-[#52C41A] hover:bg-emerald-600 text-white rounded font-bold text-xs shadow-sm cursor-pointer flex items-center gap-1"
                >
                  <Plus className="h-3.5 w-3.5" />
                  新增维度
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 flex-grow">
                {dimensions.map(d => (
                  <div key={d.id} className="bg-slate-50 border border-slate-200 rounded-lg p-5 flex flex-col justify-between hover:shadow-md transition-shadow relative overflow-hidden">
                    <div className="absolute top-0 right-0 h-1.5 w-full bg-[#11356A]" style={{ opacity: d.status ? 1 : 0.2 }}></div>
                    <div>
                      <div className="flex items-center justify-between mb-3">
                        <h3 className="font-bold text-text-dark text-sm flex items-center gap-1.5">
                          {d.name}
                          <span className={`inline-block h-2 w-2 rounded-full ${d.status ? 'bg-success-green' : 'bg-slate-400'}`}></span>
                        </h3>
                        <div className="flex items-center gap-1 text-[11px] text-text-secondary">
                          <span>状态：</span>
                          <input
                            type="checkbox"
                            checked={d.status}
                            onChange={() => handleToggleDimension(d.id, d.status, d.name)}
                            className="h-3.5 w-3.5 cursor-pointer"
                          />
                        </div>
                      </div>
                      <p className="text-xs text-text-secondary leading-relaxed mb-4">{d.desc}</p>
                    </div>

                    <div className="border-t pt-3 mt-4 space-y-2 text-xs">
                      <div className="flex justify-between">
                        <span className="text-text-secondary">包含指标数量：</span>
                        <span className="font-bold font-mono text-[#11356A]">{d.count} 个</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-text-secondary">评价权重占比：</span>
                        <span className="font-bold text-indigo-700">{d.weight}%</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-text-secondary">最后更新时间：</span>
                        <span className="font-mono text-text-secondary">{d.updated}</span>
                      </div>
                      <div className="flex items-center justify-end gap-2 pt-2">
                        <button
                          onClick={() => handleEnterDimension(d.name)}
                          className="px-3 py-1 bg-white hover:bg-slate-100 border border-slate-300 text-text-dark text-xs font-bold rounded shadow-sm cursor-pointer flex items-center gap-0.5"
                        >
                          进入指标
                          <TrendingUp className="h-3 w-3" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

            </div>
          )}

          {/* ==========================================
              TAB 2: 指标管理台账 (Table Layout)
              ========================================== */}
          {activeTab === 'indices' && (
            <div className="flex-grow flex flex-col gap-6">
              
              {/* Search bar */}
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-50 p-4 border border-border-gray rounded shrink-0">
                <div className="flex items-center gap-4 flex-wrap">
                  <div className="relative">
                    <input
                      type="text"
                      value={searchKeyword}
                      onChange={(e) => setSearchKeyword(e.target.value)}
                      placeholder="搜索指标名称/编码..."
                      className="bg-white border border-slate-300 rounded px-2.5 pl-8 py-1 text-xs text-text-dark w-48"
                    />
                    <Search className="absolute left-2.5 top-2 h-3.5 w-3.5 text-slate-400" />
                  </div>

                  <div>
                    <select
                      value={filterDimension}
                      onChange={(e) => setFilterDimension(e.target.value)}
                      className="bg-white border border-slate-300 rounded px-2 py-1 text-xs text-text-dark"
                    >
                      <option value="ALL">全部维度</option>
                      <option value="职业能力">职业能力</option>
                      <option value="履约能力">履约能力</option>
                      <option value="安全能力">安全能力</option>
                      <option value="健康能力">健康能力</option>
                      <option value="信用能力">信用能力</option>
                    </select>
                  </div>

                  <div>
                    <select
                      value={filterAlg}
                      onChange={(e) => setFilterAlg(e.target.value)}
                      className="bg-white border border-slate-300 rounded px-2 py-1 text-xs text-text-dark"
                    >
                      <option value="ALL">全部算法类型</option>
                      <option value="基准分">基准分</option>
                      <option value="加分项">加分项</option>
                      <option value="扣分项">扣分项</option>
                      <option value="阶梯评分">阶梯评分</option>
                      <option value="固定分值">固定分值</option>
                    </select>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button onClick={handleQuery} className="px-3.5 py-1.5 bg-[#11356A] hover:bg-primary-hover text-white text-xs font-bold rounded shadow-sm cursor-pointer">查询</button>
                  <button onClick={handleReset} className="px-3.5 py-1.5 bg-white hover:bg-slate-50 text-text-dark border border-slate-300 text-xs font-bold rounded shadow-sm cursor-pointer">重置</button>
                </div>
              </div>

              {/* Toolbar */}
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white border border-border-gray p-4 rounded shrink-0">
                <div className="text-xs text-text-secondary font-bold flex items-center gap-1.5">
                  <SlidersHorizontal className="h-4 w-4 text-primary animate-pulse" />
                  <span>当前筛选出 {indices.length} 项评估指标</span>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => openAddIndexDrawer()}
                    className="px-3 py-1.5 bg-[#52C41A] hover:bg-emerald-600 text-white rounded font-bold text-xs shadow-sm cursor-pointer flex items-center gap-1"
                  >
                    <Plus className="h-3.5 w-3.5" />
                    新增指标
                  </button>
                  <button
                    onClick={() => triggerNotification('Excel 导出成功！已保存为平台标准副本。', 'success')}
                    className="px-3 py-1.5 bg-white border border-slate-300 text-text-dark rounded font-bold text-xs shadow-sm cursor-pointer flex items-center gap-1 hover:bg-slate-50"
                  >
                    <Download className="h-3.5 w-3.5" />
                    导出Excel
                  </button>
                </div>
              </div>

              {/* Table */}
              <div className="flex-grow border border-border-gray rounded-lg overflow-x-auto">
                <table className="b-table text-xs">
                  <thead>
                    <tr>
                      <th>指标编号</th>
                      <th>指标名称</th>
                      <th>所属评价维度</th>
                      <th>指标详细说明</th>
                      <th>数据同步来源</th>
                      <th>关联评分算法</th>
                      <th>启用状态</th>
                      <th>版本</th>
                      <th>更新时间</th>
                      <th className="text-right">操作</th>
                    </tr>
                  </thead>
                  <tbody>
                    {indices.map(item => (
                      <tr key={item.id} className="hover:bg-slate-50 transition-colors">
                        <td className="font-mono font-bold text-[#11356A]">{item.id}</td>
                        <td className="font-bold text-text-dark">{item.name}</td>
                        <td>
                          <span className="bg-slate-100 text-text-dark border px-2 py-0.5 rounded text-[10px] font-bold">
                            {item.dimension}
                          </span>
                        </td>
                        <td className="max-w-[200px] truncate text-text-secondary" title={item.desc}>{item.desc}</td>
                        <td className="font-semibold">{item.source}</td>
                        <td>
                          <span className={`text-[10px] px-1.5 py-0.5 rounded font-black border ${
                            item.algType === '扣分项' ? 'bg-red-50 text-danger-red border-red-200' :
                            item.algType === '加分项' ? 'bg-emerald-50 text-success-green border-emerald-200' :
                            'bg-blue-50 text-[#11356A] border-blue-200'
                          }`}>
                            {item.algType}
                          </span>
                        </td>
                        <td>
                          <input
                            type="checkbox"
                            checked={item.status}
                            onChange={() => {
                              setIndices(prev => prev.map(idxObj => idxObj.id === item.id ? { ...idxObj, status: !idxObj.status } : idxObj))
                              triggerNotification(`指标状态已切换。`, 'info')
                            }}
                            className="h-3.5 w-3.5 cursor-pointer"
                          />
                        </td>
                        <td className="font-mono text-text-secondary">{item.version}</td>
                        <td className="font-mono text-text-secondary">2026-07-09</td>
                        <td className="text-right">
                          <div className="flex items-center justify-end gap-1.5">
                            <button
                              onClick={() => {
                                setSelectedDetails(item)
                                setIsDetailDrawerOpen(true)
                              }}
                              className="text-text-secondary hover:text-text-dark font-bold text-xs bg-slate-50 border px-2 py-1 rounded cursor-pointer"
                            >
                              查看
                            </button>
                            <button
                              onClick={() => openAddIndexDrawer(item)}
                              className="text-primary hover:text-primary-hover font-bold text-xs bg-primary/5 border border-primary/20 px-2 py-1 rounded cursor-pointer"
                            >
                              编辑
                            </button>
                            <button
                              onClick={() => handleCopyIndex(item)}
                              className="text-indigo-600 hover:text-indigo-800 font-bold text-xs bg-indigo-50 border border-indigo-200 px-2 py-1 rounded cursor-pointer"
                            >
                              复制
                            </button>
                            <button
                              onClick={() => handleDeleteIndex(item.id)}
                              className="text-danger-red hover:text-red-700 font-bold text-xs bg-red-50 border border-red-200 px-2 py-1 rounded cursor-pointer"
                            >
                              删除
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

            </div>
          )}

          {/* ==========================================
              TAB 3: 数据来源映射
              ========================================== */}
          {activeTab === 'sources' && (
            <div className="flex-grow flex flex-col gap-6">
              
              <div className="flex-grow border border-border-gray rounded-lg overflow-x-auto">
                <table className="b-table text-xs">
                  <thead>
                    <tr>
                      <th>对应评价指标</th>
                      <th>来源类型</th>
                      <th>数据源系统</th>
                      <th>映射底层数据库字段</th>
                      <th>同步触发方式</th>
                      <th>最后同步映射时间</th>
                      <th>接口连接状态</th>
                    </tr>
                  </thead>
                  <tbody>
                    {sources.map(src => (
                      <tr key={src.id} className="hover:bg-slate-50 transition-colors">
                        <td className="font-bold text-text-dark">{src.indexName}</td>
                        <td>
                          <span className="bg-slate-100 text-slate-700 border px-2 py-0.5 rounded text-[10px] font-semibold">
                            {src.type}
                          </span>
                        </td>
                        <td className="font-semibold text-text-dark">{src.system}</td>
                        <td className="font-mono text-indigo-700 font-semibold">{src.field}</td>
                        <td>{src.sync}</td>
                        <td className="font-mono text-text-secondary">{src.updated}</td>
                        <td>
                          <span className="bg-emerald-50 text-success-green border border-emerald-200 px-2 py-0.5 rounded font-black text-[10px]">
                            {src.status}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

            </div>
          )}

          {/* ==========================================
              TAB 4: 评分算法编辑器 (Core module)
              ========================================== */}
          {activeTab === 'alg' && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 flex-grow">
              
              {/* Left Form: Select Index, Select Alg, Config */}
              <div className="lg:col-span-8 bg-white border border-border-gray rounded-lg p-5 flex flex-col gap-6 shadow-sm">
                
                {/* AI Rec Notification banner */}
                <div className="bg-indigo-50 border border-indigo-100 rounded-lg p-4 flex items-start gap-3 text-xs">
                  <div className="bg-indigo-500/10 p-1.5 rounded-full shrink-0">
                    <Sparkles className="h-5.5 w-5.5 text-indigo-500 animate-bounce" />
                  </div>
                  <div>
                    <div className="font-bold text-[#11356A] flex items-center gap-1.5">
                      <span>AI 算法配置推荐引擎</span>
                      <span className="bg-[#11356A]/5 border border-[#11356A]/20 text-[9.5px] px-1.5 py-0.2 rounded font-black">
                        智能建议
                      </span>
                    </div>
                    <p className="text-[11px] text-text-secondary leading-relaxed mt-1">
                      系统检测到指标 <strong>{aiSelectedRec.title}</strong> 包含多阶梯发生频率。AI推荐采用：
                      <strong className="text-indigo-700 font-black">「{aiSelectedRec.recommends}」</strong>。原因：
                      {aiSelectedRec.reason}
                    </p>
                    <button
                      onClick={() => {
                        setAlgType('区间评分')
                        triggerNotification('已采纳 AI 建议，成功将算法类型切换至 [区间评分]', 'success')
                      }}
                      className="mt-2 text-xs font-black text-indigo-600 hover:underline flex items-center gap-0.5"
                    >
                      点击一键采纳并配置
                    </button>
                  </div>
                </div>

                {/* Step 1: Select target Index */}
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block font-bold text-text-secondary mb-1.5">选择评价指标</label>
                    <select
                      value={selectedAlgIndexId}
                      onChange={(e) => {
                        setSelectedAlgIndexId(e.target.value)
                        const ind = indices.find(i => i.id === e.target.value)
                        if (ind) {
                          setAlgType(ind.algType)
                        }
                      }}
                      className="w-full bg-white border border-slate-300 rounded px-2.5 py-2 text-xs text-text-dark"
                    >
                      {indices.map(ind => (
                        <option key={ind.id} value={ind.id}>{ind.id} - {ind.name}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block font-bold text-text-secondary mb-1.5">算法计算类型</label>
                    <select
                      value={algType}
                      onChange={(e) => setAlgType(e.target.value)}
                      className="w-full bg-white border border-slate-300 rounded px-2.5 py-2 text-xs text-text-dark font-bold"
                    >
                      <option value="基准分">基准分</option>
                      <option value="加分项">加分项</option>
                      <option value="扣分项">扣分项</option>
                      <option value="权重计分">权重计分</option>
                      <option value="区间评分">区间评分</option>
                      <option value="阶梯评分">阶梯评分</option>
                      <option value="封顶评分">封顶评分</option>
                      <option value="固定分值">固定分值</option>
                    </select>
                  </div>
                </div>

                {/* Step 2: Dynamic config inputs based on algorithm selection */}
                <div className="border-t border-dashed border-slate-200 pt-5 space-y-4">
                  <div className="text-xs font-bold text-text-dark flex items-center gap-1.5">
                    <SlidersHorizontal className="h-4.5 w-4.5 text-primary" />
                    <span>算法因子具体参数配置</span>
                  </div>

                  {algType === '基准分' && (
                    <div className="grid grid-cols-3 gap-4 text-xs">
                      <div>
                        <label className="block font-bold text-text-secondary mb-1">默认基础分值 (分)</label>
                        <input
                          type="number"
                          value={baseValue}
                          onChange={(e) => setBaseValue(e.target.value)}
                          className="w-full bg-white border border-slate-300 rounded px-2.5 py-1.5 text-xs text-text-dark"
                        />
                      </div>
                      <div>
                        <label className="block font-bold text-text-secondary mb-1">最高得分上限 (分)</label>
                        <input type="number" disabled value="100" className="w-full bg-slate-50 border border-slate-200 rounded px-2.5 py-1.5 text-xs text-text-secondary font-mono" />
                      </div>
                      <div>
                        <label className="block font-bold text-text-secondary mb-1">最低得分保底 (分)</label>
                        <input type="number" disabled value="0" className="w-full bg-slate-50 border border-slate-200 rounded px-2.5 py-1.5 text-xs text-text-secondary font-mono" />
                      </div>
                    </div>
                  )}

                  {algType === '加分项' && (
                    <div className="space-y-4 text-xs">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="block font-bold text-text-secondary mb-1">加分奖励触发条件</label>
                          <input
                            type="text"
                            value={bonusCond}
                            onChange={(e) => setBonusCond(e.target.value)}
                            className="w-full bg-white border border-slate-300 rounded px-2.5 py-1.5 text-xs text-text-dark"
                          />
                        </div>
                        <div className="grid grid-cols-2 gap-2">
                          <div>
                            <label className="block font-bold text-text-secondary mb-1">每次加分值</label>
                            <input
                              type="number"
                              value={bonusScore}
                              onChange={(e) => setBonusScore(e.target.value)}
                              className="w-full bg-white border border-slate-300 rounded px-2.5 py-1.5 text-xs text-text-dark"
                            />
                          </div>
                          <div>
                            <label className="block font-bold text-text-secondary mb-1">累积加分上限</label>
                            <input
                              type="number"
                              value={bonusMax}
                              onChange={(e) => setBonusMax(e.target.value)}
                              className="w-full bg-white border border-slate-300 rounded px-2.5 py-1.5 text-xs text-text-dark"
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                  )}

                  {algType === '扣分项' && (
                    <div className="space-y-4 text-xs">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="block font-bold text-text-secondary mb-1">扣分处罚触发条件</label>
                          <input
                            type="text"
                            value={deductCond}
                            onChange={(e) => setDeductCond(e.target.value)}
                            className="w-full bg-white border border-slate-300 rounded px-2.5 py-1.5 text-xs text-text-dark"
                          />
                        </div>
                        <div className="grid grid-cols-2 gap-2">
                          <div>
                            <label className="block font-bold text-text-secondary mb-1">每次扣减值</label>
                            <input
                              type="number"
                              value={deductScore}
                              onChange={(e) => setDeductScore(e.target.value)}
                              className="w-full bg-white border border-slate-300 rounded px-2.5 py-1.5 text-xs text-text-dark font-mono text-danger-red font-bold"
                            />
                          </div>
                          <div>
                            <label className="block font-bold text-text-secondary mb-1">累计扣分保底限</label>
                            <input
                              type="number"
                              value={deductMin}
                              onChange={(e) => setDeductMin(e.target.value)}
                              className="w-full bg-white border border-slate-300 rounded px-2.5 py-1.5 text-xs text-text-dark font-mono"
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                  )}

                  {algType === '权重计分' && (
                    <div className="grid grid-cols-3 gap-4 text-xs">
                      <div>
                        <label className="block font-bold text-text-secondary mb-1">基础总分分值 (分)</label>
                        <input
                          type="number"
                          value={weightBase}
                          onChange={(e) => setWeightBase(e.target.value)}
                          className="w-full bg-white border border-slate-300 rounded px-2.5 py-1.5 text-xs text-text-dark"
                        />
                      </div>
                      <div>
                        <label className="block font-bold text-text-secondary mb-1">分配权重比例 (%)</label>
                        <input
                          type="number"
                          value={weightValue}
                          onChange={(e) => setWeightValue(e.target.value)}
                          className="w-full bg-white border border-slate-300 rounded px-2.5 py-1.5 text-xs text-text-dark font-mono text-primary font-bold"
                        />
                      </div>
                    </div>
                  )}

                  {algType === '阶梯评分' && (
                    <div className="space-y-3 text-xs">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-text-secondary">动态阶梯算分设置表</span>
                        <button
                          type="button"
                          onClick={() => {
                            const newId = stepwiseRows.length + 1
                            setStepwiseRows([...stepwiseRows, { id: newId, limit: `连续出勤${newId * 60}天`, days: newId * 60, score: newId * 10 }])
                          }}
                          className="text-primary hover:text-primary-hover font-bold flex items-center gap-0.5 cursor-pointer"
                        >
                          <Plus className="h-3.5 w-3.5" />
                          添加阶梯行
                        </button>
                      </div>

                      <table className="w-full border text-left text-xs bg-slate-50">
                        <thead>
                          <tr className="bg-slate-100 border-b">
                            <th className="p-2">阶梯层级</th>
                            <th className="p-2">最小触发出勤限制 (天)</th>
                            <th className="p-2">满足条件得分 (分)</th>
                            <th className="p-2 text-right">操作</th>
                          </tr>
                        </thead>
                        <tbody>
                          {stepwiseRows.map((row, idx) => (
                            <tr key={row.id} className="border-b">
                              <td className="p-2 font-bold text-text-dark">阶梯 {idx + 1}</td>
                              <td className="p-2">
                                <input
                                  type="number"
                                  value={row.days}
                                  onChange={(e) => {
                                    const val = parseInt(e.target.value) || 0
                                    setStepwiseRows(stepwiseRows.map(r => r.id === row.id ? { ...r, days: val, limit: `连续出勤${val}天` } : r))
                                  }}
                                  className="bg-white border rounded px-2 py-1 w-24"
                                />
                              </td>
                              <td className="p-2 font-mono font-bold text-primary">
                                <input
                                  type="number"
                                  value={row.score}
                                  onChange={(e) => {
                                    const val = parseInt(e.target.value) || 0
                                    setStepwiseRows(stepwiseRows.map(r => r.id === row.id ? { ...r, score: val } : r))
                                  }}
                                  className="bg-white border rounded px-2 py-1 w-24"
                                />
                              </td>
                              <td className="p-2 text-right">
                                <button
                                  type="button"
                                  onClick={() => setStepwiseRows(stepwiseRows.filter(r => r.id !== row.id))}
                                  className="text-danger-red hover:text-red-700 font-bold p-1 cursor-pointer"
                                >
                                  <Trash2 className="h-4 w-4" />
                                </button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}

                  {algType === '区间评分' && (
                    <div className="space-y-3 text-xs">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-text-secondary">数值百分比区间分配得分</span>
                        <button
                          type="button"
                          onClick={() => {
                            setIntervalRows([...intervalRows, { min: '0', max: '100', score: '50' }])
                          }}
                          className="text-primary hover:text-primary-hover font-bold flex items-center gap-0.5 cursor-pointer"
                        >
                          <Plus className="h-3.5 w-3.5" />
                          添加区间
                        </button>
                      </div>

                      <div className="space-y-2">
                        {intervalRows.map((row, idx) => (
                          <div key={idx} className="flex items-center gap-3 bg-slate-50 border p-2 rounded">
                            <span className="font-bold text-text-secondary w-16">区间 {idx + 1}:</span>
                            <div className="flex items-center gap-1.5">
                              <input
                                type="number"
                                value={row.min}
                                onChange={(e) => setIntervalRows(intervalRows.map((r, i) => i === idx ? { ...r, min: e.target.value } : r))}
                                className="bg-white border rounded px-2 py-1 w-16 text-center"
                              />
                              <span>%</span>
                              <span>至</span>
                              <input
                                type="number"
                                value={row.max}
                                onChange={(e) => setIntervalRows(intervalRows.map((r, i) => i === idx ? { ...r, max: e.target.value } : r))}
                                className="bg-white border rounded px-2 py-1 w-16 text-center"
                              />
                              <span>%</span>
                            </div>
                            <div className="h-4 w-[1px] bg-slate-300"></div>
                            <div className="flex items-center gap-1">
                              <span>该区间得分：</span>
                              <input
                                type="number"
                                value={row.score}
                                onChange={(e) => setIntervalRows(intervalRows.map((r, i) => i === idx ? { ...r, score: e.target.value } : r))}
                                className="bg-white border rounded px-2 py-1 w-16 text-center font-bold text-primary"
                              />
                            </div>
                            <button
                              type="button"
                              onClick={() => setIntervalRows(intervalRows.filter((r, i) => i !== idx))}
                              className="text-danger-red hover:text-red-700 ml-auto cursor-pointer"
                            >
                              <X className="h-4 w-4" />
                            </button>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {algType === '封顶评分' && (
                    <div className="grid grid-cols-2 gap-4 text-xs">
                      <div>
                        <label className="block font-bold text-text-secondary mb-1">单次达标增加得分 (分)</label>
                        <input
                          type="number"
                          value={capPerItem}
                          onChange={(e) => setCapPerItem(e.target.value)}
                          className="w-full bg-white border border-slate-300 rounded px-2.5 py-1.5 text-xs text-text-dark"
                        />
                      </div>
                      <div>
                        <label className="block font-bold text-text-secondary mb-1">指标封顶最高得分 (分)</label>
                        <input
                          type="number"
                          value={capMax}
                          onChange={(e) => setCapMax(e.target.value)}
                          className="w-full bg-white border border-slate-300 rounded px-2.5 py-1.5 text-xs text-text-dark font-mono text-[#11356A] font-bold"
                        />
                      </div>
                    </div>
                  )}

                  {algType === '固定分值' && (
                    <div className="bg-slate-50 border p-4 rounded-lg text-xs space-y-2 text-text-secondary">
                      <div className="font-bold text-text-dark">固定分值说明：</div>
                      <div>系统不对原始数据作算术累加，符合判定条件（如：特种作业持证）即代表满分（100分），未通过代表 0 分。</div>
                    </div>
                  )}

                </div>

                {/* Step 3: Simulation sandbox */}
                <div className="border-t border-slate-200 pt-5 mt-4 space-y-3">
                  <div className="text-xs font-bold text-text-dark">🎛️ 算法执行仿真沙盒 (Simulation Sandbox)</div>
                  <div className="flex items-center gap-4 bg-slate-50 p-4 border rounded-lg text-xs">
                    <div>
                      <span className="text-text-secondary">注入仿真指标数值：</span>
                      <input
                        type="number"
                        value={mockInputVal}
                        onChange={(e) => setMockInputVal(e.target.value)}
                        className="bg-white border rounded px-3 py-1.5 w-28 text-center font-bold font-mono text-primary"
                      />
                    </div>
                    <button
                      type="button"
                      onClick={handleRunSimulation}
                      className="px-4 py-1.5 bg-[#11356A] hover:bg-primary-hover text-white font-bold rounded shadow-sm cursor-pointer flex items-center gap-1"
                    >
                      <Play className="h-3.5 w-3.5 fill-current" />
                      运行仿真计算
                    </button>
                  </div>

                  {simulationResult !== null && (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs mt-2 animate-slide-down">
                      <div className="bg-slate-900 text-slate-300 p-4 rounded-lg font-mono text-[10px] space-y-1.5 max-h-[160px] overflow-y-auto">
                        <div className="text-success-green font-bold border-b border-slate-800 pb-1 mb-2">仿真引擎算分推导日志：</div>
                        {simulationTrace.map((tr, idx) => (
                          <div key={idx}>{tr}</div>
                        ))}
                      </div>
                      <div className="bg-emerald-50 border border-emerald-250 p-4 rounded-lg flex flex-col items-center justify-center text-center">
                        <span className="text-text-secondary text-[11px] font-bold">最终推算工人得分</span>
                        <div className="text-3xl font-black text-success-green font-mono mt-1">{simulationResult} 分</div>
                        <span className="text-[10px] text-slate-400 mt-2">计算公式校验结果：正常合格</span>
                      </div>
                    </div>
                  )}
                </div>

                <div className="flex justify-end gap-2 border-t pt-4">
                  <button
                    onClick={() => {
                      triggerNotification('指标计算公式已保存入库，自动升版指标版本。', 'success')
                    }}
                    className="px-5 py-2 bg-primary hover:bg-[#1b3d6f] text-white text-xs font-bold rounded shadow-sm cursor-pointer"
                  >
                    保存计算规则并提交
                  </button>
                </div>

              </div>

              {/* Right Column: Dynamic logic translation card (light blue bg) */}
              <div className="lg:col-span-4 bg-indigo-50/50 border border-indigo-100 rounded-lg p-5 flex flex-col gap-4 shadow-sm max-h-[500px] overflow-y-auto">
                <div className="flex items-center gap-1.5 text-[#11356A] font-bold text-xs shrink-0 border-b pb-2">
                  <Cpu className="h-4.5 w-4.5 text-indigo-600" />
                  <span>AI 算法逻辑语义翻译</span>
                </div>
                
                <div className="bg-white border border-indigo-150 p-4 rounded shadow-sm space-y-3 text-xs flex-grow">
                  <div className="font-bold text-text-dark">指标名：{indices.find(i => i.id === selectedAlgIndexId)?.name}</div>
                  <div className="text-[11px] text-text-secondary">类型：{algType}</div>
                  <div className="h-[1px] bg-slate-200"></div>
                  <p className="text-indigo-800 font-medium leading-relaxed">
                    {computedLogicTranslation}
                  </p>
                </div>

                <div className="bg-white border rounded p-3 text-[10px] text-text-secondary space-y-1.5">
                  <div className="font-bold text-text-dark">AI 算法评测示例：</div>
                  <div>- 若输入 <strong>10</strong>，则计算得分：5分</div>
                  <div>- 若输入 <strong>95</strong>，则计算得分：10分</div>
                  <div>- 若输入 <strong>185</strong>，则计算得分：20分</div>
                </div>
              </div>

            </div>
          )}

          {/* ==========================================
              TAB 5: 指标版本管理
              ========================================== */}
          {activeTab === 'versions' && (
            <div className="flex-grow flex flex-col gap-6">
              
              <div className="flex-grow border border-border-gray rounded-lg overflow-x-auto">
                <table className="b-table text-xs">
                  <thead>
                    <tr>
                      <th>版本归档号</th>
                      <th>发版时间</th>
                      <th>发版操作员</th>
                      <th>版本发版说明</th>
                      <th>使用状态</th>
                      <th className="text-right">操作</th>
                    </tr>
                  </thead>
                  <tbody>
                    {versions.map(v => (
                      <tr key={v.id} className="hover:bg-slate-50 transition-colors">
                        <td className="font-mono font-bold text-[#11356A]">{v.version}</td>
                        <td className="font-mono text-text-secondary">{v.time}</td>
                        <td className="font-bold text-text-dark">{v.creator}</td>
                        <td className="max-w-md truncate text-text-secondary" title={v.desc}>{v.desc}</td>
                        <td>
                          <span className={`px-2 py-0.5 rounded text-[10px] font-black ${
                            v.status === '当前激活' ? 'bg-emerald-50 text-success-green border border-emerald-200' : 'bg-slate-100 text-slate-400 border border-slate-200'
                          }`}>
                            {v.status}
                          </span>
                        </td>
                        <td className="text-right">
                          <div className="flex items-center justify-end gap-1.5">
                            <button
                              onClick={() => triggerNotification(`已复制归档版本: ${v.version}`, 'success')}
                              className="text-text-secondary hover:text-text-dark font-bold text-xs bg-slate-50 border px-2 py-1 rounded cursor-pointer"
                            >
                              复制
                            </button>
                            <button
                              onClick={() => handleRollbackVersion(v.version)}
                              disabled={v.status === '当前激活'}
                              className={`font-bold text-xs border px-2 py-1 rounded ${
                                v.status === '当前激活'
                                  ? 'bg-slate-100 text-slate-400 border-slate-200 cursor-not-allowed'
                                  : 'text-primary hover:text-primary-hover bg-primary/5 border-primary/20 cursor-pointer'
                              }`}
                            >
                              回滚至此版本
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

            </div>
          )}

        </div>
      </div>

      {/* ======================================================================
          DRAWER 1: ADD/EDIT INDEX (新增/修改指标右侧抽屉)
          ====================================================================== */}
      {isAddIndexOpen && (
        <div className="fixed inset-0 z-50 flex justify-end">
          {/* Overlay */}
          <div className="absolute inset-0 bg-black/50 transition-opacity" onClick={() => setIsAddIndexOpen(false)}></div>

          {/* Form Panel */}
          <form
            onSubmit={handleSaveIndexForm}
            className="relative w-full max-w-lg bg-white h-full shadow-2xl flex flex-col z-10 animate-slide-in"
          >
            {/* Header */}
            <div className="p-5 border-b bg-slate-50 border-slate-200 flex items-center justify-between shrink-0">
              <h3 className="text-sm font-black text-text-dark flex items-center gap-1.5">
                <SlidersHorizontal className="h-4.5 w-4.5 text-primary" />
                <span>{editingIndex ? '编辑评价指标' : '新增评价指标'}</span>
              </h3>
              <button type="button" onClick={() => setIsAddIndexOpen(false)} className="text-slate-400 hover:text-slate-600 p-1">
                <X className="h-5 w-5" />
              </button>
            </div>

            {/* Scrollable inputs */}
            <div className="flex-grow p-6 overflow-y-auto space-y-4 text-xs">
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block font-bold text-text-secondary mb-1">所属评价维度</label>
                  <select
                    value={indexForm.dimension}
                    onChange={(e) => setIndexForm({ ...indexForm, dimension: e.target.value })}
                    className="w-full bg-white border border-slate-300 rounded px-2.5 py-1.5 text-text-dark"
                  >
                    <option value="职业能力">职业能力</option>
                    <option value="履约能力">履约能力</option>
                    <option value="安全能力">安全能力</option>
                    <option value="健康能力">健康能力</option>
                    <option value="信用能力">信用能力</option>
                  </select>
                </div>
                <div>
                  <label className="block font-bold text-text-secondary mb-1">指标唯一编码</label>
                  <input
                    type="text"
                    required
                    value={indexForm.id}
                    onChange={(e) => setIndexForm({ ...indexForm, id: e.target.value })}
                    placeholder="如: IDX-007"
                    className="w-full bg-white border border-slate-300 rounded px-2.5 py-1.5 text-text-dark font-mono font-bold"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-text-secondary mb-1">指标名称</label>
                <input
                  type="text"
                  required
                  value={indexForm.name}
                  onChange={(e) => setIndexForm({ ...indexForm, name: e.target.value })}
                  placeholder="指标全名"
                  className="w-full bg-white border border-slate-300 rounded px-2.5 py-1.5 text-text-dark"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block font-bold text-text-secondary mb-1">物理数据来源</label>
                  <select
                    value={indexForm.source}
                    onChange={(e) => setIndexForm({ ...indexForm, source: e.target.value })}
                    className="w-full bg-white border border-slate-300 rounded px-2.5 py-1.5 text-text-dark font-bold"
                  >
                    <option value="实名制系统">实名制系统接口</option>
                    <option value="AI智能采集">AI 智能 OCR</option>
                    <option value="人工维护">人工维护补登</option>
                    <option value="系统计算">系统自动跑分计算</option>
                    <option value="API接口">外接第三方API</option>
                  </select>
                </div>
                <div>
                  <label className="block font-bold text-text-secondary mb-1">计分公式算法</label>
                  <select
                    value={indexForm.algType}
                    onChange={(e) => setIndexForm({ ...indexForm, algType: e.target.value })}
                    className="w-full bg-white border border-slate-300 rounded px-2.5 py-1.5 text-text-dark font-bold text-[#11356A]"
                  >
                    <option value="基准分">基准分</option>
                    <option value="加分项">加分项</option>
                    <option value="扣分项">扣分项</option>
                    <option value="阶梯评分">阶梯评分</option>
                    <option value="区间评分">区间评分</option>
                    <option value="固定分值">固定分值</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-bold text-text-secondary mb-1">指标配置说明</label>
                <textarea
                  required
                  rows="3"
                  value={indexForm.desc}
                  onChange={(e) => setIndexForm({ ...indexForm, desc: e.target.value })}
                  placeholder="该评估项的具体计算要求和边界逻辑..."
                  className="w-full bg-white border border-slate-300 rounded px-2.5 py-1.5 text-xs text-text-dark"
                ></textarea>
              </div>

              <div>
                <label className="block font-bold text-text-secondary mb-1">版本归档号</label>
                <input
                  type="text"
                  disabled
                  value={indexForm.version}
                  className="w-full bg-slate-50 border border-slate-200 rounded px-2.5 py-1.5 text-text-secondary font-mono"
                />
              </div>

              <div>
                <label className="block font-bold text-text-secondary mb-1">备注信息</label>
                <input
                  type="text"
                  value={indexForm.remarks}
                  onChange={(e) => setIndexForm({ ...indexForm, remarks: e.target.value })}
                  placeholder="其他备注"
                  className="w-full bg-white border border-slate-300 rounded px-2.5 py-1.5 text-text-dark"
                />
              </div>

            </div>

            {/* Footer */}
            <div className="p-4 border-t bg-slate-50 border-slate-200 flex items-center justify-end gap-2 shrink-0">
              <button
                type="button"
                onClick={() => setIsAddIndexOpen(false)}
                className="px-4 py-2 bg-white border border-slate-300 text-text-dark font-bold rounded shadow-sm cursor-pointer"
              >
                取消
              </button>
              <button
                type="submit"
                className="px-5 py-2 bg-primary hover:bg-[#1b3d6f] text-white font-bold rounded shadow cursor-pointer transition-colors"
              >
                发布指标
              </button>
            </div>
          </form>
        </div>
      )}

      {/* ======================================================================
          DRAWER 2: INDEX DETAIL VIEWER (查看指标穿透详情右侧抽屉)
          ====================================================================== */}
      {isDetailDrawerOpen && selectedDetails && (
        <div className="fixed inset-0 z-50 flex justify-end">
          {/* Overlay */}
          <div className="absolute inset-0 bg-black/50 transition-opacity" onClick={() => setIsDetailDrawerOpen(false)}></div>

          {/* Details Panel */}
          <div className="relative w-full max-w-lg bg-white h-full shadow-2xl flex flex-col z-10 animate-slide-in">
            {/* Header */}
            <div className="p-5 border-b bg-slate-50 border-slate-200 flex items-center justify-between shrink-0">
              <h3 className="text-sm font-black text-text-dark flex items-center gap-1.5">
                <Info className="h-4.5 w-4.5 text-primary" />
                <span>评价指标元数据详情</span>
              </h3>
              <button onClick={() => setIsDetailDrawerOpen(false)} className="text-slate-400 hover:text-slate-600 p-1">
                <X className="h-5 w-5" />
              </button>
            </div>

            {/* Body */}
            <div className="flex-1 p-6 overflow-y-auto space-y-6 text-xs">
              
              {/* Index overview */}
              <div className="bg-slate-50 border rounded-lg p-5 space-y-3">
                <div className="flex justify-between items-center">
                  <span className="font-mono font-bold text-[#11356A] text-sm">{selectedDetails.id}</span>
                  <span className="bg-emerald-50 text-success-green border border-emerald-250 px-2 py-0.5 rounded text-[10px] font-bold">
                    已激活
                  </span>
                </div>
                <h4 className="font-bold text-text-dark text-sm leading-tight">{selectedDetails.name}</h4>
                <p className="text-text-secondary leading-relaxed">{selectedDetails.desc}</p>
              </div>

              {/* Mappings */}
              <div className="space-y-3">
                <div className="text-xs font-bold text-text-dark border-l-4 border-primary pl-2 uppercase tracking-wide">
                  指标数据血缘图谱
                </div>
                <div className="bg-slate-50 border rounded p-4 space-y-3">
                  <div>
                    <span className="text-text-secondary">评价所属维度：</span>
                    <span className="font-bold text-text-dark">{selectedDetails.dimension}</span>
                  </div>
                  <div>
                    <span className="text-text-secondary">物理接收源头：</span>
                    <span className="font-bold text-indigo-700">{selectedDetails.source}</span>
                  </div>
                  <div>
                    <span className="text-text-secondary">映射数据表：</span>
                    <span className="font-mono font-semibold text-text-dark">t_eval_index_data</span>
                  </div>
                  <div>
                    <span className="text-text-secondary">映射物理字段：</span>
                    <span className="font-mono text-danger-red font-bold">idx_{selectedDetails.id.toLowerCase().replace('-', '_')}_score</span>
                  </div>
                </div>
              </div>

              {/* Version History logs */}
              <div className="space-y-3">
                <div className="text-xs font-bold text-text-dark border-l-4 border-primary pl-2 uppercase tracking-wide">
                  版本与归档记录
                </div>
                <div className="space-y-2">
                  {[
                    { ver: 'v2.4.1', date: '2026-07-09', desc: '新增了判定异常数据跳过逻辑' },
                    { ver: 'v2.3.0', date: '2026-05-12', desc: '初始指标备案发布' }
                  ].map((v, i) => (
                    <div key={i} className="flex items-center justify-between border-b pb-2 text-[11px]">
                      <div>
                        <span className="font-bold text-text-dark font-mono">{v.ver}</span>
                        <p className="text-slate-400 mt-0.5">{v.desc}</p>
                      </div>
                      <span className="text-text-secondary font-mono">{v.date}</span>
                    </div>
                  ))}
                </div>
              </div>

            </div>

            {/* Footer */}
            <div className="p-4 border-t bg-slate-50 border-slate-200 flex items-center justify-end shrink-0">
              <button
                onClick={() => setIsDetailDrawerOpen(false)}
                className="px-4 py-2 bg-primary hover:bg-[#1b3d6f] text-white text-xs font-bold rounded shadow-sm cursor-pointer"
              >
                确认关闭
              </button>
            </div>

          </div>
        </div>
      )}

      {/* ======================================================================
          MODAL: ADD DIMENSION (新增评价维度对话框/模态窗口)
          ====================================================================== */}
      {isAddDimOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/50" onClick={() => setIsAddDimOpen(false)}></div>
          <form
            onSubmit={(e) => {
              e.preventDefault()
              setDimensions([...dimensions, dimForm])
              triggerNotification(`已新增评价维度: ${dimForm.name}`, 'success')
              setIsAddDimOpen(false)
            }}
            className="relative bg-white rounded-lg shadow-2xl w-full max-w-md flex flex-col z-10 overflow-hidden animate-zoom-in text-xs"
          >
            <div className="p-4 border-b bg-slate-50 border-slate-200 flex items-center justify-between">
              <h3 className="text-sm font-bold text-text-dark">新增评价评价维度</h3>
              <button type="button" onClick={() => setIsAddDimOpen(false)} className="text-slate-400 hover:text-slate-600">
                <X className="h-5 w-5" />
              </button>
            </div>
            <div className="p-6 space-y-4">
              <div>
                <label className="block font-bold text-text-secondary mb-1">维度名称</label>
                <input
                  type="text"
                  required
                  value={dimForm.name}
                  onChange={(e) => setDimForm({ ...dimForm, name: e.target.value })}
                  placeholder="如: 心理健康测评"
                  className="w-full bg-white border border-slate-300 rounded px-3 py-1.5 text-text-dark"
                />
              </div>
              <div>
                <label className="block font-bold text-text-secondary mb-1">分配权重占比 (%)</label>
                <input
                  type="number"
                  required
                  value={dimForm.weight}
                  onChange={(e) => setDimForm({ ...dimForm, weight: parseInt(e.target.value) || 0 })}
                  className="w-full bg-white border border-slate-300 rounded px-3 py-1.5 text-text-dark"
                />
              </div>
              <div>
                <label className="block font-bold text-text-secondary mb-1">维度描述信息</label>
                <textarea
                  required
                  rows="3"
                  value={dimForm.desc}
                  onChange={(e) => setDimForm({ ...dimForm, desc: e.target.value })}
                  placeholder="简要描述该维度的考核评价方向..."
                  className="w-full bg-white border border-slate-300 rounded px-3 py-2 text-text-dark"
                ></textarea>
              </div>
            </div>
            <div className="p-4 border-t bg-slate-50 border-slate-200 flex justify-end gap-2">
              <button type="button" onClick={() => setIsAddDimOpen(false)} className="px-4 py-2 bg-white border rounded shadow-sm font-bold text-text-dark cursor-pointer">
                取消
              </button>
              <button type="submit" className="px-4 py-2 bg-primary text-white rounded shadow font-bold cursor-pointer">
                添加维度
              </button>
            </div>
          </form>
        </div>
      )}

    </div>
  )
}
